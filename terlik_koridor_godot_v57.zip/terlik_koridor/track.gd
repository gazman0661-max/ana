extends Node
## FIREBASE ANALYTICS KÖPRÜSÜ (autoload: "Track")
## Android'de TerlikFirebase eklentisini kullanır; editörde / PC'de eklenti yoktur, çağrılar sessizce yok sayılır.
## Toplama kullanıcı Kullanım Şartları'nı kabul edene kadar KAPALI; GDPR bölgesinde ayrıca rıza gerekir
## (rıza = Ayarlar > Reklam Rızası ile aynı anahtar: "gdpr_consent").

const U = preload("res://fx_util.gd")
const PLUGIN_NAME := "TerlikFirebase"

var _p: Object = null


func _ready() -> void:
	if OS.get_name() == "Android" and Engine.has_singleton(PLUGIN_NAME):
		_p = Engine.get_singleton(PLUGIN_NAME)
		refresh_consent()


# Onay durumuna göre toplamayı açar/kapatır (açılışta, onay verilince ve rıza değişince çağrılır).
func refresh_consent() -> void:
	if _p == null:
		return
	var ok: bool = U.get_setting("terms_ok", false)
	if ok and U.gdpr_region():
		ok = U.get_setting("gdpr_consent", false)
	_p.setEnabled(ok)


# Olay gönder. params: {"anahtar": sayı/metin/bool}. Firebase sınırı: olay adı en çok 40 karakter, metin en çok 100.
func event(ev_name: String, params: Dictionary = {}) -> void:
	if _p == null:
		return
	_p.logEvent(ev_name, JSON.stringify(params))


func user_prop(prop_name: String, value: String) -> void:
	if _p == null:
		return
	_p.setUserProperty(prop_name, value)
