extends Node
## GOOGLE PLAY KÖPRÜSÜ (autoload: "Play")
## Android'de TerlikPlay eklentisini kullanır; editörde / PC'de ve Play dışı kurulumlarda çağrılar sessizce yok sayılır.
##  Play.check_update()    -> Play'de yeni sürüm varsa TAM EKRAN uygulama içi güncelleme açılır (oturumda bir kez kontrol)
##  Play.request_review()  -> Play'in uygulama içi puan penceresi (Google kotası dolmuşsa hiçbir şey göstermeyebilir)

const PLUGIN_NAME := "TerlikPlay"

var _p: Object = null
var _update_checked := false


func _ready() -> void:
	if OS.get_name() == "Android" and Engine.has_singleton(PLUGIN_NAME):
		_p = Engine.get_singleton(PLUGIN_NAME)


func check_update() -> void:
	if _p == null or _update_checked:
		return
	_update_checked = true
	_p.checkImmediateUpdate()


func request_review() -> void:
	if _p == null:
		return
	_p.requestReview()
