extends Node
## GOOGLE PLAY FATURALANDIRMA (autoload "Iap") — Android köprüsü: BillingBridgePlugin.java
##
## ÜRÜNLER (Play Console > Para kazanma > Ürünler > Tek seferlik ürünler; ürün kimlikleri aşağıdaki id'ler):
##   no_ads        kalıcı (consume EDİLMEZ)  Banner + geçiş reklamı kalkar. Ödüllü reklamlar (elmas, devam, vb.) kalır.
##   starter_pack  kalıcı, tek seferlik      Başlangıç paketi (coin + güç-uplar). Google zaten ikinci kez satın aldırmaz.
##   coins_1000    tüketilebilir             coin + güç-uplar
##   coins_2500    tüketilebilir             coin + güç-uplar
##   boosters_5    tüketilebilir             sadece güç-uplar
##
## ÇİFT ÖDÜL KORUMASI
##  - Her satın almanın sipariş no'su (yoksa token özeti) "done" kümesine yazılır. Ödül verilmeden önce kontrol edilir.
##  - Ödül -> done kaydı -> consume/acknowledge sırası: uygulama arada kapanırsa satın alma Google'da "açık" kalır ve
##    sonraki açılışta (queryPurchases) tekrar işlenir; done'da varsa ödül TEKRAR verilmez, sadece consume/ack yapılır.
##  - done kümesi bulut kaydına (Cloud) da yazılır: başka cihazda aynı sipariş ikinci kez ödüllendirilmez.
##  - Kalıcı ürünlerde (starter_pack) zaten onaylanmış (ack) bir satın alma, kayıtta yoksa tekrar ÖDÜLLENDİRİLMEZ
##    (veri silinip geri yüklenen cihazda coin tekrar basılmasın); sadece "satın alındı" işaretlenir.
##  - Bekleyen (PENDING) ödemeler onaylanana kadar ödül verilmez.
##
## no_ads yetkisi Google'dan gelir (her açılışta queryPurchases); çevrimdışıyken yerel önbellek kullanılır.
## Editörde / masaüstünde STUB: satın alma 0.7 sn sonra "başarılı" simüle edilir (test içindir).

signal products_changed
signal entitlement_changed
signal purchase_done(id: String, grant: Dictionary)
signal purchase_failed(key: String)          # Loc anahtarı (iap_unavail | iap_owned | iap_fail)
signal purchase_pending(id: String)
signal restore_done
signal busy_changed

const PLUGIN_NAME := "TerlikBilling"
const PATH := "user://terlik_iap.cfg"

# type: "pack" tüketilebilir | "once" kalıcı tek seferlik paket | "noads" kalıcı reklamsız
const CATALOG := [
	{"id": "starter_pack", "type": "once", "coin": 1500, "aim": 3, "slow": 3, "double": 3},
	{"id": "coins_1000", "type": "pack", "coin": 1000, "aim": 3, "slow": 3, "double": 3},
	{"id": "coins_2500", "type": "pack", "coin": 2500, "aim": 5, "slow": 5, "double": 5},
	{"id": "boosters_5", "type": "pack", "coin": 0, "aim": 5, "slow": 5, "double": 5},
	{"id": "no_ads", "type": "noads"},
]
const STUB_PRICES := {"starter_pack": "$1.49", "coins_1000": "$1.99", "coins_2500": "$3.99", "boosters_5": "$0.99", "no_ads": "$3.49"}

var no_ads := false
var done: Dictionary = {}                # sipariş anahtarı -> true  (+ "once:<id>" işaretleri)
var prices: Dictionary = {}              # ürün id -> biçimli fiyat (Play'den, yerel para birimi)
var micros: Dictionary = {}              # ürün id -> fiyat (mikro birim)
var currency: Dictionary = {}            # ürün id -> para birimi kodu
var billing_ok := false
var busy_id := ""
var is_stub := false

var _p: Object = null
var _retry := 0
var _restoring := false
var _busy_serial := 0
var _consuming: Dictionary = {}
var _acking: Dictionary = {}


func _ready() -> void:
	_load()
	if OS.get_name() == "Android":
		if Engine.has_singleton(PLUGIN_NAME):
			_p = Engine.get_singleton(PLUGIN_NAME)
			_p.connect("billing_ready", _on_billing_ready)
			_p.connect("products_loaded", _on_products_loaded)
			_p.connect("purchases_loaded", _on_purchases_loaded)
			_p.connect("purchase_updated", _on_purchase_updated)
			_p.connect("consume_done", _on_consume_done)
			_p.connect("ack_done", _on_ack_done)
			get_tree().create_timer(1.5).timeout.connect(_connect_billing)
	else:
		is_stub = true
		billing_ok = true
		prices = STUB_PRICES.duplicate()


# ---------------- DURUM ----------------
func catalog() -> Array:
	return CATALOG


func find(id: String) -> Dictionary:
	for c in CATALOG:
		if String(c["id"]) == id:
			return c
	return {}


func has_no_ads() -> bool:
	return no_ads


# Kalıcı ürün zaten alındı mı (tüketilebilir paketler için hep false)
func is_owned(id: String) -> bool:
	var c := find(id)
	if c.is_empty():
		return false
	match String(c["type"]):
		"noads":
			return no_ads
		"once":
			return done.has("once:" + id)
	return false


# Satın alınabilir mi (Play bağlı + ürün bilgisi geldi)
func is_available(id: String) -> bool:
	if is_stub:
		return true
	return _p != null and billing_ok and prices.has(id)


func price_text(id: String) -> String:
	return String(prices.get(id, ""))


func is_busy() -> bool:
	return busy_id != ""


# ---------------- BAĞLANTI ----------------
func _connect_billing() -> void:
	if _p == null:
		return
	_p.startConnection()


func _on_billing_ready(ok: bool) -> void:
	if ok:
		billing_ok = true
		_retry = 0
		var ids := PackedStringArray()
		for c in CATALOG:
			ids.append(String(c["id"]))
		_p.queryProducts(",".join(ids))
		_p.queryPurchases()
	else:
		billing_ok = false
		_retry += 1
		var wait := minf(60.0, 5.0 * pow(2.0, float(_retry - 1)))
		get_tree().create_timer(wait).timeout.connect(_connect_billing)
	products_changed.emit()


func _on_products_loaded(json: String) -> void:
	var arr: Variant = JSON.parse_string(json)
	if arr is Array:
		for e in arr:
			if e is Dictionary:
				var id := String(e.get("id", ""))
				if id == "":
					continue
				prices[id] = String(e.get("price", ""))
				micros[id] = int(e.get("micros", 0))
				currency[id] = String(e.get("cur", ""))
	products_changed.emit()


# ---------------- SATIN ALMA ----------------
func buy(id: String) -> bool:
	if busy_id != "":
		return false
	var c := find(id)
	if c.is_empty() or is_owned(id):
		return false
	if is_stub:
		_set_busy(id)
		get_tree().create_timer(0.7).timeout.connect(func(): _stub_complete(id))
		return true
	if _p == null or not billing_ok or not prices.has(id):
		purchase_failed.emit("iap_unavail")
		if _p != null and not billing_ok:
			_connect_billing()
		return false
	_set_busy(id)
	_p.purchase(id)
	return true


func _set_busy(id: String) -> void:
	busy_id = id
	_busy_serial += 1
	var serial := _busy_serial
	busy_changed.emit()
	# Güvenlik: Google penceresinden sonuç hiç gelmezse arayüz kilitli kalmasın
	get_tree().create_timer(180.0).timeout.connect(func():
		if busy_id != "" and _busy_serial == serial:
			busy_id = ""
			busy_changed.emit())


func _clear_busy() -> void:
	if busy_id != "":
		busy_id = ""
		busy_changed.emit()


func _stub_complete(id: String) -> void:
	_clear_busy()
	var c := find(id)
	match String(c["type"]):
		"noads":
			_set_no_ads(true)
			purchase_done.emit(id, {})
		"once":
			_grant(c, "stub:" + id)
		_:
			_grant(c, "stub:%s:%d" % [id, Time.get_ticks_msec()])


func _on_purchase_updated(code: int, json: String) -> void:
	_clear_busy()
	match code:
		0:
			_handle_purchases(_parse_list(json), true)
		1:
			pass                                        # kullanıcı vazgeçti: sessiz
		7:
			purchase_failed.emit("iap_owned_msg")       # zaten sahip: geri yükleme akışını çalıştır
			restore()
		_:
			purchase_failed.emit("iap_fail")


func restore() -> void:
	if is_stub:
		restore_done.emit()
		return
	if _p == null or not billing_ok:
		purchase_failed.emit("iap_unavail")
		_connect_billing()
		return
	_restoring = true
	_p.queryPurchases()


func _on_purchases_loaded(code: int, json: String) -> void:
	if code == 0:
		var list := _parse_list(json)
		_handle_purchases(list, false)
		# Yetki Google'daki gerçek duruma göre (iade edildiyse kalkar). Sadece başarılı sorguda.
		var has := false
		for pv in list:
			if pv is Dictionary and int(pv.get("state", 0)) == 1 and (pv.get("products", []) as Array).has("no_ads"):
				has = true
		_set_no_ads(has)
	if _restoring:
		_restoring = false
		restore_done.emit()


func _parse_list(json: String) -> Array:
	var v: Variant = JSON.parse_string(json)
	return v if v is Array else []


func _handle_purchases(list: Array, celebrate: bool) -> void:
	for pv in list:
		if not (pv is Dictionary):
			continue
		var token := String(pv.get("token", ""))
		var order := String(pv.get("order", ""))
		var state := int(pv.get("state", 0))
		var acked := bool(pv.get("ack", false))
		var key := order if order != "" else "t:" + token.sha256_text().substr(0, 20)
		for pid_v in (pv.get("products", []) as Array):
			var id := String(pid_v)
			var c := find(id)
			if c.is_empty():
				continue
			if state == 2:
				purchase_pending.emit(id)
				continue
			if state != 1:
				continue
			match String(c["type"]):
				"pack":
					if not done.has(key):
						_grant(c, key)
					_consume(token)
				"once":
					if not acked and not done.has(key):
						_grant(c, key)
					else:
						done[key] = true
						done["once:" + id] = true
						_save()
						products_changed.emit()
					if not acked:
						_ack(token)
				"noads":
					var was := no_ads
					_set_no_ads(true)
					if celebrate and not was:
						purchase_done.emit(id, {})
					if not acked:
						_ack(token)


func _consume(token: String) -> void:
	if _p == null or token == "" or _consuming.has(token):
		return
	_consuming[token] = true
	_p.consume(token)


func _ack(token: String) -> void:
	if _p == null or token == "" or _acking.has(token):
		return
	_acking[token] = true
	_p.acknowledge(token)


func _on_consume_done(token: String, _code: int) -> void:
	_consuming.erase(token)        # başarısızsa bir sonraki açılış / geri dönüşte yeniden denenir (ödül zaten done'da)


func _on_ack_done(token: String, _code: int) -> void:
	_acking.erase(token)


# ---------------- ÖDÜL ----------------
func _grant(c: Dictionary, key: String) -> void:
	var g := {}
	var coin := int(c.get("coin", 0))
	if coin > 0:
		Daily.add_coins(coin)
		g["coin"] = coin
	for pu in Daily.PU_IDS:
		var n := int(c.get(pu, 0))
		if n > 0:
			Daily.add_inv(pu, n)
			g[pu] = n
	done[key] = true
	if String(c["type"]) == "once":
		done["once:" + String(c["id"])] = true
	_save()
	Daily.external_change.emit()
	Cloud.mark_dirty(true)
	var id := String(c["id"])
	var ev := {"item_id": id}
	if micros.has(id) and int(micros[id]) > 0:
		ev["value"] = float(micros[id]) / 1000000.0
		ev["currency"] = String(currency.get(id, ""))
	Track.event("purchase", ev)
	products_changed.emit()
	purchase_done.emit(id, g)


func _set_no_ads(v: bool) -> void:
	if no_ads == v:
		return
	no_ads = v
	_save()
	if v:
		Ads.apply_no_ads()
	entitlement_changed.emit()
	products_changed.emit()


# ---------------- BULUT (cloud.gd) ----------------
func cloud_export() -> Array:
	var r: Array = done.keys()
	r.sort()
	return r


func cloud_import(keys: Array) -> void:
	var changed := false
	for k in keys:
		var ks := String(k)
		if ks != "" and not done.has(ks):
			done[ks] = true
			changed = true
	if changed:
		_save()
		products_changed.emit()


# ---------------- KAYIT ----------------
func _load() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	no_ads = bool(cf.get_value("i", "no_ads", false))
	for k in cf.get_value("i", "done", []):
		done[String(k)] = true


func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("i", "no_ads", no_ads)
	cf.set_value("i", "done", done.keys())
	cf.save(PATH)
