extends RefCounted
## Splash ve menü için ortak yardımcılar (easing, yıldız, kontürlü yazı, font).
## Kullanım:  const U = preload("res://fx_util.gd")   ->   U.out_back(x)

const FONT_PATH := "res://assets/fonts/Poppins-Bold.ttf"
const SETTINGS_PATH := "user://terlik_settings.cfg"

# Kullanım Şartları ve Gizlilik Politikası bağlantıları (GitHub Pages; adres büyük/küçük harfe duyarlı)
const TERMS_URL := "https://filinta01453-ui.github.io/AstroFelyx-legal/Terms&Conditions.html"
const PRIVACY_URL := "https://filinta01453-ui.github.io/AstroFelyx-legal/privacypolicy.html"


# Ayarlar (müzik, ses, titreşim, ekran efektleri): menüden yazılır, oyundan okunur.
# GDPR bölgesi mi? (AB üyeleri + AEA + Birleşik Krallık + İsviçre).
# Cihaz diline BAKMAZ: ülke, internetten (IP) bulunup "geo_cc" olarak saklanır (bkz. ads.gd > _geo_lookup).
# Ülke henüz bulunamadıysa (ilk açılış + internet yok) temkinli olarak true döner.
const GDPR_REGIONS := [
	"AT", "BE", "BG", "HR", "CY", "CZ", "DK", "EE", "FI", "FR", "DE", "GR", "HU", "IE",
	"IT", "LV", "LT", "LU", "MT", "NL", "PL", "PT", "RO", "SK", "SI", "ES", "SE",
	"IS", "LI", "NO", "GB", "UK", "CH",
]


static func gdpr_region() -> bool:
	var cc := get_str("geo_cc", "")
	if cc.length() != 2:
		return true
	return GDPR_REGIONS.has(cc.to_upper())


static func get_str(key: String, default_v: String) -> String:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		return str(cf.get_value("s", key, default_v))
	return default_v


static func set_str(key: String, val: String) -> void:
	var cf := ConfigFile.new()
	cf.load(SETTINGS_PATH)
	cf.set_value("s", key, val)
	cf.save(SETTINGS_PATH)


static func get_setting(key: String, default_v: bool) -> bool:
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		return bool(cf.get_value("s", key, default_v))
	return default_v


static func set_setting(key: String, val: bool) -> void:
	var cf := ConfigFile.new()
	cf.load(SETTINGS_PATH)
	cf.set_value("s", key, val)
	cf.save(SETTINGS_PATH)


static func make_font() -> Font:
	if ResourceLoader.exists(FONT_PATH):
		var base: Font = load(FONT_PATH)
		if base != null:
			var fv := FontVariation.new()
			fv.base_font = base
			fv.variation_embolden = 0.35
			return fv
	return ThemeDB.fallback_font


static func out_cubic(x: float) -> float:
	x = clampf(x, 0.0, 1.0)
	return 1.0 - pow(1.0 - x, 3.0)


static func out_back(x: float) -> float:
	x = clampf(x, 0.0, 1.0)
	var c1 := 1.70158
	var c3 := c1 + 1.0
	return 1.0 + c3 * pow(x - 1.0, 3.0) + c1 * pow(x - 1.0, 2.0)


static func out_bounce(x: float) -> float:
	x = clampf(x, 0.0, 1.0)
	var n1 := 7.5625
	var d1 := 2.75
	if x < 1.0 / d1:
		return n1 * x * x
	elif x < 2.0 / d1:
		x -= 1.5 / d1
		return n1 * x * x + 0.75
	elif x < 2.5 / d1:
		x -= 2.25 / d1
		return n1 * x * x + 0.9375
	x -= 2.625 / d1
	return n1 * x * x + 0.984375


static func star_pts(c: Vector2, r_out: float, r_in: float, n: int, rot: float) -> PackedVector2Array:
	var pts := PackedVector2Array()
	for i in n * 2:
		var a := rot + i * PI / float(n)
		var r := r_out if i % 2 == 0 else r_in
		pts.append(c + Vector2(cos(a), sin(a)) * r)
	return pts


# Üç katmanlı (koyu kontür + renkli kontür + dolgu) ortalanmış yazı. pos = (orta x, taban çizgisi y).
# layer: -1 = hepsi, 0 = gölge + koyu kontür, 1 = renkli kontür, 2 = dolgu.
# (Harf harf çizerken önce tüm harflerin 0. katmanı, sonra 1., sonra 2. çizilir ki kontürler komşu harfi örtmesin.)
static func fat_text(ci: CanvasItem, font: Font, txt: String, pos: Vector2, fsize: int, fill: Color, edge: Color, rot: float = 0.0, sc: float = 1.0, alpha: float = 1.0, layer: int = -1) -> void:
	sc = maxf(sc, 0.01)
	ci.draw_set_transform(pos, rot, Vector2(sc, sc))
	var p := Vector2(-500.0, 0.0)
	if layer == -1 or layer == 0:
		ci.draw_string_outline(font, p + Vector2(0, 9), txt, HORIZONTAL_ALIGNMENT_CENTER, 1000.0, fsize, 26, Color(0, 0, 0, 0.35 * alpha))
		ci.draw_string_outline(font, p, txt, HORIZONTAL_ALIGNMENT_CENTER, 1000.0, fsize, 24, Color(0.13, 0.04, 0.03, alpha))
	if layer == -1 or layer == 1:
		ci.draw_string_outline(font, p, txt, HORIZONTAL_ALIGNMENT_CENTER, 1000.0, fsize, 11, Color(edge.r, edge.g, edge.b, alpha))
	if layer == -1 or layer == 2:
		ci.draw_string(font, p, txt, HORIZONTAL_ALIGNMENT_CENTER, 1000.0, fsize, Color(fill.r, fill.g, fill.b, alpha))
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# Küçük, tek kontürlü yazı (etiketler, butonlar için).
static func out_text(ci: CanvasItem, font: Font, txt: String, pos: Vector2, fsize: int, col: Color, rot: float = 0.0, sc: float = 1.0) -> void:
	sc = maxf(sc, 0.01)
	ci.draw_set_transform(pos, rot, Vector2(sc, sc))
	var p := Vector2(-500.0, 0.0)
	ci.draw_string_outline(font, p, txt, HORIZONTAL_ALIGNMENT_CENTER, 1000.0, fsize, 9, Color(0.13, 0.04, 0.03, col.a))
	ci.draw_string(font, p, txt, HORIZONTAL_ALIGNMENT_CENTER, 1000.0, fsize, col)
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# Güneş ışınları (arka plan efekti).
static func sunburst(ci: CanvasItem, c: Vector2, rot: float, n: int, col: Color) -> void:
	for i in n:
		var a0 := rot + i * TAU / float(n)
		var a1 := a0 + TAU / float(n) * 0.5
		var pts := PackedVector2Array([c, c + Vector2(cos(a0), sin(a0)) * 1400.0, c + Vector2(cos(a1), sin(a1)) * 1400.0])
		ci.draw_colored_polygon(pts, col)


static func draw_slipper(ci: CanvasItem, tex: Texture2D, c: Vector2, h: float, rot: float, alpha: float = 1.0) -> void:
	if tex == null:
		return
	var w := h * float(tex.get_width()) / float(tex.get_height())
	ci.draw_set_transform(c, rot, Vector2.ONE)
	ci.draw_texture_rect(tex, Rect2(-w * 0.5, -h * 0.5, w, h), false, Color(1, 1, 1, alpha))
	ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# ---------------- ORTAK ÇİZİM: COIN, ROZET, GÜÇ-UP İKONLARI ----------------
# Coin ikonu: kenarlı altın daire, iç halka, parlama ve ortada küçük yıldız.
static func draw_coin(ci: CanvasItem, c: Vector2, r: float, alpha: float = 1.0) -> void:
	ci.draw_circle(c + Vector2(0, r * 0.10), r, Color(0.45, 0.26, 0.03, alpha))
	ci.draw_circle(c, r, Color(0.72, 0.43, 0.05, alpha))
	ci.draw_circle(c, r * 0.90, Color(1.0, 0.80, 0.18, alpha))
	ci.draw_circle(c, r * 0.70, Color(1.0, 0.89, 0.40, alpha))
	ci.draw_arc(c, r * 0.70, 0.0, TAU, 28, Color(0.88, 0.58, 0.08, alpha), maxf(1.5, r * 0.10))
	ci.draw_arc(c, r * 0.80, PI * 1.05, PI * 1.45, 10, Color(1, 1, 0.85, 0.9 * alpha), maxf(1.5, r * 0.12))
	ci.draw_colored_polygon(star_pts(c, r * 0.36, r * 0.16, 5, -PI / 2.0), Color(0.92, 0.62, 0.10, alpha))


# Kırmızı bildirim noktası (içinde sayı ya da "!"). c = merkez.
static func draw_badge(ci: CanvasItem, font: Font, c: Vector2, txt: String, r: float = 18.0, sc: float = 1.0) -> void:
	r *= sc
	ci.draw_circle(c + Vector2(0, 2.0 * sc), r + 4.0 * sc, Color(0, 0, 0, 0.35))
	ci.draw_circle(c, r + 3.0 * sc, Color(1, 1, 1))
	ci.draw_circle(c, r, Color(0.92, 0.12, 0.16))
	ci.draw_circle(c + Vector2(-r * 0.25, -r * 0.30), r * 0.38, Color(1, 1, 1, 0.22))
	var fs := int(r * 1.15)
	ci.draw_string(font, c + Vector2(-50.0, fs * 0.36), txt, HORIZONTAL_ALIGNMENT_CENTER, 100.0, fs, Color.WHITE)


# Güç-up ikonu (nişan / yavaş çekim / çift terlik). c = merkez, s = ölçek (1.0 = oyun içi düğme boyutu).
static func draw_pu_icon(ci: CanvasItem, tex_slip: Texture2D, id: String, c: Vector2, s: float, col: Color = Color.WHITE) -> void:
	match id:
		"aim":
			ci.draw_arc(c, 17.0 * s, 0.0, TAU, 24, col, 4.0 * s)
			ci.draw_line(c + Vector2(-28, 0) * s, c + Vector2(-9, 0) * s, col, 4.0 * s)
			ci.draw_line(c + Vector2(28, 0) * s, c + Vector2(9, 0) * s, col, 4.0 * s)
			ci.draw_line(c + Vector2(0, -28) * s, c + Vector2(0, -9) * s, col, 4.0 * s)
			ci.draw_line(c + Vector2(0, 28) * s, c + Vector2(0, 9) * s, col, 4.0 * s)
			ci.draw_circle(c, 4.0 * s, col)
		"slow":
			ci.draw_arc(c, 22.0 * s, 0.0, TAU, 28, col, 4.0 * s)
			ci.draw_line(c, c + Vector2(0, -15) * s, col, 4.0 * s)
			ci.draw_line(c, c + Vector2(11, 6) * s, col, 4.0 * s)
			ci.draw_circle(c, 3.5 * s, col)
			ci.draw_line(c + Vector2(-6, -27) * s, c + Vector2(6, -27) * s, col, 4.0 * s)
		"double":
			draw_slipper(ci, tex_slip, c + Vector2(-3, -11) * s, 44.0 * s, -0.18, col.a)
			draw_slipper(ci, tex_slip, c + Vector2(3, 11) * s, 44.0 * s, 0.18, col.a)


# Güç-up'ın dolu yuvarlak düğmesi (ring + gövde + ikon). r = yarıçap.
static func draw_pu_disc(ci: CanvasItem, tex_slip: Texture2D, id: String, c: Vector2, r: float, alpha: float = 1.0) -> void:
	var s := r / 42.0
	ci.draw_circle(c + Vector2(0, 5.0 * s), r, Color(0, 0, 0, 0.45 * alpha))
	ci.draw_circle(c, r, Color(0.1, 0.04, 0.03, alpha))
	ci.draw_circle(c, r - 3.0 * s, Color(0.3, 0.9, 0.5, alpha))
	ci.draw_circle(c, r - 7.0 * s, Color(0.15, 0.10, 0.24, 0.96 * alpha))
	draw_pu_icon(ci, tex_slip, id, c, s, Color(1, 1, 1, alpha))


# Kuadratik bezier noktası (uçan ödüller için)
static func bez(a: Vector2, b: Vector2, c: Vector2, t: float) -> Vector2:
	var u := 1.0 - t
	return a * u * u + b * 2.0 * u * t + c * t * t


# Elmas ikonu (mor-mavi kesme taş). c = merkez, r = yarıçap.
static func draw_gem(ci: CanvasItem, c: Vector2, r: float, alpha: float = 1.0, col: Color = Color(0.45, 0.75, 1.0)) -> void:
	var top := PackedVector2Array([c + Vector2(-0.62, -0.38) * r, c + Vector2(-0.30, -0.80) * r, c + Vector2(0.30, -0.80) * r, c + Vector2(0.62, -0.38) * r])
	var all := PackedVector2Array([c + Vector2(-0.62, -0.38) * r, c + Vector2(-0.30, -0.80) * r, c + Vector2(0.30, -0.80) * r, c + Vector2(0.62, -0.38) * r, c + Vector2(0.0, 0.85) * r])
	var dark := Color(col.r * 0.35, col.g * 0.35, col.b * 0.45, alpha)
	ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-0.70, -0.40) * r, c + Vector2(-0.34, -0.90) * r, c + Vector2(0.34, -0.90) * r, c + Vector2(0.70, -0.40) * r, c + Vector2(0.0, 0.96) * r]), dark)
	ci.draw_colored_polygon(all, Color(col.r, col.g, col.b, alpha))
	ci.draw_colored_polygon(top, Color(minf(col.r + 0.28, 1.0), minf(col.g + 0.2, 1.0), 1.0, alpha))
	ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-0.62, -0.38) * r, c + Vector2(0.0, -0.38) * r, c + Vector2(0.0, 0.85) * r]), Color(col.r * 0.80, col.g * 0.80, col.b * 0.92, alpha))
	ci.draw_line(c + Vector2(-0.62, -0.38) * r, c + Vector2(0.62, -0.38) * r, Color(1, 1, 1, 0.55 * alpha), maxf(1.0, r * 0.06))
	ci.draw_line(c + Vector2(-0.30, -0.80) * r, c + Vector2(0.0, -0.38) * r, Color(1, 1, 1, 0.45 * alpha), maxf(1.0, r * 0.05))
	ci.draw_line(c + Vector2(0.30, -0.80) * r, c + Vector2(0.0, -0.38) * r, Color(1, 1, 1, 0.35 * alpha), maxf(1.0, r * 0.05))
	ci.draw_circle(c + Vector2(-0.22, -0.60) * r, r * 0.09, Color(1, 1, 1, 0.9 * alpha))


# Kalp (küçük parçacıklar için)
static func draw_heart(ci: CanvasItem, c: Vector2, s: float, col: Color) -> void:
	ci.draw_circle(c + Vector2(-0.5, -0.3) * s, s * 0.58, col)
	ci.draw_circle(c + Vector2(0.5, -0.3) * s, s * 0.58, col)
	ci.draw_colored_polygon(PackedVector2Array([c + Vector2(-1.03, -0.12) * s, c + Vector2(1.03, -0.12) * s, c + Vector2(0.0, 1.05) * s]), col)
