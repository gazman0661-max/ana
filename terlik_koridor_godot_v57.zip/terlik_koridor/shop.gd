extends Node
## TERLİK MARKETİ + ELMAS (autoload "Shop")
##
## - Terlik kataloğu, sahip olunanlar, seçili terlik ve elmas bakiyesi burada tutulur (user://terlik_shop.cfg).
## - Coin: Daily.get_coins()/spend_coins() (user://terlik_save.cfg). Elmas: bu dosyada.
## - ELMAS KAZAN: 3 reklam = 1 tur. Her reklam 1/2/3/5/10 elmas (GEM_TABLE oranlarıyla), turun SON reklamında en az 2 elmas garantili.
##   3. reklam bitince COOLDOWN (2 saat) sayacı başlar, dolunca yeni tur. Günlük başka sınır yok.
## - Fiyat kuralı: 1 elmas ≈ 10 coin (gem = coin / 10). Sadece görünüm terlikleri elmasla satılmaz (gem = 0).
## - Terlik özellikleri oyun içinde main.gd'de uygulanır (skin değişkeni = Shop.equipped).

signal changed

const PATH := "user://terlik_shop.cfg"
const COOLDOWN := 7200.0
const ROUND_ADS := 3
const ROUND_MIN_LAST := 2
const GEM_TABLE := [[1, 35], [2, 25], [3, 20], [5, 15], [10, 5]]     # [elmas, yüzde]
const BOOM_MAX := 3                                                  # Bumerang: bölümde en fazla kaç atış geri döner
const GOLD_BONUS := 1.25                                             # Altın: bölüm sonu coin çarpanı

# kind: "power" = özellikli, "look" = sadece görünüm.  coin/gem = fiyat (gem 0 = elmasla satılmaz)
const SKINS := [
	{"id": "classic", "kind": "base", "coin": 0, "gem": 0, "tint": Color(1, 1, 1)},
	{"id": "flame", "kind": "power", "coin": 1500, "gem": 150, "tint": Color(1.0, 0.62, 0.35)},
	{"id": "bolt", "kind": "power", "coin": 3000, "gem": 300, "tint": Color(0.78, 0.86, 1.0)},
	{"id": "giant", "kind": "power", "coin": 4500, "gem": 450, "tint": Color(0.72, 1.0, 0.72)},
	{"id": "gold", "kind": "power", "coin": 6000, "gem": 600, "tint": Color(1.0, 0.86, 0.36)},
	{"id": "hyper", "kind": "power", "coin": 7500, "gem": 750, "tint": Color(0.60, 0.95, 1.0)},
	{"id": "boom", "kind": "power", "coin": 10000, "gem": 1000, "tint": Color(0.86, 0.62, 1.0)},
	{"id": "pink", "kind": "look", "coin": 200, "gem": 0, "tint": Color(1.0, 0.62, 0.82)},
	{"id": "tiger", "kind": "look", "coin": 250, "gem": 0, "tint": Color(1.0, 0.72, 0.30)},
	{"id": "heart", "kind": "look", "coin": 300, "gem": 0, "tint": Color(1.0, 0.55, 0.60)},
	{"id": "rainbow", "kind": "look", "coin": 400, "gem": 0, "tint": Color(1, 1, 1)},
	{"id": "disco", "kind": "look", "coin": 500, "gem": 0, "tint": Color(1, 1, 1)},
]

var gems := 0
var owned: Array = ["classic"]
var equipped := "classic"
var ad_count := 0              # içinde bulunulan turda izlenen reklam sayısı (0..2)
var cd_until := 0.0            # sayaç bitiş zamanı (unix saniye)
var ad_wait := false           # elmas reklamı açık (ödül bekleniyor)


func _ready() -> void:
	_load()


func _load() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	gems = maxi(0, int(cf.get_value("s", "gems", 0)))
	owned = cf.get_value("s", "owned", ["classic"])
	equipped = String(cf.get_value("s", "equipped", "classic"))
	ad_count = clampi(int(cf.get_value("s", "ad_count", 0)), 0, ROUND_ADS - 1)
	cd_until = float(cf.get_value("s", "cd_until", 0.0))
	if not owned.has("classic"):
		owned.append("classic")
	if not owned.has(equipped):
		equipped = "classic"


func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("s", "gems", gems)
	cf.set_value("s", "owned", owned)
	cf.set_value("s", "equipped", equipped)
	cf.set_value("s", "ad_count", ad_count)
	cf.set_value("s", "cd_until", cd_until)
	cf.save(PATH)


# ---------------- KATALOG ----------------
func skin(id: String) -> Dictionary:
	for s in SKINS:
		if s["id"] == id:
			return s
	return SKINS[0]


func is_owned(id: String) -> bool:
	return owned.has(id)


func tint_now(id: String, t: float) -> Color:
	if id == "rainbow":
		return Color.from_hsv(fposmod(t * 0.45, 1.0), 0.55, 1.0)
	if id == "disco":
		return Color.from_hsv(fposmod(floor(t * 5.0) * 0.17, 1.0), 0.65, 1.0)
	return skin(id)["tint"]


# Terliğin arkasındaki parıltı rengi (alfa 0 = yok)
func glow_color(id: String) -> Color:
	match id:
		"flame":
			return Color(1.0, 0.45, 0.08, 0.30)
		"bolt":
			return Color(0.45, 0.65, 1.0, 0.32)
		"gold":
			return Color(1.0, 0.85, 0.25, 0.30)
		"hyper":
			return Color(0.45, 0.95, 1.0, 0.30)
		"boom":
			return Color(0.75, 0.40, 1.0, 0.30)
		"heart":
			return Color(1.0, 0.40, 0.55, 0.22)
		"pink":
			return Color(1.0, 0.55, 0.80, 0.22)
		"disco", "rainbow":
			return Color(1, 1, 1, 0.16)
	return Color(0, 0, 0, 0)


# ---------------- ELMAS / SATIN ALMA ----------------
func add_gems(n: int) -> void:
	if n <= 0:
		return
	gems += n
	_save()
	changed.emit()


# Bakiyeyi doğrudan ayarlar (Bulut birleştirmesi / hesap değişimi)
func set_gems(n: int) -> void:
	gems = maxi(0, n)
	_save()
	changed.emit()


# Bulut birleştirmesinden gelen sahip olunan / takılı terlikler
func cloud_import(own: Array, eq: String) -> void:
	var o: Array = []
	for v in own:
		o.append(String(v))
	if not o.has("classic"):
		o.append("classic")
	owned = o
	equipped = eq if o.has(eq) else "classic"
	_save()
	changed.emit()


# 0 = alındı | 1 = yetersiz bakiye | 2 = zaten sahip | 3 = bu terlik bu para birimiyle satılmaz
func buy(id: String, with_gems: bool) -> int:
	if is_owned(id):
		return 2
	var s := skin(id)
	if with_gems:
		var g := int(s["gem"])
		if g <= 0:
			return 3
		if gems < g:
			return 1
		gems -= g
	else:
		var c := int(s["coin"])
		if not Daily.spend_coins(c):
			return 1
	owned.append(id)
	equipped = id
	_save()
	Track.event("spend_virtual_currency", {"item_name": "skin_" + id, "virtual_currency_name": "gem" if with_gems else "coin", "value": int(s["gem"]) if with_gems else int(s["coin"])})
	changed.emit()
	return 0


func equip(id: String) -> void:
	if is_owned(id):
		equipped = id
		_save()
		changed.emit()


# ---------------- ELMAS KAZAN (reklam turu) ----------------
func now() -> float:
	return Time.get_unix_time_from_system()


func cooldown_left() -> int:
	var left := cd_until - now()
	if left > COOLDOWN + 5.0:              # cihaz saati geri alınmış: en fazla 2 saat beklet
		cd_until = now() + COOLDOWN
		_save()
		left = COOLDOWN
	return maxi(0, int(ceil(left)))


func can_watch() -> bool:
	return cooldown_left() == 0


func _roll() -> int:
	var r := randi() % 100
	var acc := 0
	for e in GEM_TABLE:
		acc += int(e[1])
		if r < acc:
			return int(e[0])
	return 1


# Reklam izlendi: elmas verir, turu ilerletir. Döner: kazanılan elmas (0 = sayaç varken çağrılmış).
func gem_ad_done() -> int:
	if not can_watch():
		return 0
	var n := _roll()
	var last := ad_count + 1 >= ROUND_ADS
	if last and n < ROUND_MIN_LAST:
		n = ROUND_MIN_LAST
	ad_count += 1
	if ad_count >= ROUND_ADS:
		ad_count = 0
		cd_until = now() + COOLDOWN
	gems += n
	_save()
	Track.event("earn_virtual_currency", {"virtual_currency_name": "gem", "value": n})
	changed.emit()
	return n
