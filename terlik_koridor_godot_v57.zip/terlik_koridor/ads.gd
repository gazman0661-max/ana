extends Node
## REKLAM KÖPRÜSÜ (autoload: "Ads")  |  LevelPlay (ironSource + Unity Ads mediation)
## Android'de LevelPlayAds eklentisini kullanır. Editörde / PC'de eklenti yoktur,
## bu yüzden "stub" modunda çalışır: reklam hemen "izlenmiş" sayılır, sahte banner çizilir.

signal banner_height_changed(h: float)   # banner'ın oyunun üstüne bindiği yükseklik (720 genişlikli oyun koordinatı)
signal rewarded_earned                   # oyuncu ödüllü reklamı tamamladı (kapanıştan SONRA da gelebilir)
signal rewarded_closed                   # ödüllü reklam kapandı ya da gösterilemedi
signal interstitial_done                 # geçiş reklamı kapandı (ya da gösterilemedi) -> oyun devam etsin
signal region_resolved                   # internetten ülke bulundu (ya da bulunamadı); GDPR kararı artık net

const U = preload("res://fx_util.gd")
const PLUGIN_NAME := "LevelPlayAds"

# >>> LevelPlay panelinden al: Setup > Ad Units (app key ve 3 ad unit id) <<<
const APP_KEY := "2734447fd"
const BANNER_ID := "49c6c5wjz2gagjlb"
# Geçiş reklamı (Interstitial ad unit). Boş bırakılırsa geçiş reklamı kapanır.
const INTERSTITIAL_ID := "b4n74kzvfdds7wls"
const REWARDED_ID := "2eiwf0yysehblsw1"

const STUB_BANNER_PX := 100.0            # editörde sahte banner yüksekliği (oyun koordinatı)
const GAME_W := 720.0
const GAME_H := 1280.0

var is_stub := true
var banner_h := 0.0
var banner_total := 0.0     # banner'in TOPLAM yuksekligi (oyun koordinati); HUD ekranin ustunde bunun altina yerlesir
var rewarded_ready := false
var interstitial_ready := false

var _p: Object = null
var _started := false

# ---- Bölge (GDPR): cihaz diline DEĞİL, IP'ye göre ülke. Ücretsiz, anahtarsız servisler sırayla denenir.
const GEO_URLS := [
	"https://api.country.is/",
	"https://get.geojs.io/v1/ip/country.json",
	"https://ipapi.co/country/",
]
var geo_done := false

# ---- Geçiş reklamı sayacı (diske yazılır, uygulama kapansa da kaybolmaz). Kazanılan VE kaybedilen bölümler sayılır.
const STATS_PATH := "user://terlik_ads.cfg"
var levels_since_ad := 0
var stat := {"wins": 0, "losses": 0, "interstitials": 0, "rewarded": 0}

# ---- "Reklam bulunamadı" penceresi
var popup_open := false
var _popup_layer: CanvasLayer = null
var _popup_title: Label = null
var _popup_body: Label = null
var _popup_retry_btn: Button = null
var _popup_retry: Callable = Callable()
var _popup_wait := 0.0


func _ready() -> void:
	set_process(false)
	_load_stats()
	region_resolved.connect(_on_region_resolved)
	_geo_lookup()
	if OS.get_name() == "Android" and Engine.has_singleton(PLUGIN_NAME):
		is_stub = false
		_p = Engine.get_singleton(PLUGIN_NAME)
		_p.connect("init_failed", func(msg: String): push_warning("LevelPlay init hatası: " + msg))
		_p.connect("banner_loaded", _on_banner_loaded)
		_p.connect("banner_failed", _on_banner_failed)
		_p.connect("rewarded_ready", func(): rewarded_ready = true)
		_p.connect("rewarded_unavailable", func(): rewarded_ready = false)
		_p.connect("rewarded_earned", _emit_earned)
		_p.connect("rewarded_closed", func(): rewarded_closed.emit())
		_p.connect("interstitial_ready", func(): interstitial_ready = true)
		_p.connect("interstitial_unavailable", func(): interstitial_ready = false)
		_p.connect("interstitial_closed", _on_interstitial_closed)
		# Reklam SDK'sı kullanıcı Kullanım Şartları/Gizlilik'i kabul edene kadar BAŞLATILMAZ (consent.gd -> Ads.start()).
		if U.get_setting("terms_ok", false):
			start()
	else:
		is_stub = true
		# Editör/PC: sahte reklam. Android'de eklenti yüklenmediyse reklam YOK -> bedava ödül verilmez,
		# "Reklam bulunamadı" penceresi çıkar.
		var dev := OS.get_name() != "Android"
		rewarded_ready = dev
		interstitial_ready = dev and INTERSTITIAL_ID != ""
		# Editörde sahte banner yeri ayrılır; telefonda eklenti yoksa oyuncu hiçbir şey görmesin.
		banner_h = STUB_BANNER_PX if (OS.get_name() != "Android" and not Iap.has_no_ads()) else 0.0
		banner_total = banner_h


# Reklam SDK'sını başlat (onay verildikten sonra çağrılır; birden fazla çağrılsa da bir kez çalışır).
func start() -> void:
	Track.refresh_consent()
	if _started or is_stub or _p == null:
		return
	_started = true
	if not geo_done and U.get_str("geo_cc", "") == "":      # ilk açılış: ülke bulunana kadar (en çok 4 sn) bekle
		await _wait_geo(4.0)
	# GDPR bölgesindeyse kullanıcının seçimi (varsayılan: rıza YOK) init'ten ÖNCE LevelPlay'e verilir.
	if U.gdpr_region() and _p.has_method("setGdprConsent"):
		_p.setGdprConsent(U.get_setting("gdpr_consent", false))
	# Reklamsız paket: banner kimliği boş gönderilir (Java tarafı banner oluşturmaz)
	_p.initAds(APP_KEY, "" if Iap.has_no_ads() else BANNER_ID, INTERSTITIAL_ID, REWARDED_ID)


# Banner piksel yüksekliğini oyun koordinatına çevirir.
# Proje 720x1280 + aspect "expand" (screen.gd): ekran daha uzunsa oyun alanının üstünde fazlalık olur,
# banner önce oraya biner; sadece onu aşan kısım oyunun üstünü kapatır.
func _on_banner_loaded(h_px: int) -> void:
	if Iap.has_no_ads():
		apply_no_ads()
		return
	var s := DisplayServer.window_get_size()
	var sc := float(s.x) / Scr.size.x          # 1 oyun birimi kaç piksel
	# Ekran uzunsa üstteki fazlalık (Scr.off.y) banner'a yer olur; sadece taşan kısım oyunu kapatır.
	banner_total = float(h_px) / sc
	banner_h = maxf(0.0, banner_total - Scr.off.y)
	banner_height_changed.emit(banner_h)


# Banner yüklenemedi: yer ayırma, yazı yok; yüklenince banner_loaded ile geri gelir.
func _on_banner_failed() -> void:
	banner_h = 0.0
	banner_total = 0.0
	banner_height_changed.emit(banner_h)


# Reklamsız paket alındı (ya da açılışta zaten sahip): bannerı gizle, yer ayırmayı kaldır.
func apply_no_ads() -> void:
	banner_h = 0.0
	banner_total = 0.0
	if not is_stub and _p != null and _p.has_method("setBannerVisible"):
		_p.setBannerVisible(false)
	banner_height_changed.emit(banner_h)


func _on_interstitial_closed() -> void:
	interstitial_ready = false
	interstitial_done.emit()


func _emit_earned() -> void:
	stat["rewarded"] = int(stat["rewarded"]) + 1
	_save_stats()
	rewarded_earned.emit()


# Ödüllü reklamı göster. true = gösteriliyor (sonucu rewarded_earned sinyali bildirir).
# Reklam yoksa false döner ve "Reklam bulunamadı / Tekrar dene" penceresi açılır;
# "Tekrar dene" ile reklam hazır olunca `retry` çağrılır (aynı işlem yeniden başlar).
func show_rewarded(retry: Callable = Callable()) -> bool:
	if is_stub and rewarded_ready:           # editör: sahte reklam, 0.6 sn sonra ödül
		get_tree().create_timer(0.6).timeout.connect(func():
			_emit_earned()
			rewarded_closed.emit())
		return true
	if is_stub or not rewarded_ready:
		show_no_ad_popup(retry)
		return false
	rewarded_ready = false
	_p.showRewarded()
	return true


# Geçiş reklamını göster. true = gösteriliyor (bitince interstitial_done gelir).
# false = hazır değil, oyun beklemeden devam etsin (sayaç korunur, bir sonraki fırsatta gösterilir).
func show_interstitial() -> bool:
	if INTERSTITIAL_ID == "" or Iap.has_no_ads():     # reklamsız paket: geçiş reklamı yok (ödüllü reklam kalır)
		return false
	if is_stub:
		if not interstitial_ready:
			return false
		_count_interstitial()
		get_tree().create_timer(0.6).timeout.connect(func(): interstitial_done.emit())
		return true
	if not interstitial_ready:
		return false
	interstitial_ready = false
	_count_interstitial()
	_p.showInterstitial()
	return true


func _count_interstitial() -> void:
	levels_since_ad = 0
	stat["interstitials"] = int(stat["interstitials"]) + 1
	_save_stats()


# ---------------- SAYAÇ (kazanılan + kaybedilen bölümler) ----------------
# counts_for_ad=false: ilk (reklamsız) bölümler; istatistiğe yazılır ama geçiş reklamı sayacını artırmaz.
func note_level_end(won: bool, counts_for_ad: bool) -> void:
	stat["wins" if won else "losses"] = int(stat["wins" if won else "losses"]) + 1
	if counts_for_ad:
		levels_since_ad += 1
	_save_stats()


# Kayıptan sonra devam edildi (reklam/coin): aynı bölüm iki kez sayılmasın.
func undo_loss(counts_for_ad: bool) -> void:
	stat["losses"] = maxi(0, int(stat["losses"]) - 1)
	if counts_for_ad:
		levels_since_ad = maxi(0, levels_since_ad - 1)
	_save_stats()


func interstitial_due(every: int) -> bool:
	return levels_since_ad >= every


# Ödüllü reklam izlendi: geçiş reklamı yerine sayılır.
func reset_counter() -> void:
	levels_since_ad = 0
	_save_stats()


func _load_stats() -> void:
	var cf := ConfigFile.new()
	if cf.load(STATS_PATH) != OK:
		return
	levels_since_ad = int(cf.get_value("a", "since", 0))
	for k in stat.keys():
		stat[k] = int(cf.get_value("a", k, 0))


func _save_stats() -> void:
	var cf := ConfigFile.new()
	cf.set_value("a", "since", levels_since_ad)
	for k in stat.keys():
		cf.set_value("a", k, int(stat[k]))
	cf.save(STATS_PATH)


# ---------------- BÖLGE (GDPR) - IP'den ülke, ücretsiz ----------------
func _geo_lookup() -> void:
	for url in GEO_URLS:
		var http := HTTPRequest.new()
		http.timeout = 3.0
		add_child(http)
		if http.request(url) != OK:
			http.queue_free()
			continue
		var res: Array = await http.request_completed
		http.queue_free()
		if int(res[0]) != HTTPRequest.RESULT_SUCCESS or int(res[1]) != 200:
			continue
		var cc := _parse_cc((res[3] as PackedByteArray).get_string_from_utf8())
		if cc != "":
			U.set_str("geo_cc", cc)          # bir sonraki açılışta internet yoksa bu kullanılır
			break
	geo_done = true
	region_resolved.emit()


func _parse_cc(body: String) -> String:
	body = body.strip_edges()
	var cc := ""
	if body.begins_with("{"):
		var j: Variant = JSON.parse_string(body)
		if j is Dictionary:
			cc = str(j.get("country", j.get("country_code", "")))
	elif body.length() == 2:
		cc = body
	cc = cc.strip_edges().to_upper()
	if cc.length() == 2 and cc.unicode_at(0) >= 65 and cc.unicode_at(0) <= 90 and cc.unicode_at(1) >= 65 and cc.unicode_at(1) <= 90:
		return cc
	return ""


func _wait_geo(sec: float) -> void:
	var t := 0.0
	while not geo_done and t < sec:
		await get_tree().process_frame
		t += get_process_delta_time()


func _on_region_resolved() -> void:
	Track.refresh_consent()
	if _started and not is_stub and _p != null and U.gdpr_region() and _p.has_method("setGdprConsent"):
		_p.setGdprConsent(U.get_setting("gdpr_consent", false))


# ---------------- "REKLAM BULUNAMADI" PENCERESİ ----------------
func show_no_ad_popup(retry: Callable = Callable()) -> void:
	if popup_open:
		return
	_build_popup()
	_popup_retry = retry
	_popup_wait = 0.0
	_popup_title.text = Loc.t("ad_none_title")
	_popup_body.text = Loc.t("ad_none_body")
	_popup_retry_btn.disabled = false
	_popup_layer.visible = true
	popup_open = true
	set_process(false)


func _sb(c: Color, border: Color, radius: int, bw: int, margin: float) -> StyleBoxFlat:
	var b := StyleBoxFlat.new()
	b.bg_color = c
	b.set_corner_radius_all(radius)
	b.set_border_width_all(bw)
	b.border_color = border
	b.content_margin_left = margin
	b.content_margin_right = margin
	b.content_margin_top = margin
	b.content_margin_bottom = margin
	return b


func _mk_btn(txt_key: String, c: Color, border: Color, font: Font) -> Button:
	var b := Button.new()
	b.text = Loc.t(txt_key)
	b.custom_minimum_size = Vector2(0.0, 92.0)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", 32)
	b.add_theme_color_override("font_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", Color.WHITE)
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.6))
	var n := _sb(c, border, 28, 6, 8.0)
	var d := _sb(c.darkened(0.2), border, 28, 6, 8.0)
	var dis := _sb(c.darkened(0.35), border, 28, 6, 8.0)
	b.add_theme_stylebox_override("normal", n)
	b.add_theme_stylebox_override("hover", n)
	b.add_theme_stylebox_override("pressed", d)
	b.add_theme_stylebox_override("disabled", dis)
	b.add_theme_stylebox_override("focus", n)
	return b


func _build_popup() -> void:
	if _popup_layer != null:
		return
	var font := U.make_font()
	_popup_layer = CanvasLayer.new()
	_popup_layer.layer = 100
	add_child(_popup_layer)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.62)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP          # arkadaki oyuna tıklama geçmesin
	_popup_layer.add_child(dim)
	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	dim.add_child(center)
	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(580.0, 0.0)
	panel.add_theme_stylebox_override("panel", _sb(Color(0.99, 0.94, 0.80), Color(0.35, 0.13, 0.05), 30, 7, 34.0))
	center.add_child(panel)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 22)
	panel.add_child(vb)
	_popup_title = Label.new()
	_popup_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_popup_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_popup_title.add_theme_font_override("font", font)
	_popup_title.add_theme_font_size_override("font_size", 42)
	_popup_title.add_theme_color_override("font_color", Color(0.78, 0.2, 0.1))
	vb.add_child(_popup_title)
	_popup_body = Label.new()
	_popup_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_popup_body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_popup_body.add_theme_font_override("font", font)
	_popup_body.add_theme_font_size_override("font_size", 27)
	_popup_body.add_theme_color_override("font_color", Color(0.25, 0.12, 0.06))
	vb.add_child(_popup_body)
	var hb := HBoxContainer.new()
	hb.add_theme_constant_override("separation", 18)
	vb.add_child(hb)
	var close_btn := _mk_btn("ad_close", Color(0.86, 0.28, 0.22), Color(0.35, 0.08, 0.05), font)
	close_btn.pressed.connect(_on_popup_close)
	hb.add_child(close_btn)
	_popup_retry_btn = _mk_btn("ad_retry", Color(0.22, 0.78, 0.30), Color(0.08, 0.30, 0.12), font)
	_popup_retry_btn.pressed.connect(_on_popup_retry)
	hb.add_child(_popup_retry_btn)
	_popup_layer.visible = false


func _on_popup_close() -> void:
	Sfx.play("click")
	_close_popup(false)


func _on_popup_retry() -> void:
	Sfx.play("click")
	if rewarded_ready:
		_close_popup(true)
		return
	# Eklenti reklamı kendiliğinden yeniden yüklemeyi dener; birkaç sn bekleyip hazır olursa devam ederiz.
	_popup_wait = 6.0
	_popup_title.text = Loc.t("ad_retrying")
	_popup_body.text = ""
	_popup_retry_btn.disabled = true
	set_process(true)


func _process(delta: float) -> void:
	if not popup_open or _popup_wait <= 0.0:
		set_process(false)
		return
	_popup_wait -= delta
	if rewarded_ready:
		_close_popup(true)
	elif _popup_wait <= 0.0:
		_popup_title.text = Loc.t("ad_none_title")
		_popup_body.text = Loc.t("ad_none_body")
		_popup_retry_btn.disabled = false
		set_process(false)


func _close_popup(run_retry: bool) -> void:
	popup_open = false
	_popup_wait = 0.0
	set_process(false)
	if _popup_layer != null:
		_popup_layer.visible = false
	if run_retry and _popup_retry.is_valid():
		_popup_retry.call_deferred()


# Kişiselleştirilmiş reklam rızasını kaydeder ve LevelPlay'e iletir (Ayarlar > Reklam Rızasını Yönet).
func set_gdpr_consent(on: bool) -> void:
	U.set_setting("gdpr_consent", on)
	Track.refresh_consent()
	if is_stub or _p == null or not _p.has_method("setGdprConsent"):
		return
	_p.setGdprConsent(on)
