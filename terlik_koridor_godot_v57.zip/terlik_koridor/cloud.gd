extends Node
## PLAY GAMES OTURUMU + BULUT KAYDI (autoload "Cloud") — Android köprüsü: PlayGamesBridgePlugin.java
##
## NE SENKRONLANIR (tek bir JSON "blob", PGS Saved Games'te "terlik_save_v1"):
##   bölüm ilerlemesi (+ "sıfırla" sayacı), sahip olunan / takılı terlikler, günlük ödül durumu + günlük görevler,
##   işlenmiş satın alma kayıtları (Iap.done), ve coin / elmas / güç-up BAKİYELERİ.
## NE SENKRONLANMAZ: ses/dil ayarları, reklam sayaçları (cihaza özel); "reklamsız" yetkisi (Google Play'den gelir).
##
## BAKİYELER (coin, elmas, güç-up) — "cihaz sayaçları" yöntemi:
##   Her cihaz kendi için iki sürekli artan sayaç tutar: kazanılan (e) ve harcanan (s). Bakiye = tüm cihazların (e - s) toplamı.
##   Birleştirme = cihaz başına sayaçların büyüğünü almak (sırası/tekrarı önemsiz, hiçbir kazanç ikiye katlanmaz, kaybolmaz).
##   Yerel bakiye değişimi (kazanç / harcama) kontrol noktalarında fark alınarak sayaçlara işlenir (_checkpoint).
##
## HESAP DEĞİŞİMİ (A hesabından B hesabına):
##   Yerel durum bir oyuncu kimliğine "bağlanır" (bound_id). Başka bir kimlikle oturum açılırsa A'nın durumu cihazda
##   arşivlenir (user://acc_*.json), B'nin arşivi (varsa) ya da SIFIR durum yüklenir. A'nın ilerlemesi B'ye ASLA karışmaz;
##   A'ya geri dönülünce arşiv + A'nın bulutu birleştirilir.
##   Hiç bağlanmamış (misafir) ilerleme ilk girişte hesaba katılır; hem cihazda hem bulutta ilerleme varsa oyuncuya sorulur.
##
## GÜVENLİK AĞLARI: bulut verisi okunamazsa ÜZERİNE YAZILMAZ; daha yeni şema (v) ise yazılmaz ("uygulamayı güncelle");
##   oyun sahnesindeyken yerel durum değiştirilmez (sadece buluta yazılır); veri geri yüklenmiş cihazda bakiye ikiye katlanmaz.

const U = preload("res://fx_util.gd")

signal applied                 # bulut / hesap durumu yerele uygulandı (menü cüzdanı + bölüm yenilensin)
signal status_changed
signal choice_needed           # ilk bağlanmada hem cihazda hem bulutta ilerleme var -> oyuncuya sor
signal account_switched         # başka bir Play Games hesabına geçildi (yerel durum o hesaba göre yüklendi)

enum St { OFF, SIGNED_OUT, SIGNING_IN, IDLE, SYNCING, ERROR, NEED_UPDATE, CHOICE }

const PLUGIN_NAME := "TerlikGames"
const CFG := "user://terlik_cloud.cfg"
const SCHEMA := 1
const CUR := ["coin", "gem", "aim", "slow", "double"]
const POLL_SEC := 5.0
const MIN_GAP := 12.0                 # iki otomatik eşitleme arası en az süre
const PULL_SEC := 180.0               # menüdeyken periyodik "bulutta yeni var mı" kontrolü
const OP_TIMEOUT := 45.0

var status := St.OFF
var signed_in := false
var player_id := ""
var player_name := ""
var bound_id := ""                    # yerel durumun ait olduğu oyuncu ("" = misafir / hiç bağlanmadı)
var bound_name := ""
var dev_id := ""
var last_ok := 0                      # son başarılı eşitleme (unix)
var in_game := false
var dirty := false
var is_stub := false

var my_e: Dictionary = {}
var my_s: Dictionary = {}
var cp: Dictionary = {}               # son kontrol noktasındaki bakiye
var known_dev: Dictionary = {}        # diğer cihazların sayaçları (son birleşmeden)
var epoch := 0                        # "Baştan başla" sayacı: yüksek olan kazanır
var eq_t := 0
var last_eq := ""
var restored := false                 # başka cihaza yedekten geri yüklenmiş kopya
var restore_base: Dictionary = {}

var _p: Object = null
var _aid := ""
var _op := ""                         # "load" | "save" | "resolve" | ""
var _op_pid := ""
var _op_t := 0.0
var _poll_t := 0.0
var _pull_t := 0.0
var _gap := 999.0
var _next_sync := 0.0
var _err_wait := 0.0
var _err_n := 0
var _fp := ""
var _conflict_n := 0
var _sync_again := false
var _auth_started := false
var _signin_t := -1.0
var _deferred_auth: Array = []        # oyun sahnesindeyken gelen hesap değişimi: [pid, name]
var _choice_local: Dictionary = {}
var _choice_cloud: Dictionary = {}


func _ready() -> void:
	_load_cfg()
	if OS.get_name() == "Android":
		if Engine.has_singleton(PLUGIN_NAME):
			_p = Engine.get_singleton(PLUGIN_NAME)
			_p.connect("auth_changed", _on_auth)
			_p.connect("cloud_loaded", _on_cloud_loaded)
			_p.connect("cloud_saved", _on_cloud_saved)
			_p.connect("cloud_conflict", _on_cloud_conflict)
			status = St.SIGNED_OUT
	else:
		is_stub = true
		status = St.SIGNED_OUT
	_fp = _fingerprint()


func _notification(what: int) -> void:
	if status == St.OFF:
		return
	if what == NOTIFICATION_APPLICATION_PAUSED:
		if signed_in and (dirty or _fingerprint() != _fp):
			dirty = true
			sync_now("pause")
	elif what == NOTIFICATION_APPLICATION_RESUMED:
		if signed_in and Time.get_unix_time_from_system() - last_ok > 60.0:
			_next_sync = 1.0
			dirty = true


# ---------------- DIŞ API ----------------
func available() -> bool:
	return status != St.OFF


func set_in_game(v: bool) -> void:
	in_game = v
	if v or status == St.OFF:
		return
	if not _deferred_auth.is_empty():
		var d := _deferred_auth
		_deferred_auth = []
		_on_auth(true, String(d[0]), String(d[1]))
	elif signed_in:
		dirty = true
		_next_sync = 0.8              # menüye dönünce bulutu çek / uygula


# Her yerel değişiklikten sonra çağrılabilir (zorunlu değil: periyodik parmak izi kontrolü de var)
func mark_dirty(urgent := false) -> void:
	if status == St.OFF:
		return
	dirty = true
	if urgent:
		_next_sync = 1.5
	elif _next_sync <= 0.0:
		_next_sync = 6.0


func sign_in() -> void:
	if status == St.OFF or signed_in:
		return
	if is_stub:
		_on_auth(true, _stub_pid(), "Editör " + _stub_pid())
		return
	_set_status(St.SIGNING_IN)
	_signin_t = 25.0
	_p.signIn()


func sync_now(_reason := "") -> void:
	if not _sync_allowed():
		return
	if _op != "":
		_sync_again = true
		return
	_conflict_n = 0
	_op = "load"
	_op_pid = player_id
	_op_t = 0.0
	_set_status(St.SYNCING)
	if is_stub:
		_stub_load()
	else:
		_p.cloudLoad()


# "Baştan başla" (Ayarlar): bölüm 1'e döner; sayaç artırılır ki bulut birleştirmesi eski bölümü geri getirmesin
func level_reset() -> void:
	epoch += 1
	Daily.set_level(1)
	_save_cfg()
	_fp = ""
	mark_dirty(true)


func status_key() -> String:
	match status:
		St.OFF:
			return "cl_off"
		St.SIGNED_OUT:
			return "cl_out"
		St.SIGNING_IN:
			return "cl_signing"
		St.IDLE:
			return "cl_ok"
		St.SYNCING:
			return "cl_sync"
		St.ERROR:
			return "cl_err"
		St.NEED_UPDATE:
			return "cl_upd"
		St.CHOICE:
			return "cl_choice"
	return "cl_off"


# Seçim penceresi için iki tarafın özeti
func summary(blob: Dictionary) -> Dictionary:
	return {"lv": int(blob.get("lv", 1)), "coin": _blob_bal(blob, "coin"), "gem": _blob_bal(blob, "gem"), "skins": (blob.get("own", []) as Array).size()}


func choice_local_summary() -> Dictionary:
	return summary(_choice_local)


func choice_cloud_summary() -> Dictionary:
	return summary(_choice_cloud)


# "merge" = birleştir (önerilen) | "cloud" = bu cihazdakini bırak, hesaptakini kullan
func choose(mode: String) -> void:
	if status != St.CHOICE:
		return
	var local := _choice_local
	var cloud := _choice_cloud
	_choice_local = {}
	_choice_cloud = {}
	var merged: Dictionary
	if mode == "cloud":
		for c in CUR:
			my_e[c] = 0
			my_s[c] = 0
		merged = cloud.duplicate(true)
	else:
		merged = merge(local, cloud)
	_finish_merge(merged, cloud)


# ---------------- OTURUM ----------------
func _stub_pid() -> String:
	var e := OS.get_environment("TERLIK_PLAYER")
	return e if e != "" else "editor_a"


func _on_auth(signed: bool, pid: String, pname: String) -> void:
	_signin_t = -1.0
	if not (signed and pid != ""):
		signed_in = false
		player_id = ""
		player_name = ""
		if status != St.OFF and status != St.CHOICE:
			_set_status(St.SIGNED_OUT)
		return
	# Oyun sahnesindeyken hesap değişirse yerel durumu ellemeyiz; menüye dönünce işlenir (arada senkron da durur)
	if in_game and bound_id != "" and bound_id != pid:
		_deferred_auth = [pid, pname]
		signed_in = false
		return
	player_id = pid
	player_name = pname
	signed_in = true
	if bound_id != "" and bound_id != pid:
		_switch_account(pid)
		account_switched.emit()
	if status == St.CHOICE:
		_choice_local = {}
		_choice_cloud = {}
	_set_status(St.IDLE)
	dirty = true
	if _op != "":
		_sync_again = true            # uçuştaki işlem eski hesaba ait olabilir; sonucu atılır, yeniden eşitlenir
	else:
		sync_now("auth")


# Hesap değişti: eski hesabın yerel durumunu arşivle, yenisinin arşivini (yoksa sıfır durum) yükle
func _switch_account(new_pid: String) -> void:
	restored = false
	restore_base = {}
	var cur := export_blob()
	_write_json(_acc_path(bound_id), cur)
	var arc := _read_json(_acc_path(new_pid))
	var target: Dictionary = arc if (not arc.is_empty() and arc.has("dev")) else _fresh_blob()
	for c in CUR:
		my_e[c] = 0
		my_s[c] = 0
	apply_blob(target)
	bound_id = new_pid
	bound_name = player_name
	_save_cfg()


func _sync_allowed() -> bool:
	if not signed_in or not _deferred_auth.is_empty():
		return false
	return status != St.OFF and status != St.NEED_UPDATE and status != St.CHOICE


# ---------------- EŞİTLEME ----------------
func _on_cloud_loaded(ok: bool, data: String, err: String) -> void:
	if _op != "load":
		return
	_op = ""
	if _op_pid != player_id:
		_restart()
		return
	if not ok:
		_fail("load: " + err)
		return
	var cloud := {}
	if data != "":
		var v: Variant = JSON.parse_string(data)
		if not (v is Dictionary) or not (v as Dictionary).has("dev"):
			_fail("bozuk bulut verisi")          # üzerine YAZMA
			return
		cloud = v
		if int(cloud.get("v", 0)) > SCHEMA:
			_set_status(St.NEED_UPDATE)           # daha yeni sürümün verisi: eski sürüm dokunmaz
			return
	_process_cloud(cloud)


func _process_cloud(cloud: Dictionary) -> void:
	if in_game:
		# Oyun içindeyken yerel durum değişmez: sadece (birleşmiş hali) buluta yazılır. Misafirse bekler.
		if bound_id == "":
			_set_status(St.IDLE)
			return
		var merged_g := merge(export_blob(), cloud)
		_upload_if_changed(merged_g, cloud)
		return
	# Geri yüklenmiş kopya: bulut doluysa kopyadaki bakiye atılır (zaten bulutta var), boşsa sahiplenilir
	if restored:
		if cloud.is_empty():
			for c in CUR:
				my_e[c] = int(my_e.get(c, 0)) + int(restore_base.get(c, 0))
		restored = false
		restore_base = {}
		_save_cfg()
	var local := export_blob()
	if bound_id == "" and not cloud.is_empty() and _has_progress(cloud) and _has_progress(local):
		_choice_local = local
		_choice_cloud = cloud
		_set_status(St.CHOICE)
		choice_needed.emit()
		return
	_finish_merge(merge(local, cloud), cloud)


func _finish_merge(merged: Dictionary, cloud: Dictionary) -> void:
	apply_blob(merged)
	bound_id = player_id
	bound_name = player_name
	_save_cfg()
	_upload_if_changed(merged, cloud)


func _upload_if_changed(merged: Dictionary, cloud: Dictionary) -> void:
	if not cloud.is_empty() and _core(merged) == _core(cloud):
		_done_ok()
		return
	merged["t"] = int(Time.get_unix_time_from_system())
	_op = "save"
	_op_pid = player_id
	_op_t = 0.0
	_set_status(St.SYNCING)
	if is_stub:
		_stub_save(JSON.stringify(merged))
	else:
		_p.cloudSave(JSON.stringify(merged))


func _on_cloud_saved(ok: bool, err: String) -> void:
	if _op != "save" and _op != "resolve":
		return
	_op = ""
	if _op_pid != player_id:
		_restart()
		return
	if not ok:
		_fail("save: " + err)
		return
	_done_ok()


# İki cihaz aynı anda yazmış: iki sürümü de GDScript'te birleştirip geri gönder
func _on_cloud_conflict(server: String, local_s: String) -> void:
	if _op == "":
		return
	if _op_pid != player_id:
		_op = ""
		_restart()
		return
	_conflict_n += 1
	if _conflict_n > 5:
		_op = ""
		_fail("sürekli çakışma")
		return
	var a := _parse_blob(server)
	var b := _parse_blob(local_s)
	if (a.has("__bad") or b.has("__bad")):
		_op = ""
		_fail("bozuk çakışma verisi")
		return
	if int(a.get("v", 0)) > SCHEMA or int(b.get("v", 0)) > SCHEMA:
		_op = ""
		_set_status(St.NEED_UPDATE)
		return
	var base := merge(a, b)
	var merged: Dictionary
	if in_game or bound_id == "":
		merged = merge(base, export_blob()) if bound_id != "" else base
	else:
		merged = merge(base, export_blob())
		apply_blob(merged)
		bound_id = player_id
		bound_name = player_name
		_save_cfg()
	merged["t"] = int(Time.get_unix_time_from_system())
	_op = "resolve"
	_op_t = 0.0
	if is_stub:
		_stub_save(JSON.stringify(merged))
	else:
		_p.cloudResolve(JSON.stringify(merged))


func _parse_blob(s: String) -> Dictionary:
	if s == "":
		return {}
	var v: Variant = JSON.parse_string(s)
	if v is Dictionary and (v as Dictionary).has("dev"):
		return v
	return {"__bad": true}


func _done_ok() -> void:
	last_ok = int(Time.get_unix_time_from_system())
	_err_n = 0
	_err_wait = 0.0
	_gap = 0.0
	_set_status(St.IDLE)
	dirty = _fingerprint() != _fp
	if dirty:
		_next_sync = 3.0
	if _sync_again:
		_sync_again = false
		_next_sync = 0.5
		dirty = true


func _fail(msg: String) -> void:
	push_warning("Cloud: " + msg)
	_op = ""
	_err_n += 1
	_err_wait = minf(300.0, 20.0 * pow(2.0, float(_err_n - 1)))
	_set_status(St.ERROR)


func _restart() -> void:
	_set_status(St.IDLE)
	_next_sync = 0.3
	dirty = true


func _set_status(s: int) -> void:
	if status == s:
		return
	status = s
	status_changed.emit()


# ---------------- DÖNGÜ ----------------
func _process(delta: float) -> void:
	if status == St.OFF:
		return
	# Kullanım Şartları kabul edilmeden Play Games oturumuna dokunulmaz
	if not _auth_started and U.get_setting("terms_ok", false):
		_auth_started = true
		if is_stub:
			_on_auth(true, _stub_pid(), "Editör " + _stub_pid())
		elif _p != null:
			_p.checkAuth()
	if _signin_t > 0.0:
		_signin_t -= delta
		if _signin_t <= 0.0 and status == St.SIGNING_IN:
			_set_status(St.SIGNED_OUT)
	if _op != "":
		_op_t += delta
		if _op_t > OP_TIMEOUT:
			_fail("zaman aşımı")
		return
	if not signed_in:
		return
	_gap += delta
	_poll_t += delta
	if _poll_t >= POLL_SEC:
		_poll_t = 0.0
		if _fingerprint() != _fp:
			mark_dirty(false)
	if status == St.ERROR:
		_err_wait -= delta
		if _err_wait <= 0.0:
			_set_status(St.IDLE)
			dirty = true
			_next_sync = 0.1
		return
	if not in_game:
		_pull_t += delta
		if _pull_t >= PULL_SEC:
			_pull_t = 0.0
			dirty = true
			_next_sync = maxf(_next_sync, 0.1)
	if _next_sync > 0.0:
		_next_sync -= delta
		if _next_sync <= 0.0 and dirty and _gap >= MIN_GAP:
			dirty = false
			sync_now("auto")
		elif _next_sync <= 0.0 and dirty:
			_next_sync = MIN_GAP - _gap + 0.1


# ---------------- BAKİYE / KONTROL NOKTASI ----------------
func _bal(cur: String) -> int:
	match cur:
		"coin":
			return Daily.get_coins()
		"gem":
			return Shop.gems
	return Daily.inv_count(cur)


func _set_bal(cur: String, n: int) -> void:
	match cur:
		"coin":
			Daily.set_coins(n)
		"gem":
			Shop.set_gems(n)
		_:
			Daily.set_inv(cur, n)


# Son kontrol noktasından beri olan bakiye farkını kazanç / harcama sayacına işler
func _checkpoint() -> void:
	for c in CUR:
		var b := _bal(c)
		var d := b - int(cp.get(c, b))
		if d > 0:
			my_e[c] = int(my_e.get(c, 0)) + d
		elif d < 0:
			my_s[c] = int(my_s.get(c, 0)) - d
		cp[c] = b
	if Shop.equipped != last_eq:
		last_eq = Shop.equipped
		eq_t = int(Time.get_unix_time_from_system())


func _fingerprint() -> String:
	var parts: Array = [Daily.get_coins(), Shop.gems, Daily.best_level(), Shop.owned.size(), Shop.equipped,
		Daily.last_claim, Daily.mask, Daily.q_day, str(Daily.q_prog), str(Daily.q_claimed), epoch, Iap.done.size()]
	for id in Daily.PU_IDS:
		parts.append(Daily.inv_count(id))
	return str(parts)


# ---------------- BLOB ----------------
func export_blob() -> Dictionary:
	_checkpoint()
	var dev: Dictionary = known_dev.duplicate(true)
	var mine := {}
	for c in CUR:
		mine[c] = [int(my_e.get(c, 0)), int(my_s.get(c, 0))]
	dev[dev_id] = mine
	var own: Array = Shop.owned.duplicate()
	own.sort()
	_fp = _fingerprint()
	return {
		"v": SCHEMA, "t": int(Time.get_unix_time_from_system()),
		"dev": dev,
		"lv": Daily.best_level(), "ep": epoch,
		"own": own, "eq": Shop.equipped, "et": eq_t,
		"d": Daily.cloud_export(),
		"iap": Iap.cloud_export(),
	}


func _fresh_blob() -> Dictionary:
	var mine := {}
	for c in CUR:
		mine[c] = [0, 0]
	return {
		"v": SCHEMA, "t": 0, "dev": {dev_id: mine},
		"lv": 1, "ep": 0, "own": ["classic"], "eq": "classic", "et": 0,
		"d": {"lc": -1, "ws": -1, "mk": 0, "lw": -100000, "qd": -1, "qt": [], "qg": [], "qp": [], "qc": [], "qk": []},
		"iap": Iap.cloud_export(),
	}


func _blob_bal(blob: Dictionary, cur: String) -> int:
	var t := 0
	var dev: Dictionary = blob.get("dev", {})
	for did in dev:
		var pr: Array = (dev[did] as Dictionary).get(cur, [0, 0])
		t += int(pr[0]) - int(pr[1])
	return maxi(0, t)


func _has_progress(blob: Dictionary) -> bool:
	if int(blob.get("lv", 1)) > 1 or (blob.get("own", []) as Array).size() > 1:
		return true
	var dev: Dictionary = blob.get("dev", {})
	for did in dev:
		for c in CUR:
			var pr: Array = (dev[did] as Dictionary).get(c, [0, 0])
			if int(pr[0]) > 0:
				return true
	return false


# Oyun durumunu verilen (birleşmiş) blob ile DEĞİŞTİRİR. Bakiye = sayaç toplamı.
func apply_blob(m: Dictionary) -> void:
	var dev: Dictionary = m.get("dev", {})
	if not dev.has(dev_id):
		var z := {}
		for c in CUR:
			z[c] = [0, 0]
		dev[dev_id] = z
	var mine: Dictionary = dev[dev_id]
	for c in CUR:
		var pr: Array = mine.get(c, [0, 0])
		var e := int(pr[0])
		var s := int(pr[1])
		var total := 0
		for did in dev:
			var q: Array = (dev[did] as Dictionary).get(c, [0, 0])
			total += int(q[0]) - int(q[1])
		if total < 0:
			e += -total                  # iki cihaz aynı parayı harcadıysa eksiye düşme: farkı bu cihaza kazanç yaz
			total = 0
		mine[c] = [e, s]
		my_e[c] = e
		my_s[c] = s
		_set_bal(c, total)
		cp[c] = total
	dev[dev_id] = mine
	m["dev"] = dev
	known_dev = dev.duplicate(true)
	known_dev.erase(dev_id)
	epoch = int(m.get("ep", 0))
	Daily.set_level(maxi(1, int(m.get("lv", 1))))
	Shop.cloud_import(m.get("own", ["classic"]), String(m.get("eq", "classic")))
	last_eq = Shop.equipped
	eq_t = int(m.get("et", 0))
	Daily.cloud_import(m.get("d", {}))
	Iap.cloud_import(m.get("iap", []))
	_save_cfg()
	_fp = _fingerprint()
	Daily.external_change.emit()
	applied.emit()


# İki blob'u BİRLEŞTİRİR (sıra / tekrar fark etmez: değişmeli, birleşmeli, idempotent)
func merge(a: Dictionary, b: Dictionary) -> Dictionary:
	if a.is_empty():
		return b.duplicate(true)
	if b.is_empty():
		return a.duplicate(true)
	var m := {"v": SCHEMA, "t": maxi(int(a.get("t", 0)), int(b.get("t", 0)))}
	# cihaz sayaçları: cihaz başına en büyük değerler
	var dev := {}
	for src in [a.get("dev", {}), b.get("dev", {})]:
		for did in src:
			var cur_d: Dictionary = dev.get(did, {})
			var sd: Dictionary = src[did]
			for c in CUR:
				var pr: Array = sd.get(c, [0, 0])
				var old: Array = cur_d.get(c, [0, 0])
				cur_d[c] = [maxi(int(old[0]), int(pr[0])), maxi(int(old[1]), int(pr[1]))]
			dev[did] = cur_d
	m["dev"] = dev
	# bölüm: "sıfırla" sayacı yüksek olan kazanır; eşitse en yüksek bölüm
	var ea := int(a.get("ep", 0))
	var eb := int(b.get("ep", 0))
	if ea > eb:
		m["ep"] = ea
		m["lv"] = int(a.get("lv", 1))
	elif eb > ea:
		m["ep"] = eb
		m["lv"] = int(b.get("lv", 1))
	else:
		m["ep"] = ea
		m["lv"] = maxi(int(a.get("lv", 1)), int(b.get("lv", 1)))
	# terlikler: birleşim; takılı olan: en son değiştirilen
	m["own"] = _union(a.get("own", []), b.get("own", []))
	if not (m["own"] as Array).has("classic"):
		(m["own"] as Array).append("classic")
		(m["own"] as Array).sort()
	var ta := int(a.get("et", 0))
	var tb := int(b.get("et", 0))
	var pick_a := ta > tb or (ta == tb and String(a.get("eq", "classic")) <= String(b.get("eq", "classic")))
	m["et"] = maxi(ta, tb)
	m["eq"] = String(a.get("eq", "classic")) if pick_a else String(b.get("eq", "classic"))
	if not (m["own"] as Array).has(m["eq"]):
		m["eq"] = "classic"
	m["iap"] = _union(a.get("iap", []), b.get("iap", []))
	m["d"] = _merge_daily(a.get("d", {}), b.get("d", {}))
	return m


func _union(x, y) -> Array:
	var seen := {}
	for v in x:
		seen[String(v)] = true
	for v in y:
		seen[String(v)] = true
	var r: Array = seen.keys()
	r.sort()
	return r


func _merge_daily(a: Dictionary, b: Dictionary) -> Dictionary:
	var r := {}
	r["lc"] = maxi(int(a.get("lc", -1)), int(b.get("lc", -1)))
	r["lw"] = maxi(int(a.get("lw", -100000)), int(b.get("lw", -100000)))
	var wa := int(a.get("ws", -1))
	var wb := int(b.get("ws", -1))
	if wa > wb:
		r["ws"] = wa
		r["mk"] = int(a.get("mk", 0))
	elif wb > wa:
		r["ws"] = wb
		r["mk"] = int(b.get("mk", 0))
	else:
		r["ws"] = wa
		r["mk"] = int(a.get("mk", 0)) | int(b.get("mk", 0))
	# görevler: yeni gün kazanır; aynı gün + aynı görevler: ilerleme en büyük, alındı bayrağı VEYA; farklıysa puanı yüksek olan
	var qa := int(a.get("qd", -1))
	var qb := int(b.get("qd", -1))
	var src: Dictionary
	if qa > qb:
		src = a.duplicate(true)
	elif qb > qa:
		src = b.duplicate(true)
	else:
		if str(a.get("qt", [])) == str(b.get("qt", [])) and str(a.get("qg", [])) == str(b.get("qg", [])):
			src = a.duplicate(true)
			var pa: Array = a.get("qp", [])
			var pb: Array = b.get("qp", [])
			var ca: Array = a.get("qc", [])
			var cb: Array = b.get("qc", [])
			var prog: Array = []
			var cl: Array = []
			for i in range(pa.size()):
				prog.append(maxi(int(pa[i]), int(pb[i]) if i < pb.size() else 0))
				cl.append((i < ca.size() and bool(ca[i])) or (i < cb.size() and bool(cb[i])))
			src["qp"] = prog
			src["qc"] = cl
		else:
			var sa := _qscore(a)
			var sb := _qscore(b)
			if sa > sb or (sa == sb and str(a) <= str(b)):
				src = a.duplicate(true)
			else:
				src = b.duplicate(true)
	for k in ["qd", "qt", "qg", "qp", "qc", "qk"]:
		r[k] = src.get(k, [] if k != "qd" else -1)
	return r


func _qscore(d: Dictionary) -> int:
	var s := 0
	for v in d.get("qp", []):
		s += int(v)
	for v in d.get("qc", []):
		if bool(v):
			s += 1000
	return s


# Zaman damgası hariç, karşılaştırma için kararlı metin
func _core(d: Dictionary) -> String:
	var c := d.duplicate(true)
	c.erase("t")
	return JSON.stringify(c, "", true)


# ---------------- YEREL KAYIT ----------------
func _acc_path(pid: String) -> String:
	return "user://acc_%s.json" % pid.md5_text().substr(0, 16)


func _write_json(path: String, d: Dictionary) -> void:
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(d))
		f.close()


func _read_json(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var f := FileAccess.open(path, FileAccess.READ)
	if f == null:
		return {}
	var v: Variant = JSON.parse_string(f.get_as_text())
	f.close()
	return v if v is Dictionary else {}


func _load_cfg() -> void:
	var cf := ConfigFile.new()
	var had := cf.load(CFG) == OK
	dev_id = String(cf.get_value("dev", "id", ""))
	var old_aid := String(cf.get_value("dev", "aid", ""))
	var uid := OS.get_unique_id()
	_aid = uid.sha256_text().substr(0, 16) if uid != "" else ""
	bound_id = String(cf.get_value("acct", "bound", ""))
	bound_name = String(cf.get_value("acct", "name", ""))
	epoch = int(cf.get_value("misc", "epoch", 0))
	eq_t = int(cf.get_value("misc", "eq_t", 0))
	last_ok = int(cf.get_value("misc", "last_ok", 0))
	restored = bool(cf.get_value("misc", "restored", false))
	var kd: Variant = JSON.parse_string(String(cf.get_value("known", "dev", "{}")))
	known_dev = kd if kd is Dictionary else {}
	var rb: Variant = JSON.parse_string(String(cf.get_value("misc", "restore_base", "{}")))
	restore_base = rb if rb is Dictionary else {}
	last_eq = Shop.equipped
	var fresh_dev := (dev_id == "")
	if fresh_dev:
		dev_id = "%08x%08x" % [randi(), randi()]
	# Android yedeğinden başka cihaza geri yüklenmiş: aynı cihaz kimliği iki telefonda olamaz
	var moved := had and not fresh_dev and old_aid != "" and _aid != "" and old_aid != _aid
	if moved:
		dev_id = "%08x%08x" % [randi(), randi()]
		restored = true
		restore_base = {}
		for c in CUR:
			restore_base[c] = _bal(c)
	for c in CUR:
		var b := _bal(c)
		if fresh_dev:
			# bulut öncesi ilerleme (ya da yeni kurulum): mevcut bakiye bu cihazda kazanılmış sayılır
			my_e[c] = b
			my_s[c] = 0
			cp[c] = b
		elif moved:
			my_e[c] = 0
			my_s[c] = 0
			cp[c] = b
		else:
			my_e[c] = int(cf.get_value("e", c, b))
			my_s[c] = int(cf.get_value("s", c, 0))
			cp[c] = int(cf.get_value("cp", c, b))
	_save_cfg()


func _save_cfg() -> void:
	var cf := ConfigFile.new()
	cf.set_value("dev", "id", dev_id)
	cf.set_value("dev", "aid", _aid)
	cf.set_value("acct", "bound", bound_id)
	cf.set_value("acct", "name", bound_name)
	cf.set_value("misc", "epoch", epoch)
	cf.set_value("misc", "eq_t", eq_t)
	cf.set_value("misc", "last_ok", last_ok)
	cf.set_value("misc", "restored", restored)
	cf.set_value("misc", "restore_base", JSON.stringify(restore_base))
	cf.set_value("known", "dev", JSON.stringify(known_dev))
	for c in CUR:
		cf.set_value("e", c, int(my_e.get(c, 0)))
		cf.set_value("s", c, int(my_s.get(c, 0)))
		cf.set_value("cp", c, int(cp.get(c, 0)))
	cf.save(CFG)


# ---------------- EDİTÖR (sahte bulut: user://fake_cloud_*.json) ----------------
func _stub_path() -> String:
	return "user://fake_cloud_%s.json" % _stub_pid().md5_text().substr(0, 8)


func _stub_load() -> void:
	await get_tree().process_frame
	var s := ""
	if FileAccess.file_exists(_stub_path()):
		var f := FileAccess.open(_stub_path(), FileAccess.READ)
		if f:
			s = f.get_as_text()
			f.close()
	_on_cloud_loaded(true, s, "")


func _stub_save(json: String) -> void:
	var f := FileAccess.open(_stub_path(), FileAccess.WRITE)
	if f:
		f.store_string(json)
		f.close()
	await get_tree().process_frame
	_on_cloud_saved(true, "")
