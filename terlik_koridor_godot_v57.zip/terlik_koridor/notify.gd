extends Node
## BİLDİRİMLER (autoload "Notify")  |  Android yerel bildirimleri (internet/sunucu gerekmez)
##
## Günde en fazla 3 bildirim (cihazın YEREL saatine göre):
##   10:00  günlük ödül hazır  (o gün ödül zaten alındıysa bugünkü atlanır)
##   15:30  günlük görevler    (bugün tüm görevlerin ödülü alındıysa bugünkü atlanır)
##   20:30  oyuna davet
## Oyun arka plana gidince önümüzdeki DAYS_AHEAD gün için alarmlar kurulur, oyuna dönülünce iptal edilir
## (oyuncu oynarken bildirim gelmesin). DAYS_AHEAD gün hiç açmazsa bildirimler kendiliğinden biter.
## Son girişten 3. ve 7. günün 10:00 bildirimi "seni özledik" metnidir (oyuna girince 300 / 500+güç-up hediye penceresi açılır).
## Ayarlar > Bildirimler kapalıysa hiçbir şey kurulmaz. Android 13+ için ilk açılışta izin sorulur.
## Editörde / PC'de eklenti yoktur, çağrılar sessizce yok sayılır.

const U = preload("res://fx_util.gd")
const PLUGIN_NAME := "TerlikNotify"
const DAYS_AHEAD := 60
# [saat, dakika]
const SLOT_REWARD := [10, 0]
const SLOT_QUEST := [15, 30]
const SLOT_EVENING := [20, 30]

var _p: Object = null


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if OS.get_name() == "Android" and Engine.has_singleton(PLUGIN_NAME):
		_p = Engine.get_singleton(PLUGIN_NAME)
		_p.cancelAll()                 # oyun şu an önde: kurulu alarm ve tepsideki bildirimler temizlensin


func enabled() -> bool:
	return U.get_setting("notif", true)


# İzin penceresi gerekli mi? (ilk açılışta bir kez; Android 12 ve altında izin zaten verilmiştir)
func should_ask() -> bool:
	if U.get_setting("notif_asked", false):
		return false
	if OS.get_name() == "Android":
		if _p == null:
			return false
		if bool(_p.hasPermission()):
			U.set_setting("notif_asked", true)
			return false
	return true


func has_permission() -> bool:
	if _p == null:
		return true
	return bool(_p.hasPermission())


# Sistem izin penceresini açar (Android 13+). Daha önce sorulduğu not edilir.
func ask_permission() -> void:
	U.set_setting("notif_asked", true)
	if _p != null:
		_p.requestPermission()
	Track.event("notif_prompt", {"item_name": "asked"})


# ---------------- ZAMANLAMA ----------------
func _msg(key: String, daynum: int, salt: int) -> String:
	var a := Loc.l(key)
	return a[(daynum + salt) % a.size()]


func schedule() -> void:
	if _p == null:
		return
	if not enabled() or not has_permission():
		_p.cancelAll()
		return
	var title := Loc.t("title_full")
	var d0 := Daily.today()
	var now_s := Daily.seconds_of_day()
	var list: Array = []
	var nid := 100
	for off in DAYS_AHEAD:
		var dn := d0 + off
		# 1) günlük ödül
		var skip := false
		if off == 0:
			skip = (not Daily.can_claim()) or now_s >= SLOT_REWARD[0] * 3600 + SLOT_REWARD[1] * 60
		if not skip:
			var key := "nt_reward"
			if (off == 3 or off == 7) and Daily.winback_allowed(dn):
				key = "nt_back3" if off == 3 else "nt_back7"
			list.append({"id": nid, "d": off, "h": SLOT_REWARD[0], "m": SLOT_REWARD[1], "title": title, "body": _msg(key, dn, 0)})
		nid += 1
		# 2) günlük görevler
		skip = false
		if off == 0:
			skip = Daily.quests_open_count() == 0 or now_s >= SLOT_QUEST[0] * 3600 + SLOT_QUEST[1] * 60
		if not skip:
			list.append({"id": nid, "d": off, "h": SLOT_QUEST[0], "m": SLOT_QUEST[1], "title": title, "body": _msg("nt_quest", dn, 1)})
		nid += 1
		# 3) akşam daveti
		skip = off == 0 and now_s >= SLOT_EVENING[0] * 3600 + SLOT_EVENING[1] * 60
		if not skip:
			list.append({"id": nid, "d": off, "h": SLOT_EVENING[0], "m": SLOT_EVENING[1], "title": title, "body": _msg("nt_eve", dn, 2)})
		nid += 1
	_p.scheduleAll(JSON.stringify(list))


func cancel() -> void:
	if _p != null:
		_p.cancelAll()


func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_PAUSED:
		schedule()
	elif what == NOTIFICATION_APPLICATION_RESUMED:
		cancel()
