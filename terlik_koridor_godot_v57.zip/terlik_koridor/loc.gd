extends Node
## ÇEVİRİ (autoload "Loc"). Kullanım:  Loc.t("play")   |   Loc.t("level") % 5   |   Loc.l("poke") -> Array
## Diller: tr, en, es, pt (Brezilya), id. Seçim user://terlik_settings.cfg içinde "lang" olarak saklanır.
## İlk açılışta telefonun diline bakar; desteklenmiyorsa İngilizce.
## Yeni dil eklemek: LANGS ve NAMES'e ekle, S içindeki her satıra bir değer daha yaz.
## "|" ile ayrılmış değerler liste olarak alınır (Loc.l).

signal changed

const SETTINGS_PATH := "user://terlik_settings.cfg"
const LANGS := ["tr", "en", "es", "pt", "id"]
const NAMES := ["TÜRKÇE", "ENGLISH", "ESPAÑOL", "PORTUGUÊS", "INDONESIA"]

var idx := 1

# Sıra: tr, en, es, pt, id
const S = {
	# --- başlık ---
	"t1": ["ANNE", "MOM'S", "LA", "CHINELO", "SANDAL"],
	"t2": ["TERLİĞİ", "SLIPPER", "CHANCLA", "DA MÃE", "IBU"],
	"t3": ["KORİDOR", "HALLWAY", "PASILLO", "CORREDOR", "LORONG"],
	"title_full": ["Anne Terliği", "Mom's Slipper", "La Chancla", "Chinelo da Mãe", "Sandal Ibu"],
	# --- ana menü ---
	"play": ["OYNA", "PLAY", "JUGAR", "JOGAR", "MAIN"],
	"new_game": ["Yeni oyun", "New game", "Juego nuevo", "Novo jogo", "Game baru"],
	"continue": ["Bölüm %d'den devam", "Continue from level %d", "Seguir en nivel %d", "Continuar na fase %d", "Lanjut dari level %d"],
	"how_to": ["NASIL OYNANIR?", "HOW TO PLAY", "¿CÓMO SE JUEGA?", "COMO JOGAR?", "CARA BERMAIN?"],
	"how_to_s": ["Nasıl Oynanır?", "How to Play", "Cómo se juega", "Como jogar", "Cara Bermain"],
	"ok": ["TAMAM!", "OK!", "¡LISTO!", "OK!", "OKE!"],
	"h1": [
		"1. Ekranın alt yarısında parmağını hedefe doğru YUKARI fırlat (flick). Ne kadar hızlı savurursan terlik o kadar güçlü gider.",
		"1. On the lower half of the screen, flick your finger UP toward the target. The faster you flick, the harder the slipper flies.",
		"1. En la mitad inferior de la pantalla, lanza el dedo HACIA ARRIBA, hacia el objetivo. Cuanto más rápido, más fuerte sale la chancla.",
		"1. Na metade de baixo da tela, deslize o dedo rápido para CIMA, na direção do alvo. Quanto mais rápido, mais forte o chinelo voa.",
		"1. Di separuh layar bawah, jentikkan jari ke ATAS menuju target. Makin cepat jentikan, makin kuat sandal melesat."],
	"h2": [
		"2. Kaydırdığın yön nişanı belirler: sağa doğru savurursan terlik sağa gider. Çok yana savurursan duvardan seker.",
		"2. The direction of your swipe is your aim: flick to the right and the slipper goes right. Flick far sideways to bounce off the wall.",
		"2. La dirección del deslizamiento es tu puntería: a la derecha, la chancla va a la derecha. Muy de lado, rebota en la pared.",
		"2. A direção do deslize é a sua mira: para a direita, o chinelo vai para a direita. Muito de lado, ele quica na parede.",
		"2. Arah jentikan adalah bidikanmu: ke kanan, sandal ke kanan. Terlalu miring, sandal memantul di dinding."],
	"h3": [
		"3. Bırak = fırlat! Terliği koltuğun ÜSTÜNDEN aşırıp Memo'nun kafasına düşür.",
		"3. Release to throw! Lob the slipper OVER the couch and onto Memo's head.",
		"3. ¡Suelta para lanzar! Pasa la chancla POR ENCIMA del sofá hasta la cabeza de Memo.",
		"3. Solte para lançar! Passe o chinelo POR CIMA do sofá e acerte a cabeça do Memo.",
		"3. Lepas untuk melempar! Lempar sandal MELEWATI sofa dan kenai kepala Memo."],
	"h4": [
		"4. Duvardan sektirebilirsin. Ama vazo ve avize kırarsan Anne duyar!",
		"4. You can bounce it off walls. But if you break a vase or chandelier, Mom will hear!",
		"4. Puedes rebotar en las paredes. ¡Pero si rompes un jarrón o una lámpara, mamá lo oye!",
		"4. Dá para ricochetear nas paredes. Mas se quebrar um vaso ou lustre, a mamãe ouve!",
		"4. Kamu bisa memantulkan ke dinding. Tapi kalau memecahkan vas atau lampu gantung, Ibu dengar!"],
	"h5": [
		"5. Bölümdeki bütün Memo'ları vur, yıldızları topla. Terlik az: boşa atma!",
		"5. Hit every Memo in the level and collect stars. Slippers are limited: don't waste them!",
		"5. Acierta a todos los Memo del nivel y gana estrellas. Hay pocas chanclas: ¡no las desperdicies!",
		"5. Acerte todos os Memos da fase e ganhe estrelas. Os chinelos são poucos: não desperdice!",
		"5. Kenai semua Memo di level ini dan kumpulkan bintang. Sandal terbatas: jangan dibuang!"],
	# --- Memo'nun repliği ve efekt yazıları ---
	"stop": ["YAPMA!", "DON'T!", "¡NO!", "NÃO!", "JANGAN!"],
	"nanik": ["NANİK!", "NYAH NYAH!", "¡BLEH!", "BLÉ!", "WEEK!"],
	"enough": ["BIKTIM ARTIK!", "I'M DONE!", "¡YA BASTA!", "CHEGA!", "CUKUP!"],
	"poke": [
		"AY!|BURNUM!|ANNE!|YAPMADIM!|ÇAT!",
		"OUCH!|MY NOSE!|MOM!|NOT ME!|BONK!",
		"¡AY!|¡MI NARIZ!|¡MAMÁ!|¡YO NO FUI!|¡PAF!",
		"AI!|MEU NARIZ!|MÃE!|NÃO FUI EU!|POW!",
		"AW!|HIDUNGKU!|IBU!|BUKAN AKU!|DUK!"],
	"tak": ["TAK!", "WHACK!", "¡PLAF!", "PLAC!", "TAK!"],
	"wall": [
		"TAK!|TOK!|BOİNG!",
		"WHACK!|THWACK!|BOING!",
		"¡PLAF!|¡TOC!|¡BOING!",
		"PLAC!|TOC!|BOING!",
		"TAK!|DUK!|BOING!"],
	"smash": [
		"ŞANGIR!|ÇANGIR ÇUNGUR!|ANNEM DUYMASIN!",
		"CRASH!|SMASH!|MOM CAN'T KNOW!",
		"¡CRASH!|¡PLAS!|¡MAMÁ NO LO SEPA!",
		"CRASH!|PLÁ!|MAMÃE NÃO VIU!",
		"PRANG!|PYAR!|IBU JANGAN TAHU!"],
	"nopain": ["HİÇ ACIMADI!", "DIDN'T HURT!", "¡NO DOLIÓ!", "NEM DOEU!", "TIDAK SAKIT!"],
	# --- hedef etiketleri ---
	"tag_hizli": ["HIZLI", "FAST", "RÁPIDO", "RÁPIDO", "CEPAT"],
	"tag_kacak": ["KAÇAK", "SNEAKY", "ESQUIVO", "ESQUIVO", "LICIN"],
	"tag_kalin": ["KALIN", "TOUGH", "DURO", "DURO", "TANGGUH"],
	# --- oyun içi ---
	"menu": ["Menü", "Menu", "Menú", "Menu", "Menu"],
	"retry_s": ["Yeniden", "Retry", "Otra vez", "Repetir", "Ulang"],
	"retry": ["Tekrar Oyna", "Play Again", "Jugar otra vez", "Jogar de novo", "Main lagi"],
	"next": ["Sonraki Bölüm", "Next Level", "Siguiente nivel", "Próxima fase", "Level berikutnya"],
	"reward": ["Reklam İzle  +%d Terlik", "Watch Ad  +%d Slippers", "Ver anuncio  +%d chanclas", "Ver anúncio  +%d chinelos", "Tonton Iklan  +%d Sandal"],
	"pop_title": ["+%d Terlik Kazan!", "Win +%d Slippers!", "¡Gana +%d chanclas!", "Ganhe +%d chinelos!", "Dapat +%d Sandal!"],
	"pop_body": ["Kısa bir reklam izle, kaldığın yerden devam et.", "Watch a short ad and keep going from where you left off.", "Mira un anuncio corto y sigue desde donde lo dejaste.", "Assista a um anúncio curto e continue de onde parou.", "Tonton iklan singkat dan lanjutkan dari tempat terakhir."],
	"pop_watch": ["İzle", "Watch", "Ver", "Assistir", "Tonton"],
	"pop_cancel": ["Vazgeç", "Cancel", "Cancelar", "Cancelar", "Batal"],
	# --- bölüm sonu coin x2 + güç-up'lar ---
	"x2coin": ["Reklam İzle  x2 Coin", "Watch Ad  x2 Coins", "Ver anuncio  x2 monedas", "Ver anúncio  x2 moedas", "Tonton Iklan  x2 Koin"],
	"pu_aim": ["Nişan", "Aim", "Mira", "Mira", "Bidik"],
	"pu_slow": ["Yavaş", "Slow", "Lento", "Lento", "Pelan"],
	"pu_double": ["Çift", "Double", "Doble", "Dobro", "Ganda"],
	"pu_aim_t": ["Nişan Yardımı", "Aim Assist", "Ayuda de mira", "Ajuda de mira", "Bantuan Bidik"],
	"pu_slow_t": ["Yavaş Çekim", "Slow Motion", "Cámara lenta", "Câmera lenta", "Gerak Lambat"],
	"pu_double_t": ["Çift Terlik", "Double Slipper", "Chancla doble", "Chinelo duplo", "Sandal Ganda"],
	"pu_aim_d": ["Memo'nun üstündeki yeşil halkaya dokun: terlik oraya otomatik fırlar. Bölüm boyunca açık kalır.", "Tap the green ring over a Memo: the slipper auto-throws at it. Stays on for the whole level.", "Toca el aro verde sobre un Memo: la chancla sale sola hacia él. Dura todo el nivel.", "Toque no anel verde sobre um Memo: o chinelo é lançado sozinho nele. Dura a fase toda.", "Ketuk lingkaran hijau di atas Memo: sandal terlempar otomatis ke sana. Aktif sepanjang level."],
	"pu_aim_tap": ["DOKUN", "TAP", "TOCA", "TOQUE", "KETUK"],
	"pu_aim_fail": ["Yol kapalı!", "No clear shot!", "¡Sin tiro!", "Sem caminho!", "Jalur tertutup!"],
	"pu_slow_d": ["Bu bölümde Memo'lar yavaş hareket eder. Nişan almak çok kolay!", "For this level, Memos move slowly. Much easier to aim!", "En este nivel, los Memo se mueven lento. ¡Apuntar es mucho más fácil!", "Nesta fase, os Memos se movem devagar. Fica bem mais fácil mirar!", "Di level ini, Memo bergerak pelan. Jauh lebih mudah membidik!"],
	"pu_double_d": ["Sıradaki atışta iki terlik birden uçar, hakkın sadece biri gider.", "Your next throw sends two slippers at once and uses only one of your shots.", "Tu próximo tiro lanza dos chanclas a la vez y gasta solo uno.", "Seu próximo arremesso lança dois chinelos de uma vez e gasta só um.", "Lemparan berikutnya melempar dua sandal sekaligus, hanya memakai satu jatah."],
	"pu_coin": ["Coin ile al", "Buy with coins", "Comprar", "Comprar", "Beli koin"],
	"great": ["HARİKA!", "AWESOME!", "¡GENIAL!", "INCRÍVEL!", "KEREN!"],
	"coin_shots": ["+%d Terlik", "+%d Slippers", "+%d chanclas", "+%d chinelos", "+%d Sandal"],
	"no_coin": ["Yetersiz coin!", "Not enough coins!", "¡Monedas insuficientes!", "Moedas insuficientes!", "Koin tidak cukup!"],
	"ad_loading": ["Reklam yükleniyor...", "Loading ad...", "Cargando anuncio...", "Carregando anúncio...", "Memuat iklan..."],
	"ad_none_title": ["Reklam bulunamadı", "No ad found", "No se encontró anuncio", "Anúncio não encontrado", "Iklan tidak ditemukan"],
	"ad_none_body": ["Şu an gösterilecek reklam yok. İnternet bağlantını kontrol edip tekrar dene.", "There is no ad to show right now. Check your connection and try again.", "No hay anuncios disponibles ahora. Revisa tu conexión e inténtalo de nuevo.", "Não há anúncio disponível agora. Verifique sua conexão e tente de novo.", "Belum ada iklan yang bisa ditampilkan. Periksa koneksi internetmu lalu coba lagi."],
	"ad_retry": ["Tekrar dene", "Try again", "Reintentar", "Tentar de novo", "Coba lagi"],
	"ad_close": ["Kapat", "Close", "Cerrar", "Fechar", "Tutup"],
	"ad_retrying": ["Reklam aranıyor...", "Looking for an ad...", "Buscando anuncio...", "Procurando anúncio...", "Mencari iklan..."],
	"level": ["Bölüm %d", "Level %d", "Nivel %d", "Fase %d", "Level %d"],
	"hard": ["ZOR", "HARD", "DIFÍCIL", "DIFÍCIL", "SULIT"],
	"all_hit": ["HEPSİ VURULDU!", "ALL HIT!", "¡TODOS CAÍDOS!", "TODOS NO CHÃO!", "SEMUA KENA!"],
	"memo_hit": ["MEMO VURULDU!", "MEMO HIT!", "¡MEMO CAÍDO!", "MEMO ACERTADO!", "MEMO KENA!"],
	"level_done": ["Bölüm %d tamam", "Level %d complete", "Nivel %d completado", "Fase %d concluída", "Level %d selesai"],
	"out": ["TERLİK BİTTİ!", "SLIPPERS GONE!", "¡SIN CHANCLAS!", "SEM CHINELOS!", "SANDAL HABIS!"],
	"escaped": ["Memo yine yırttı...", "Memo got away again...", "Memo se escapó otra vez...", "O Memo escapou de novo...", "Memo kabur lagi..."],
	"smashed": [
		"Kırdığın eşya: %d  (Anne duymasın!)",
		"Things broken: %d  (Don't tell Mom!)",
		"Cosas rotas: %d  (¡Que mamá no se entere!)",
		"Quebrou: %d  (Que a mamãe não saiba!)",
		"Barang pecah: %d  (Jangan sampai Ibu tahu!)"],
	"rooms": [
		"Aile Koridoru|Mutfak Koridoru|Çılgın Koridor|Kırmızı Salon|Mavi Salon|Saatler Koridoru|Güneşli Oda",
		"Family Hallway|Kitchen Hallway|Crazy Corridor|Red Lounge|Blue Lounge|Clock Hallway|Sunny Room",
		"Pasillo Familiar|Pasillo de la Cocina|Pasillo Loco|Salón Rojo|Salón Azul|Pasillo de Relojes|Cuarto Soleado",
		"Corredor da Família|Corredor da Cozinha|Corredor Maluco|Sala Vermelha|Sala Azul|Corredor dos Relógios|Quarto Ensolarado",
		"Lorong Keluarga|Lorong Dapur|Lorong Gila|Ruang Merah|Ruang Biru|Lorong Jam|Kamar Cerah"],
	# --- öğretici ipuçları (satırlar "|" ile ayrılır) ---
	"hint1": [
		"Parmağını YUKARI fırlat (flick)!|Yönü kaydırma açısı belirler.|Terlik koltuğun ÜSTÜNDEN aşmalı!",
		"Flick your finger UP to throw!|Your swipe angle sets the aim.|The slipper must fly OVER the couch!",
		"¡Lanza el dedo HACIA ARRIBA!|El ángulo del deslizamiento apunta.|¡La chancla debe pasar POR ENCIMA del sofá!",
		"Deslize o dedo para CIMA!|O ângulo do deslize é a mira.|O chinelo deve passar POR CIMA do sofá!",
		"Jentikkan jari ke ATAS untuk melempar!|Sudut jentikan menentukan bidikan.|Sandal harus terbang DI ATAS sofa!"],
	"hint1b": [
		"Olmadı, sorun değil!|Daha hızlı ya da daha yavaş savur, yönü değiştir.|Parmağını sürerken noktalı çizgi yolu gösterir.",
		"Missed, no problem!|Flick faster or slower, or change direction.|While you swipe, the dotted line shows the path.",
		"¡No pasa nada!|Desliza más rápido o más lento, o cambia la dirección.|Al deslizar, la línea punteada muestra el recorrido.",
		"Errou, sem problema!|Deslize mais rápido ou mais devagar, ou mude a direção.|Ao deslizar, a linha pontilhada mostra o trajeto.",
		"Meleset, tidak apa-apa!|Jentik lebih cepat atau lambat, atau ganti arah.|Saat menggeser, garis titik-titik menunjukkan jalur."],
	"hint2": [
		"2 Memo var!|İkisini de vurman lazım.",
		"2 Memos!|Hit them both.",
		"¡Hay 2 Memos!|Tienes que darles a los dos.",
		"São 2 Memos!|Acerte os dois.",
		"Ada 2 Memo!|Kenai keduanya."],
	"hint3": [
		"Vazo yoluna çıkarsa kırılır!|Üstünden aşırmayı dene.",
		"A vase in the way will break!|Try to lob it over.",
		"¡Si chocas con el jarrón, se rompe!|Intenta pasar por encima.",
		"Se bater no vaso, ele quebra!|Tente passar por cima.",
		"Vas di jalur akan pecah!|Coba lempar melewatinya."],
	"hint4": [
		"3 Memo! Atışlarını boşa harcama.|Ortadaki kayıyor, zamanla.",
		"3 Memos! Don't waste your shots.|The middle one slides, time it.",
		"¡3 Memos! No desperdicies tiros.|El del medio se mueve, calcula.",
		"3 Memos! Não desperdice tiros.|O do meio desliza, cronometre.",
		"3 Memo! Jangan buang lemparan.|Yang tengah bergeser, atur waktunya."],
	"hint5": [
		"MAVİ Memo KAÇAK: koltuğa eğilir.|Kafasını çıkarınca vur!",
		"BLUE Memo is SNEAKY: he ducks down.|Hit him when he pops up!",
		"Memo AZUL ESQUIVA: se agacha tras el sofá.|¡Dale cuando asome la cabeza!",
		"Memo AZUL é ESCORREGADIO: se abaixa.|Acerte quando ele levantar a cabeça!",
		"Memo BIRU LICIN: dia menunduk di sofa.|Kenai saat kepalanya muncul!"],
	"hint6": [
		"SARI Memo HIZLI ve küçük.|Gideceği yeri tahmin et!",
		"YELLOW Memo is FAST and small.|Predict where he's going!",
		"Memo AMARILLO: RÁPIDO y pequeño.|¡Predice hacia dónde va!",
		"Memo AMARELO: RÁPIDO e pequeno.|Preveja para onde ele vai!",
		"Memo KUNING CEPAT dan kecil.|Tebak ke mana dia bergerak!"],
	"hint8": [
		"KIRMIZI Memo KALIN:|2 kere vurman lazım!",
		"RED Memo is TOUGH:|it takes 2 hits!",
		"Memo ROJO es DURO:|¡hay que darle 2 veces!",
		"Memo VERMELHO é DURO:|precisa de 2 acertos!",
		"Memo MERAH TANGGUH:|butuh 2 kali kena!"],
	# --- ayarlar ---
	"settings": ["Seçenekler", "Settings", "Ajustes", "Opções", "Pengaturan"],
	"our_apps": ["Uygulamalarımız", "Our Apps", "Nuestras apps", "Nossos apps", "Aplikasi Kami"],
	"games_btn": ["Oyunlarımız ve Uygulamalarımız", "Our Games & Apps", "Nuestros juegos y apps", "Nossos jogos e apps", "Game & Aplikasi Kami"],
	"apps_note": [
		"Bizim yaptığımız diğer oyunlar ve uygulamalar:",
		"Other games and apps we made:",
		"Otros juegos y apps que hicimos:",
		"Outros jogos e apps que criamos:",
		"Game dan aplikasi lain buatan kami:"],
	"sec_sound": ["SES", "SOUND", "SONIDO", "SOM", "SUARA"],
	"music": ["Müzik", "Music", "Música", "Música", "Musik"],
	"sfx": ["Ses Efektleri", "Sound Effects", "Efectos de sonido", "Efeitos sonoros", "Efek Suara"],
	"sec_device": ["CİHAZ", "DEVICE", "DISPOSITIVO", "DISPOSITIVO", "PERANGKAT"],
	"vib": ["Titreşim", "Vibration", "Vibración", "Vibração", "Getar"],
	"fxs": ["Ekran Efektleri", "Screen Effects", "Efectos de pantalla", "Efeitos de tela", "Efek Layar"],
	"sec_progress": ["İLERLEME", "PROGRESS", "PROGRESO", "PROGRESSO", "KEMAJUAN"],
	"reset": ["Baştan Başla (1. Bölüm)", "Start Over (Level 1)", "Empezar de nuevo (nivel 1)", "Recomeçar (fase 1)", "Mulai Ulang (Level 1)"],
	"reset_ask": ["Emin misin? Tekrar dokun", "Are you sure? Tap again", "¿Seguro? Toca otra vez", "Tem certeza? Toque de novo", "Yakin? Ketuk lagi"],
	"reset_done": ["İlerleme sıfırlandı", "Progress reset", "Progreso reiniciado", "Progresso reiniciado", "Kemajuan direset"],
	"backup_btn": ["Yedekleme nasıl yapılır?", "How to back up progress", "¿Cómo guardar mi progreso?", "Como salvar meu progresso?", "Cara mencadangkan data?"],
	"bk_title": ["YEDEKLEME", "BACKUP", "COPIA", "BACKUP", "CADANGAN"],
	"bk1": [
		"1) Telefonda Ayarlar > Google > Yedekleme bölümünden yedeklemeyi aç. (Menü adı marka ve sürüme göre biraz değişebilir.)",
		"1) On your phone open Settings > Google > Backup and turn backup on. (Menu names may differ slightly by brand and version.)",
		"1) En el teléfono abre Ajustes > Google > Copia de seguridad y actívala. (Los nombres del menú pueden variar según la marca y la versión.)",
		"1) No celular abra Configurações > Google > Backup e ative o backup. (Os nomes dos menus podem variar conforme a marca e a versão.)",
		"1) Di ponsel buka Setelan > Google > Pencadangan lalu aktifkan. (Nama menu bisa sedikit berbeda tergantung merek dan versi.)"],
	"bk2": [
		"2) Yedek otomatik alınır; genelde günde bir kez, telefon şarjdayken ve Wi-Fi'a bağlıyken. Oyunu silmeden önce telefonu bir süre şarjda ve Wi-Fi'da bırak.",
		"2) Backups run automatically, usually about once a day while the phone is charging on Wi-Fi. Before deleting the game, leave the phone charging on Wi-Fi for a while.",
		"2) La copia es automática, normalmente una vez al día con el teléfono cargando y con Wi-Fi. Antes de borrar el juego, deja el teléfono cargando con Wi-Fi un rato.",
		"2) O backup é automático, geralmente uma vez por dia com o celular carregando e no Wi-Fi. Antes de apagar o jogo, deixe o celular carregando no Wi-Fi por um tempo.",
		"2) Pencadangan berjalan otomatis, biasanya sekali sehari saat ponsel mengisi daya dan terhubung Wi-Fi. Sebelum menghapus game, biarkan ponsel mengisi daya di Wi-Fi beberapa saat."],
	"bk3": [
		"3) Yeni telefonda aynı Google hesabıyla giriş yap ve oyunu Play Store'dan yükle; ilerleme kendiliğinden geri gelebilir.",
		"3) On the new phone sign in with the same Google account and install the game from Google Play; your progress can come back automatically.",
		"3) En el teléfono nuevo inicia sesión con la misma cuenta de Google e instala el juego desde Google Play; tu progreso puede volver automáticamente.",
		"3) No celular novo entre com a mesma conta Google e instale o jogo pela Google Play; seu progresso pode voltar automaticamente.",
		"3) Di ponsel baru masuk dengan akun Google yang sama dan instal game dari Google Play; kemajuanmu bisa kembali otomatis."],
	"bk4": [
		"Not: Yedekleme Google/Android tarafından yapılır, garanti edilemez.",
		"Note: Backup is handled by Google/Android and can't be guaranteed.",
		"Nota: La copia depende de Google/Android y no se puede garantizar.",
		"Obs.: O backup depende do Google/Android e não pode ser garantido.",
		"Catatan: Pencadangan dikelola Google/Android dan tidak dapat dijamin."],
	"cs_title": ["HOŞ GELDİN!", "WELCOME!", "¡BIENVENIDO!", "BEM-VINDO!", "SELAMAT DATANG!"],
	"cs_body": [
		"Oyuna başlamadan önce Kullanım Şartları'nı ve Gizlilik Politikası'nı okuyup kabul etmen gerekiyor. Oyunda reklamlar gösterilir. Kabul etmezsen oyun açılmaz.",
		"Before you start, please read and accept the Terms of Use and the Privacy Policy. The game shows ads. If you decline, the game will close.",
		"Antes de empezar, lee y acepta los Términos de uso y la Política de privacidad. El juego muestra anuncios. Si rechazas, el juego se cerrará.",
		"Antes de começar, leia e aceite os Termos de uso e a Política de privacidade. O jogo exibe anúncios. Se recusar, o jogo será fechado.",
		"Sebelum mulai, baca dan setujui Ketentuan Penggunaan dan Kebijakan Privasi. Game ini menampilkan iklan. Jika kamu menolak, game akan ditutup."],
	"cs_accept": ["KABUL ET", "ACCEPT", "ACEPTAR", "ACEITAR", "TERIMA"],
	"cs_reject": ["REDDET", "DECLINE", "RECHAZAR", "RECUSAR", "TOLAK"],
	"sec_lang": ["DİL", "LANGUAGE", "IDIOMA", "IDIOMA", "BAHASA"],
	"sec_help": ["YARDIM", "HELP", "AYUDA", "AJUDA", "BANTUAN"],
	"sec_privacy": ["GİZLİLİK", "PRIVACY", "PRIVACIDAD", "PRIVACIDADE", "PRIVASI"],
	"consent": ["Reklam Rızasını Yönet", "Manage Ad Consent", "Consentimiento de anuncios", "Consentimento de anúncios", "Kelola Persetujuan Iklan"],
	"sec_about": ["HAKKINDA", "ABOUT", "ACERCA DE", "SOBRE", "TENTANG"],
	"terms": ["Kullanım Şartları", "Terms of Use", "Términos de uso", "Termos de uso", "Ketentuan Penggunaan"],
	"privacy": ["Gizlilik Politikası", "Privacy Policy", "Política de privacidad", "Política de privacidade", "Kebijakan Privasi"],
	"download": ["İNDİR", "GET", "BAJAR", "BAIXAR", "UNDUH"],
	"gdesc0": [
		"Fırlat, birleştir, inşa et! 6 dünyada eşleştir, kasabanı büyüt.",
		"Shoot, merge and build! Match items across 6 worlds and grow your town.",
		"¡Lanza, une y construye! Combina objetos en 6 mundos y haz crecer tu pueblo.",
		"Lance, una e construa! Combine itens em 6 mundos e faça sua cidade crescer.",
		"Tembak, gabungkan, bangun! Cocokkan item di 6 dunia dan kembangkan kotamu."],
	"gdpr_title": ["AB / AEA / Birleşik Krallık (GDPR)", "EU / EEA / UK (GDPR)", "UE / EEE / Reino Unido (RGPD)", "UE / EEE / Reino Unido (GDPR)", "UE / EEA / Inggris (GDPR)"],
	"gdpr_info": [
		"İlerlemen cihazında saklanır. Reklam ve ölçümleme ortaklarımız (Unity LevelPlay vb.) reklam kimliği ve cihaz bilgisi gibi verileri işleyebilir. Rızanı istediğin zaman Ayarlar > Reklam Rızasını Yönet'ten geri alabilirsin.",
		"Your progress is stored on your device. Our ad and measurement partners (e.g. Unity LevelPlay) may process data such as the advertising ID and device info. You can withdraw consent any time in Settings > Manage Ad Consent.",
		"Tu progreso se guarda en tu dispositivo. Nuestros socios de publicidad y medición (p. ej., Unity LevelPlay) pueden procesar datos como el ID de publicidad y la información del dispositivo. Puedes retirar el consentimiento cuando quieras en Ajustes > Consentimiento de anuncios.",
		"Seu progresso é salvo no seu dispositivo. Nossos parceiros de publicidade e medição (p. ex., Unity LevelPlay) podem processar dados como o ID de publicidade e informações do dispositivo. Você pode retirar o consentimento a qualquer momento em Configurações > Consentimento de anúncios.",
		"Progresmu disimpan di perangkatmu. Mitra iklan dan pengukuran kami (mis. Unity LevelPlay) dapat memproses data seperti ID iklan dan info perangkat. Kamu dapat mencabut persetujuan kapan saja di Pengaturan > Kelola Persetujuan Iklan."],
	"gdpr_check": [
		"Kişisel verilerimin yukarıda anlatıldığı şekilde işlenmesine açıkça rıza veriyorum (isteğe bağlı).",
		"I explicitly consent to the processing of my personal data as described above (optional).",
		"Doy mi consentimiento explícito para el tratamiento de mis datos personales como se describe arriba (opcional).",
		"Dou meu consentimento explícito para o tratamento dos meus dados pessoais conforme descrito acima (opcional).",
		"Saya secara tegas menyetujui pemrosesan data pribadi saya seperti dijelaskan di atas (opsional)."],
	"gdpr_note": [
		"İşaretlersen kişiselleştirilmiş reklamlar görürsün. İşaretlemezsen reklamlar yine görünür ama kişiselleştirilmez.",
		"Tick it for personalized ads. If you don't, you'll still see ads, just not personalized.",
		"Márcalo para ver anuncios personalizados. Si no, seguirás viendo anuncios, pero no personalizados.",
		"Marque para ver anúncios personalizados. Se não marcar, ainda verá anúncios, mas não personalizados.",
		"Centang untuk iklan yang dipersonalisasi. Jika tidak, iklan tetap muncul tetapi tidak dipersonalisasi."],
	"adc_on": [
		"Reklam rızası şu an AÇIK. Buradan geri çekebilirsin.",
		"Ad consent is currently ON. You can withdraw it here.",
		"El consentimiento de anuncios está ACTIVADO. Puedes retirarlo aquí.",
		"O consentimento de anúncios está ATIVADO. Você pode retirá-lo aqui.",
		"Persetujuan iklan saat ini AKTIF. Kamu bisa mencabutnya di sini."],
	"adc_off": [
		"Reklam rızası şu an KAPALI. Buradan izin verebilirsin.",
		"Ad consent is currently OFF. You can allow it here.",
		"El consentimiento de anuncios está DESACTIVADO. Puedes permitirlo aquí.",
		"O consentimento de anúncios está DESATIVADO. Você pode permitir aqui.",
		"Persetujuan iklan saat ini NONAKTIF. Kamu bisa mengizinkannya di sini."],
	"adc_withdraw": ["Rızayı geri çek", "Withdraw consent", "Retirar consentimiento", "Retirar consentimento", "Cabut persetujuan"],
	"adc_allow": ["İzin ver", "Allow", "Permitir", "Permitir", "Izinkan"],
	"adc_close": ["Kapat", "Close", "Cerrar", "Fechar", "Tutup"],
	"toast_noconsent": [
		"Bu cihazda reklam rızası formu yok",
		"No ad consent form on this device",
		"No hay formulario de consentimiento",
		"Sem formulário de consentimento",
		"Tidak ada formulir persetujuan"],
	"toast_nolink": ["Bağlantı henüz eklenmedi", "Link not added yet", "Enlace aún no disponible", "Link ainda não adicionado", "Tautan belum ditambahkan"],
	"toast_nopkg": ["Paket adı henüz eklenmedi", "Package not added yet", "Paquete aún no disponible", "Pacote ainda não adicionado", "Paket belum ditambahkan"],
	# --- günlük ödül / görevler / bildirimler ---
	"daily_title": ["Günlük Ödül", "Daily Reward", "Premio diario", "Prêmio diário", "Hadiah Harian"],
	"daily_day": ["%d. GÜN", "DAY %d", "DÍA %d", "DIA %d", "HARI %d"],
	"daily_claim": ["AL!", "CLAIM!", "¡RECLAMAR!", "RESGATAR!", "AMBIL!"],
	"daily_claimed": ["Ödül alındı!", "Reward claimed!", "¡Premio reclamado!", "Prêmio resgatado!", "Hadiah diambil!"],
	"daily_back": ["Yarın yeni bir ödül seni bekliyor.", "A new reward awaits you tomorrow.", "Mañana te espera un nuevo premio.", "Amanhã um novo prêmio espera você.", "Besok ada hadiah baru untukmu."],
	"daily_streak": ["%d gün üst üste giriş!", "%d days in a row!", "¡%d días seguidos!", "%d dias seguidos!", "%d hari berturut-turut!"],
	"daily_extra": ["7. gün seri bonusu eklendi!", "Day 7 streak bonus added!", "¡Bono de racha del día 7!", "Bônus de sequência do dia 7!", "Bonus beruntun hari ke-7!"],
	"quests_title": ["GÖREVLER", "QUESTS", "MISIONES", "MISSÕES", "MISI"],
	"q_claim": ["AL", "CLAIM", "RECLAMAR", "RESGATAR", "AMBIL"],
	"q_claimed": ["Alındı", "Claimed", "Reclamado", "Resgatado", "Diambil"],
	"q_reset": ["Yenilenmesine: %s", "Refreshes in: %s", "Se renueva en: %s", "Renova em: %s", "Diperbarui dalam: %s"],
	"q_memo": ["%d Memo yakala", "Catch %d Memos", "Atrapa a %d Memos", "Pegue %d Memos", "Tangkap %d Memo"],
	"q_stars": ["%d yıldız topla", "Collect %d stars", "Reúne %d estrellas", "Colete %d estrelas", "Kumpulkan %d bintang"],
	"q_levels": ["%d bölüm kazan", "Win %d levels", "Gana %d niveles", "Vença %d fases", "Menangkan %d level"],
	"q_smash": ["%d eşya kır", "Smash %d items", "Rompe %d objetos", "Quebre %d objetos", "Pecahkan %d barang"],
	"q_powerup": ["%d güçlendirici kullan", "Use %d power-ups", "Usa %d potenciadores", "Use %d power-ups", "Pakai %d penguat"],
	"q_threestar": ["%d bölümü 3 yıldızla bitir", "Finish %d levels with 3 stars", "Termina %d niveles con 3 estrellas", "Termine %d fases com 3 estrelas", "Selesaikan %d level dengan 3 bintang"],
	"q_shots": ["%d terlik fırlat", "Throw %d slippers", "Lanza %d chanclas", "Arremesse %d chinelos", "Lempar %d sandal"],
	"quest_ready": ["Görev tamamlandı!", "Quest complete!", "¡Misión cumplida!", "Missão cumprida!", "Misi selesai!"],
	"notif_set": ["Bildirimler", "Notifications", "Notificaciones", "Notificações", "Notifikasi"],
	"notif_title": ["BİLDİRİMLER", "NOTIFICATIONS", "NOTIFICACIONES", "NOTIFICAÇÕES", "NOTIFIKASI"],
	"notif_body": ["Günlük ödülün ve görevlerin hazır olunca sana haber verelim mi? İstediğin zaman Ayarlar'dan kapatabilirsin.", "Want a heads-up when your daily reward and quests are ready? You can turn this off anytime in Settings.", "¿Quieres que te avisemos cuando tu premio diario y tus misiones estén listos? Puedes desactivarlo en Ajustes.", "Quer receber um aviso quando seu prêmio diário e suas missões estiverem prontos? Você pode desativar em Ajustes.", "Mau diberi tahu saat hadiah harian dan misimu siap? Kamu bisa mematikannya kapan saja di Pengaturan."],
	"notif_later": ["Şimdi Değil", "Not Now", "Ahora no", "Agora não", "Nanti"],
	"pu_use": ["Envanterden kullan (x%d)", "Use from inventory (x%d)", "Usar del inventario (x%d)", "Usar do inventário (x%d)", "Pakai dari inventaris (x%d)"],
	"nt_reward": ["Günlük ödülün hazır! Gel, al.|Annen sana bir hediye bıraktı, gel al!|Bugünün ödülü seni bekliyor!", "Your daily reward is ready! Come grab it.|Mom left you a little gift. Come get it!|Today's reward is waiting for you!", "¡Tu premio diario está listo! Ven a por él.|¡Mamá te dejó un regalito! ¡Ven a buscarlo!|¡El premio de hoy te espera!", "Seu prêmio diário está pronto! Venha pegar.|A mamãe deixou um presentinho! Venha buscar!|O prêmio de hoje está esperando você!", "Hadiah harianmu sudah siap! Ayo ambil.|Ibu meninggalkan hadiah kecil untukmu. Ayo ambil!|Hadiah hari ini menunggumu!"],
	"nt_quest": ["Günlük görevlerin seni bekliyor. Bitir, coin kazan!|Bugünkü görevleri tamamlayıp coin toplamaya ne dersin?|Memo'ları yakalama görevi seni bekliyor!", "Your daily quests are waiting. Finish them, earn coins!|How about finishing today's quests and collecting coins?|A Memo-catching quest is waiting for you!", "Tus misiones diarias te esperan. ¡Termínalas y gana monedas!|¿Qué tal completar las misiones de hoy y juntar monedas?|¡Una misión para atrapar a Memo te espera!", "Suas missões diárias esperam por você. Termine e ganhe moedas!|Que tal completar as missões de hoje e juntar moedas?|Uma missão para pegar o Memo está esperando!", "Misi harianmu menunggu. Selesaikan dan dapatkan koin!|Bagaimana kalau menyelesaikan misi hari ini dan mengumpulkan koin?|Misi menangkap Memo menunggumu!"],
	"nt_eve": ["Memo yine dil çıkarıyor... Terlik elinde mi?|Koridor seni bekliyor. Bir bölüm daha?|Annenin terliği hazır, Memo kaçamaz!", "Memo is sticking his tongue out again... Got your slipper?|The hallway is waiting. One more level?|Mom's slipper is ready, Memo can't escape!", "Memo vuelve a sacar la lengua... ¿Tienes la chancla?|El pasillo te espera. ¿Un nivel más?|¡La chancla de mamá está lista, Memo no escapa!", "O Memo está mostrando a língua de novo... Cadê o chinelo?|O corredor está esperando. Mais uma fase?|O chinelo da mamãe está pronto, o Memo não escapa!", "Memo menjulurkan lidah lagi... Sandalnya sudah siap?|Lorong menunggumu. Satu level lagi?|Sandal Ibu sudah siap, Memo tidak bisa kabur!"],
	"wb_title": ["SENİ ÖZLEDİK!", "WE MISSED YOU!", "¡TE EXTRAÑAMOS!", "SENTIMOS SUA FALTA!", "KAMI RINDU KAMU!"],
	"wb_body": ["Eğlenceyi kaçırma! Sana özel hediyen hazır.", "Don't miss the fun! Your special gift is ready.", "¡No te pierdas la diversión! Tu regalo especial está listo.", "Não perca a diversão! Seu presente especial está pronto.", "Jangan lewatkan serunya! Hadiah spesialmu sudah siap."],
	"nt_back3": ["Seni özledik! Eğlenceyi kaçırma, hediyen seni bekliyor.|Memo seni özledi... Gel, sana bir sürprizimiz var!", "We missed you! Don't miss the fun, your gift is waiting.|Memo misses you... Come back, we have a surprise for you!", "¡Te extrañamos! No te pierdas la diversión, tu regalo te espera.|Memo te extraña... ¡Vuelve, tenemos una sorpresa!", "Sentimos sua falta! Não perca a diversão, seu presente espera por você.|O Memo sente sua falta... Volte, temos uma surpresa!", "Kami rindu kamu! Jangan lewatkan serunya, hadiahmu menunggu.|Memo kangen kamu... Kembalilah, ada kejutan untukmu!"],
	"nt_back7": ["Seni çok özledik! Hediyelerin hazır, gel al.|Bir haftadır yoksun! Sana özel hediyeler seni bekliyor.", "We really missed you! Your gifts are ready, come grab them.|You've been away a week! Special gifts are waiting for you.", "¡Te extrañamos mucho! Tus regalos están listos, ven por ellos.|¡Llevas una semana fuera! Te esperan regalos especiales.", "Sentimos muito sua falta! Seus presentes estão prontos, venha buscar.|Faz uma semana que você sumiu! Presentes especiais esperam por você.", "Kami sangat rindu! Hadiahmu sudah siap, ayo ambil.|Sudah seminggu kamu pergi! Hadiah spesial menunggumu."],
	# --- market / elmas ---
	"sk_classic": ["Klasik", "Classic", "Clásica", "Clássico", "Klasik"],
	"sk_flame": ["Alevli", "Flame", "Llameante", "Flamejante", "Api"],
	"sk_bolt": ["Şimşek", "Lightning", "Relámpago", "Relâmpago", "Petir"],
	"sk_giant": ["Dev", "Giant", "Gigante", "Gigante", "Raksasa"],
	"sk_gold": ["Altın", "Golden", "Dorada", "Dourado", "Emas"],
	"sk_hyper": ["Hipersonik", "Hypersonic", "Hipersónica", "Hipersônico", "Hipersonik"],
	"sk_boom": ["Bumerang", "Boomerang", "Bumerán", "Bumerangue", "Bumerang"],
	"sk_pink": ["Pembe", "Pink", "Rosa", "Rosa", "Pink"],
	"sk_tiger": ["Kaplan", "Tiger", "Tigre", "Tigre", "Harimau"],
	"sk_heart": ["Kalpli", "Hearts", "Corazones", "Corações", "Hati"],
	"sk_rainbow": ["Gökkuşağı", "Rainbow", "Arcoíris", "Arco-íris", "Pelangi"],
	"sk_disco": ["Disko", "Disco", "Disco", "Disco", "Disko"],
	"sk_classic_d": ["Annenin sevgili terliği. Her zaman yanında.", "Mom's beloved slipper. Always by your side.", "La chancla favorita de mamá. Siempre contigo.", "O chinelo querido da mamãe. Sempre com você.", "Sandal kesayangan Ibu. Selalu bersamamu."],
	"sk_flame_d": ["Alev izi bırakır. Vazo ve avizeyi kırarken yavaşlamaz.", "Leaves a fire trail. Doesn't slow down when smashing vases and chandeliers.", "Deja un rastro de fuego. No se frena al romper jarrones y lámparas.", "Deixa um rastro de fogo. Não perde velocidade ao quebrar vasos e lustres.", "Meninggalkan jejak api. Tidak melambat saat memecahkan vas dan lampu hias."],
	"sk_bolt_d": ["Vurduğu Memo'dan yakındaki Memo'ya yıldırım atlar.", "Lightning jumps from the Memo it hits to a nearby Memo.", "El rayo salta de la Memo golpeada a otra cercana.", "O raio salta do Memo atingido para outro por perto.", "Petir melompat dari Memo yang kena ke Memo di dekatnya."],
	"sk_giant_d": ["Dev boy! Vuruş alanı geniş, çarpınca yer sallanır.", "Giant size! Bigger hit area, shakes the ground on impact.", "¡Tamaño gigante! Mayor área de golpe, hace temblar el suelo.", "Tamanho gigante! Área de acerto maior, faz o chão tremer.", "Ukuran raksasa! Area pukul luas, tanah bergetar saat kena."],
	"sk_gold_d": ["Bölüm sonu coin ödülü %25 artar.", "Level-end coin reward +25%.", "La recompensa de monedas al final del nivel sube un 25%.", "A recompensa de moedas no fim da fase aumenta 25%.", "Hadiah koin akhir level naik 25%."],
	"sk_hyper_d": ["Işık hızında! Aynı yoldan çok daha hızlı gider.", "Lightning fast! Follows the same path much quicker.", "¡A la velocidad de la luz! Hace el mismo camino mucho más rápido.", "Na velocidade da luz! Faz o mesmo caminho bem mais rápido.", "Secepat kilat! Jalurnya sama, tapi jauh lebih cepat."],
	"sk_boom_d": ["Iskalarsa geri döner, atış hakkın yanmaz (bölümde 3 kez).", "If it misses it comes back and your throw isn't used (3 times per level).", "Si falla, vuelve y no gastas el lanzamiento (3 veces por nivel).", "Se errar, volta e o arremesso não é gasto (3 vezes por fase).", "Jika meleset, kembali dan lemparanmu tidak terpakai (3 kali per level)."],
	"sk_pink_d": ["Sadece görünüm: pembe terlik, parıltılı iz.", "Look only: pink slipper with a sparkly trail.", "Solo estilo: chancla rosa con rastro brillante.", "Só visual: chinelo rosa com rastro brilhante.", "Hanya tampilan: sandal pink dengan jejak berkilau."],
	"sk_tiger_d": ["Sadece görünüm: kaplan rengi, pati izi.", "Look only: tiger colors with paw prints.", "Solo estilo: colores de tigre con huellas.", "Só visual: cores de tigre com pegadas.", "Hanya tampilan: warna harimau dengan jejak kaki."],
	"sk_heart_d": ["Sadece görünüm: arkasında kalpler uçuşur.", "Look only: hearts float behind it.", "Solo estilo: corazones flotan detrás.", "Só visual: corações voam atrás dele.", "Hanya tampilan: hati beterbangan di belakangnya."],
	"sk_rainbow_d": ["Sadece görünüm: gökkuşağı izi bırakır.", "Look only: leaves a rainbow trail.", "Solo estilo: deja un rastro de arcoíris.", "Só visual: deixa um rastro de arco-íris.", "Hanya tampilan: meninggalkan jejak pelangi."],
	"sk_disco_d": ["Sadece görünüm: renk değiştirir, disko ışıkları.", "Look only: changes colors with disco lights.", "Solo estilo: cambia de color con luces de disco.", "Só visual: muda de cor com luzes de discoteca.", "Hanya tampilan: berganti warna dengan lampu disko."],
	"market_title": ["MARKET", "SHOP", "TIENDA", "LOJA", "TOKO"],
	"mk_use": ["KULLAN", "EQUIP", "USAR", "USAR", "PAKAI"],
	"mk_using": ["KULLANILIYOR", "EQUIPPED", "EN USO", "EM USO", "DIPAKAI"],
	"mk_confirm": ["%s satın alınsın mı?", "Buy %s?", "¿Comprar %s?", "Comprar %s?", "Beli %s?"],
	"mk_yes": ["SATIN AL", "BUY", "COMPRAR", "COMPRAR", "BELI"],
	"mk_no": ["VAZGEÇ", "CANCEL", "CANCELAR", "CANCELAR", "BATAL"],
	"mk_nocoin": ["Yeterli coin yok", "Not enough coins", "No tienes suficientes monedas", "Moedas insuficientes", "Koin tidak cukup"],
	"mk_nogem": ["Yeterli elmas yok", "Not enough gems", "No tienes suficientes gemas", "Gemas insuficientes", "Permata tidak cukup"],
	"mk_new": ["YENİ TERLİK!", "NEW SLIPPER!", "¡NUEVA CHANCLA!", "NOVO CHINELO!", "SANDAL BARU!"],
	"mk_new_sub": ["Terliğin hazır, kullanıma başladı. Bol şans!", "Your slipper is ready and equipped. Good luck!", "¡Tu chancla está lista y equipada. Suerte!", "Seu chinelo está pronto e equipado. Boa sorte!", "Sandalmu siap dan sudah dipakai. Semoga berhasil!"],
	"mk_power": ["Özellikli", "Special", "Especial", "Especial", "Spesial"],
	"mk_look": ["Görünüm", "Look", "Estilo", "Visual", "Tampilan"],
	"gem_btn": ["ELMAS KAZAN", "EARN GEMS", "GANA GEMAS", "GANHE GEMAS", "DAPAT PERMATA"],
	"gem_watch": ["Reklam izle (%d/3)", "Watch ad (%d/3)", "Ver anuncio (%d/3)", "Ver anúncio (%d/3)", "Tonton iklan (%d/3)"],
	"gem_wait": ["Sonraki tur: %s", "Next round: %s", "Próxima ronda: %s", "Próxima rodada: %s", "Ronde berikut: %s"],
	"gem_loading": ["Reklam yükleniyor...", "Loading ad...", "Cargando anuncio...", "Carregando anúncio...", "Memuat iklan..."],
	"gem_win": ["ELMAS KAZANDIN!", "YOU WON GEMS!", "¡GANASTE GEMAS!", "VOCÊ GANHOU GEMAS!", "KAMU DAPAT PERMATA!"],
	"gem_jackpot": ["JACKPOT!", "JACKPOT!", "¡JACKPOT!", "JACKPOT!", "JACKPOT!"],
	"boom_back": ["Geri döndü!", "It's back!", "¡Volvió!", "Voltou!", "Kembali!"],
	"mk_tab_skin": ["TERLİKLER", "SLIPPERS", "CHANCLAS", "CHINELOS", "SANDAL"],
	"mk_tab_pack": ["PAKETLER", "PACKS", "PAQUETES", "PACOTES", "PAKET"],
	"iap_noads_t": ["REKLAMSIZ", "NO ADS", "SIN ANUNCIOS", "SEM ANÚNCIOS", "TANPA IKLAN"],
	"iap_noads_d": ["Banner ve geçiş reklamları kalkar. Ödüllü reklamlar isteğe bağlı kalır.", "Removes banner and interstitial ads. Rewarded ads stay optional.", "Quita los banners y anuncios intersticiales. Los anuncios con recompensa siguen siendo opcionales.", "Remove banners e anúncios intersticiais. Anúncios com recompensa continuam opcionais.", "Menghapus iklan banner dan sela. Iklan hadiah tetap opsional."],
	"iap_starter_t": ["BAŞLANGIÇ PAKETİ", "STARTER PACK", "PAQUETE INICIAL", "PACOTE INICIAL", "PAKET PEMULA"],
	"iap_starter_tag": ["TEK SEFERLİK", "ONE TIME ONLY", "SOLO UNA VEZ", "SÓ UMA VEZ", "SEKALI SAJA"],
	"iap_c1000_t": ["KÜÇÜK PAKET", "SMALL PACK", "PAQUETE PEQUEÑO", "PACOTE PEQUENO", "PAKET KECIL"],
	"iap_c2500_t": ["BÜYÜK PAKET", "BIG PACK", "PAQUETE GRANDE", "PACOTE GRANDE", "PAKET BESAR"],
	"iap_boost_t": ["GÜÇ-UP PAKETİ", "BOOSTER PACK", "PAQUETE DE POTENCIADORES", "PACOTE DE BOOSTERS", "PAKET BOOSTER"],
	"iap_best": ["EN İYİ DEĞER", "BEST VALUE", "MEJOR VALOR", "MELHOR VALOR", "TERBAIK"],
	"iap_owned": ["SATIN ALINDI", "PURCHASED", "COMPRADO", "COMPRADO", "TERBELI"],
	"iap_restore": ["Satın alımları geri yükle", "Restore purchases", "Restaurar compras", "Restaurar compras", "Pulihkan pembelian"],
	"iap_restore_done": ["Satın alımların kontrol edildi", "Purchases checked", "Compras comprobadas", "Compras verificadas", "Pembelian sudah diperiksa"],
	"iap_unavail": ["Mağaza şu an kullanılamıyor. Biraz sonra tekrar dene.", "Store unavailable right now. Try again in a bit.", "La tienda no está disponible ahora. Inténtalo más tarde.", "A loja está indisponível agora. Tente de novo mais tarde.", "Toko tidak tersedia saat ini. Coba lagi nanti."],
	"iap_fail": ["Satın alma tamamlanamadı", "Purchase could not be completed", "No se pudo completar la compra", "Não foi possível concluir a compra", "Pembelian tidak dapat diselesaikan"],
	"iap_owned_msg": ["Bu ürüne zaten sahipsin, geri yükleniyor…", "You already own this, restoring…", "Ya tienes este artículo, restaurando…", "Você já possui este item, restaurando…", "Kamu sudah memilikinya, memulihkan…"],
	"iap_pending": ["Ödeme onay bekliyor. Onaylanınca ödülün gelecek.", "Payment pending. Your reward arrives once it's approved.", "Pago pendiente. Recibirás tu recompensa al aprobarse.", "Pagamento pendente. Você receberá a recompensa quando for aprovado.", "Pembayaran tertunda. Hadiah datang setelah disetujui."],
	"iap_thanks": ["TEŞEKKÜRLER!", "THANK YOU!", "¡GRACIAS!", "OBRIGADO!", "TERIMA KASIH!"],
	"iap_noads_ok": ["Reklamlar kaldırıldı!", "Ads removed!", "¡Anuncios eliminados!", "Anúncios removidos!", "Iklan dihapus!"],
	"iap_note": ["Ödemeler Google Play üzerinden yapılır.", "Payments are processed by Google Play.", "Los pagos se procesan con Google Play.", "Os pagamentos são processados pelo Google Play.", "Pembayaran diproses oleh Google Play."],
	"iap_buy_btn": ["AL", "BUY", "COMPRAR", "COMPRAR", "BELI"],
	"set_sec_cloud": ["BULUT KAYDI", "CLOUD SAVE", "GUARDADO EN LA NUBE", "SAVE NA NUVEM", "SIMPAN CLOUD"],
	"cl_btn_in": ["Play Games ile giriş yap", "Sign in with Play Games", "Iniciar sesión con Play Games", "Entrar com o Play Games", "Masuk dengan Play Games"],
	"cl_btn_sync": ["Şimdi eşitle", "Sync now", "Sincronizar ahora", "Sincronizar agora", "Sinkronkan sekarang"],
	"cl_off": ["Bu cihazda kullanılamıyor", "Not available on this device", "No disponible en este dispositivo", "Indisponível neste dispositivo", "Tidak tersedia di perangkat ini"],
	"cl_out": ["Giriş yapılmadı: ilerlemen sadece bu cihazda", "Not signed in: progress stays on this device only", "Sin sesión: el progreso solo está en este dispositivo", "Sem login: o progresso fica só neste dispositivo", "Belum masuk: progres hanya di perangkat ini"],
	"cl_signing": ["Giriş yapılıyor…", "Signing in…", "Iniciando sesión…", "Entrando…", "Sedang masuk…"],
	"cl_ok": ["Bulut kaydı açık", "Cloud save is on", "Guardado en la nube activo", "Save na nuvem ativo", "Simpan cloud aktif"],
	"cl_sync": ["Eşitleniyor…", "Syncing…", "Sincronizando…", "Sincronizando…", "Menyinkronkan…"],
	"cl_err": ["Eşitlenemedi, otomatik tekrar denenecek", "Couldn't sync, will retry automatically", "No se pudo sincronizar, se reintentará", "Não foi possível sincronizar, tentaremos de novo", "Gagal sinkron, akan dicoba lagi"],
	"cl_upd": ["Bulut kaydı daha yeni bir sürümle yazılmış. Uygulamayı güncelle.", "Cloud save was written by a newer version. Please update the app.", "El guardado en la nube es de una versión más nueva. Actualiza la app.", "O save na nuvem é de uma versão mais nova. Atualize o app.", "Simpanan cloud dari versi lebih baru. Perbarui aplikasi."],
	"cl_choice": ["Seçim bekleniyor", "Waiting for your choice", "Esperando tu elección", "Aguardando sua escolha", "Menunggu pilihanmu"],
	"cl_last": ["Son eşitleme: %s", "Last sync: %s", "Última sincronización: %s", "Última sincronização: %s", "Sinkron terakhir: %s"],
	"cl_acct": ["Hesap: %s", "Account: %s", "Cuenta: %s", "Conta: %s", "Akun: %s"],
	"ago_now": ["az önce", "just now", "hace un momento", "agora há pouco", "baru saja"],
	"ago_min": ["%d dk önce", "%d min ago", "hace %d min", "há %d min", "%d mnt lalu"],
	"ago_hour": ["%d sa önce", "%d h ago", "hace %d h", "há %d h", "%d jam lalu"],
	"ago_day": ["%d gün önce", "%d d ago", "hace %d d", "há %d d", "%d hari lalu"],
	"cl_ch_title": ["İLERLEME BULUNDU", "PROGRESS FOUND", "PROGRESO ENCONTRADO", "PROGRESSO ENCONTRADO", "PROGRES DITEMUKAN"],
	"cl_ch_body": ["Hem bu cihazda hem Play Games hesabında ilerleme var. Ne yapalım?", "There's progress on this device and on your Play Games account. What should we do?", "Hay progreso en este dispositivo y en tu cuenta de Play Games. ¿Qué hacemos?", "Há progresso neste dispositivo e na sua conta do Play Games. O que fazer?", "Ada progres di perangkat ini dan di akun Play Games. Apa yang dilakukan?"],
	"cl_ch_here": ["BU CİHAZ", "THIS DEVICE", "ESTE DISPOSITIVO", "ESTE DISPOSITIVO", "PERANGKAT INI"],
	"cl_ch_cloud": ["HESABIN", "YOUR ACCOUNT", "TU CUENTA", "SUA CONTA", "AKUNMU"],
	"cl_ch_lv": ["Bölüm %d", "Level %d", "Nivel %d", "Fase %d", "Level %d"],
	"cl_ch_merge": ["BİRLEŞTİR (ÖNERİLEN)", "MERGE (RECOMMENDED)", "COMBINAR (RECOMENDADO)", "COMBINAR (RECOMENDADO)", "GABUNGKAN (DISARANKAN)"],
	"cl_ch_use": ["SADECE HESABI KULLAN", "USE ACCOUNT ONLY", "USAR SOLO LA CUENTA", "USAR SÓ A CONTA", "PAKAI AKUN SAJA"],
	"cl_ch_hint": ["Birleştirince bölüm, terlikler ve bakiyeler birlikte korunur.", "Merging keeps levels, slippers and balances from both.", "Al combinar se conservan niveles, chanclas y saldos de ambos.", "Ao combinar, fases, chinelos e saldos de ambos são mantidos.", "Menggabungkan menjaga level, sandal, dan saldo keduanya."],
	"cl_switched": ["Hesap değişti: ilerleme bu hesaba göre yüklendi", "Account changed: progress loaded for this account", "Cuenta cambiada: progreso cargado para esta cuenta", "Conta alterada: progresso carregado para esta conta", "Akun berubah: progres dimuat untuk akun ini"]
}


func _ready() -> void:
	var cf := ConfigFile.new()
	var saved := ""
	if cf.load(SETTINGS_PATH) == OK:
		saved = String(cf.get_value("s", "lang", ""))
	if saved in LANGS:
		idx = LANGS.find(saved)
	else:
		var sys := OS.get_locale_language()
		if sys == "in":
			sys = "id"
		idx = LANGS.find(sys) if sys in LANGS else 1
	_apply_title()


func lang() -> String:
	return LANGS[idx]


func lang_name() -> String:
	return NAMES[idx]


# Sıradaki dile geç ve kaydet.
func cycle() -> void:
	set_lang((idx + 1) % LANGS.size())


# Verilen sıradaki dile geç ve kaydet (dil listesinden seçim).
func set_lang(i: int) -> void:
	idx = clampi(i, 0, LANGS.size() - 1)
	var cf := ConfigFile.new()
	cf.load(SETTINGS_PATH)
	cf.set_value("s", "lang", LANGS[idx])
	cf.save(SETTINGS_PATH)
	_apply_title()
	changed.emit()


func t(key: String) -> String:
	if not S.has(key):
		return key
	return String(S[key][idx])


# "|" ile ayrılmış değeri liste olarak döndürür.
func l(key: String) -> PackedStringArray:
	return t(key).split("|")


# Rastgele bir kelime (efekt yazıları için).
func pick(key: String) -> String:
	var a := l(key)
	return a[randi() % a.size()]


# Oda adı (THEMES içindeki "bg" numarasına göre).
func room(bg: int) -> String:
	var a := l("rooms")
	return a[bg] if bg < a.size() else ""


# Başlığın 1. satırı uzun dillerde (CHINELO, SANDAL) taşmasın diye küçültme çarpanı.
func k1() -> float:
	return [1.0, 0.95, 1.0, 0.8, 0.9][idx]


func _apply_title() -> void:
	DisplayServer.window_set_title(t("title_full"))
