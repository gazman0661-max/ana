@tool
extends EditorPlugin
## Android export sirasinda LevelPlay eklentisini otomatik ekler (Android Studio GEREKMEZ):
##  - Java kaynagini res://android/build/src altina kopyalar
##  - AndroidManifest'e eklenti kaydini ve izinleri ekler
##  - LevelPlay + Unity Ads bagimliliklarini Gradle'a ekler
## Gerekli: Project > Install Android Build Template, Export > Android > "Use Gradle Build" ACIK.

var export_plugin: AndroidExportPlugin


func _enter_tree() -> void:
	export_plugin = AndroidExportPlugin.new()
	add_export_plugin(export_plugin)


func _exit_tree() -> void:
	remove_export_plugin(export_plugin)
	export_plugin = null


class AndroidExportPlugin extends EditorExportPlugin:
	const SRC_DIR := "res://addons/LevelPlayAds/android_src/com/terlik/levelplayads"
	const DST_DIR := "res://android/build/src/com/terlik/levelplayads"
	const FB_JSON := "res://firebase/google-services.json"
	const FB_VALUES := "res://android/build/res/values/firebase_google_services.xml"
	# >>> Play Console > Oyun Hizmetleri (Play Games Services) > Yapilandirma: "Proje kimligi" (sadece rakam, ornek "123456789012") <<<
	# Bos birakilirsa build yine calisir ama Play Games girisi / bulut kaydi calismaz.
	const PGS_PROJECT_ID := "317205084582"
	const GAMES_VALUES := "res://android/build/res/values/games_ids.xml"

	func _get_name() -> String:
		return "LevelPlayAds"

	func _supports_platform(platform: EditorExportPlatform) -> bool:
		return platform is EditorExportPlatformAndroid

	func _export_begin(features: PackedStringArray, is_debug: bool, path: String, flags: int) -> void:
		if not features.has("android"):
			return
		if not DirAccess.dir_exists_absolute(ProjectSettings.globalize_path("res://android/build")):
			push_error("LevelPlayAds: Android build template yok. Project > Install Android Build Template yap.")
			return
		var dst := ProjectSettings.globalize_path(DST_DIR)
		DirAccess.make_dir_recursive_absolute(dst)
		for fn in DirAccess.get_files_at(SRC_DIR):
			if not fn.ends_with(".java"):
				continue
			var err := DirAccess.copy_absolute(ProjectSettings.globalize_path(SRC_DIR + "/" + fn), dst + "/" + fn)
			if err != OK:
				push_error("LevelPlayAds: %s kopyalanamadi (hata %d). Elle kopyala: android_src/com -> android/build/src/com" % [fn, err])
		_write_firebase_values()
		_write_games_ids()
		_write_notify_icon()
		_patch_gradle()

	# google-services.json -> res/values/firebase_google_services.xml (Google Services Gradle eklentisinin urettigi degerler).
	# Boylece Gradle eklentisi/classpath ayari gerekmez; FirebaseInitProvider bu degerlerle kendiliginden baslar.
	func _write_firebase_values() -> void:
		if not FileAccess.file_exists(FB_JSON):
			push_warning("Firebase: res://firebase/google-services.json yok, Firebase atlandi")
			return
		var d = JSON.parse_string(FileAccess.get_file_as_string(FB_JSON))
		if typeof(d) != TYPE_DICTIONARY or not d.has("client") or d["client"].is_empty():
			push_error("Firebase: google-services.json okunamadi")
			return
		var pi: Dictionary = d.get("project_info", {})
		var cl: Dictionary = d["client"][0]
		var key := ""
		if cl.has("api_key") and not cl["api_key"].is_empty():
			key = String(cl["api_key"][0].get("current_key", ""))
		var vals := {
			"gcm_defaultSenderId": str(pi.get("project_number", "")),
			"google_api_key": key,
			"google_app_id": str(cl["client_info"].get("mobilesdk_app_id", "")),
			"google_crash_reporting_api_key": key,
			"google_storage_bucket": str(pi.get("storage_bucket", "")),
			"project_id": str(pi.get("project_id", "")),
		}
		if pi.has("firebase_url"):
			vals["firebase_database_url"] = str(pi["firebase_url"])
		var xml := '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n'
		for k in vals.keys():
			if String(vals[k]) != "":
				xml += '    <string name="%s" translatable="false">%s</string>\n' % [k, String(vals[k]).xml_escape()]
		xml += "</resources>\n"
		var out := ProjectSettings.globalize_path(FB_VALUES)
		DirAccess.make_dir_recursive_absolute(out.get_base_dir())
		var f := FileAccess.open(out, FileAccess.WRITE)
		if f:
			f.store_string(xml)
			f.close()
			print("Firebase: degerler yazildi (", vals["project_id"], ")")
		else:
			push_error("Firebase: values xml yazilamadi")

	# Play Games proje kimligi -> res/values/games_ids.xml (manifestteki @string/game_services_project_id)
	func _write_games_ids() -> void:
		var id := PGS_PROJECT_ID if PGS_PROJECT_ID != "" else "0"
		if PGS_PROJECT_ID == "":
			push_warning("Play Games: export_plugin.gd icindeki PGS_PROJECT_ID bos; bulut kaydi calismayacak")
		var out := ProjectSettings.globalize_path(GAMES_VALUES)
		DirAccess.make_dir_recursive_absolute(out.get_base_dir())
		var f := FileAccess.open(out, FileAccess.WRITE)
		if f:
			f.store_string('<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <string name="game_services_project_id" translatable="false">%s</string>\n</resources>\n' % id)
			f.close()
		else:
			push_error("Play Games: games_ids.xml yazilamadi")

	# Bildirim kucuk ikonu (beyaz yildiz; Android sadece alfa kanalini kullanir): res/drawable/terlik_notif.xml
	func _write_notify_icon() -> void:
		var out := ProjectSettings.globalize_path("res://android/build/res/drawable/terlik_notif.xml")
		DirAccess.make_dir_recursive_absolute(out.get_base_dir())
		var xml := '<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">\n    <path android:fillColor="#FFFFFFFF" android:pathData="M12,2l2.9,6.3 6.9,0.7 -5.2,4.6 1.5,6.8 -6.1,-3.5 -6.1,3.5 1.5,-6.8 -5.2,-4.6 6.9,-0.7z"/>\n</vector>\n'
		var f := FileAccess.open(out, FileAccess.WRITE)
		if f:
			f.store_string(xml)
			f.close()
		else:
			push_warning("Bildirim ikonu yazilamadi")

	# v29: adquality-sdk .aar'i telefonda Jetifier'i patlatiyor (ASCII disi sinif adi).
	# build.gradle'a exclude ekler, gradle.properties'te Jetifier'i kapatir. Tekrar tekrar eklemez.
	func _patch_gradle() -> void:
		var bg := ProjectSettings.globalize_path("res://android/build/build.gradle")
		if FileAccess.file_exists(bg):
			var txt := FileAccess.get_file_as_string(bg)
			if not txt.contains("terlik-exclude-adquality"):
				txt += "\n// terlik-exclude-adquality\nconfigurations.all {\n    exclude group: 'com.unity3d.ads-mediation', module: 'adquality-sdk'\n}\n"
				var f := FileAccess.open(bg, FileAccess.WRITE)
				if f:
					f.store_string(txt)
					f.close()
					print("LevelPlayAds: build.gradle'a adquality exclude eklendi")
				else:
					push_error("LevelPlayAds: build.gradle yazilamadi")
		var gp := ProjectSettings.globalize_path("res://android/build/gradle.properties")
		var lines := PackedStringArray()
		if FileAccess.file_exists(gp):
			for l in FileAccess.get_file_as_string(gp).split("\n"):
				if not l.strip_edges().begins_with("android.enableJetifier"):
					lines.append(l)
		while lines.size() > 0 and lines[lines.size() - 1].strip_edges() == "":
			lines.remove_at(lines.size() - 1)
		lines.append("android.enableJetifier=false")
		if not "\n".join(lines).contains("android.useAndroidX"):
			lines.append("android.useAndroidX=true")
		var g := FileAccess.open(gp, FileAccess.WRITE)
		if g:
			g.store_string("\n".join(lines) + "\n")
			g.close()

	# Eklentiyi Godot'a tanitir
	func _get_android_manifest_application_element_contents(platform: EditorExportPlatform, debug: bool) -> String:
		return '<meta-data android:name="org.godotengine.plugin.v2.LevelPlayAds" android:value="com.terlik.levelplayads.LevelPlayAdsPlugin" />\n<meta-data android:name="org.godotengine.plugin.v2.TerlikFirebase" android:value="com.terlik.levelplayads.FirebaseBridgePlugin" />\n<meta-data android:name="org.godotengine.plugin.v2.TerlikPlay" android:value="com.terlik.levelplayads.PlayBridgePlugin" />\n<meta-data android:name="org.godotengine.plugin.v2.TerlikNotify" android:value="com.terlik.levelplayads.NotifyBridgePlugin" />\n<meta-data android:name="org.godotengine.plugin.v2.TerlikBilling" android:value="com.terlik.levelplayads.BillingBridgePlugin" />\n<meta-data android:name="org.godotengine.plugin.v2.TerlikGames" android:value="com.terlik.levelplayads.PlayGamesBridgePlugin" />\n<meta-data android:name="com.google.android.gms.games.APP_ID" android:value="@string/game_services_project_id" />\n<receiver android:name="com.terlik.levelplayads.NotifyReceiver" android:exported="false" />\n<receiver android:name="com.terlik.levelplayads.NotifyBootReceiver" android:exported="true"><intent-filter><action android:name="android.intent.action.BOOT_COMPLETED" /><action android:name="android.intent.action.MY_PACKAGE_REPLACED" /></intent-filter></receiver>\n<meta-data android:name="firebase_analytics_collection_enabled" android:value="false" />'

	func _get_android_manifest_element_contents(platform: EditorExportPlatform, debug: bool) -> String:
		return '<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />\n<uses-permission android:name="com.google.android.gms.permission.AD_ID" />\n<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />\n<uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />\n<uses-permission android:name="com.android.vending.BILLING" />'

	# Surumleri LevelPlay dokumanindaki guncel degerlerle karsilastir (docs.unity.com > LevelPlay > Android SDK)
	func _get_android_dependencies(platform: EditorExportPlatform, debug: bool) -> PackedStringArray:
		return PackedStringArray([
			"com.unity3d.ads-mediation:mediation-sdk:9.5.0",
			# Mediation aglari: panelde actigin her agin adaptorunu buraya ekle.
			"com.unity3d.ads-mediation:unityads-adapter:5.5.0",
			"com.unity3d.ads:unity-ads:4.16.6",
			# Firebase Analytics (surumu Firebase surum notlarindan guncelle)
			"com.google.firebase:firebase-analytics:22.1.2",
			# Google Play: uygulama ici guncelleme + uygulama ici puan penceresi
			"com.google.android.play:app-update:2.1.0",
			"com.google.android.play:review:2.0.2",
			# Google Play Faturalandirma (Billing Library 8: 31 Agustos 2026 sonrasi zorunlu) + Play Games Hizmetleri v2 (oturum + bulut kaydi)
			"com.android.billingclient:billing:8.0.0",
			"com.google.android.gms:play-services-games-v2:21.0.0",
		])
