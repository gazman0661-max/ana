package com.terlik.levelplayads;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;

import com.google.firebase.analytics.FirebaseAnalytics;

import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Godot 4 <-> Firebase Analytics koprusu (GDScript tarafi: track.gd, autoload "Track").
 * Toplama varsayilan KAPALI (manifest: firebase_analytics_collection_enabled=false);
 * kullanici Kullanim Sartlari'ni (GDPR bolgesinde ayrica rizayi) kabul edince setEnabled(true) cagrilir.
 */
public class FirebaseBridgePlugin extends GodotPlugin {

    private static final String TAG = "TerlikFirebase";
    private FirebaseAnalytics analytics;

    public FirebaseBridgePlugin(Godot godot) {
        super(godot);
    }

    @Override
    public String getPluginName() {
        return "TerlikFirebase";
    }

    private FirebaseAnalytics fa() {
        if (analytics == null) {
            Activity act = getActivity();
            if (act == null) {
                return null;
            }
            try {
                analytics = FirebaseAnalytics.getInstance(act.getApplicationContext());
            } catch (Throwable t) {
                Log.w(TAG, "Firebase baslatilamadi: " + t);
            }
        }
        return analytics;
    }

    @UsedByGodot
    public void setEnabled(boolean enabled) {
        FirebaseAnalytics f = fa();
        if (f != null) {
            f.setAnalyticsCollectionEnabled(enabled);
        }
    }

    /** params: {"anahtar": deger, ...} seklinde JSON metni (sayi / metin / true-false). */
    @UsedByGodot
    public void logEvent(String name, String paramsJson) {
        FirebaseAnalytics f = fa();
        if (f == null) {
            return;
        }
        Bundle b = new Bundle();
        try {
            if (paramsJson != null && !paramsJson.isEmpty()) {
                JSONObject o = new JSONObject(paramsJson);
                Iterator<String> it = o.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    Object v = o.get(k);
                    if (v instanceof Integer || v instanceof Long) {
                        b.putLong(k, ((Number) v).longValue());
                    } else if (v instanceof Number) {
                        b.putDouble(k, ((Number) v).doubleValue());
                    } else if (v instanceof Boolean) {
                        b.putLong(k, ((Boolean) v) ? 1L : 0L);
                    } else {
                        String sv = String.valueOf(v);
                        b.putString(k, sv.length() > 100 ? sv.substring(0, 100) : sv);
                    }
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "Olay parametreleri okunamadi: " + t);
        }
        f.logEvent(name, b);
    }

    @UsedByGodot
    public void setUserProperty(String name, String value) {
        FirebaseAnalytics f = fa();
        if (f != null) {
            f.setUserProperty(name, value);
        }
    }
}
