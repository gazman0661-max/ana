package com.terlik.levelplayads;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Alarm calisinca bildirimi gosterir. Zamanlama/iptal yardimcilari da burada (NotifyBridgePlugin ve NotifyBootReceiver kullanir).
 * Kurulu alarmlar SharedPreferences'ta (mutlak zamanla) saklanir; telefon yeniden baslayinca ya da uygulama guncellenince geri kurulur.
 */
public class NotifyReceiver extends BroadcastReceiver {

    public static final String ACTION = "com.terlik.levelplayads.NOTIFY";
    static final String TAG = "TerlikNotify";
    static final String CHANNEL = "terlik_reminders";
    static final String PREFS = "terlik_notify";
    static final String KEY = "entries";

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            if (intent == null || !ACTION.equals(intent.getAction())) {
                return;
            }
            show(ctx, intent.getIntExtra("id", 0), intent.getStringExtra("title"), intent.getStringExtra("body"));
        } catch (Throwable t) {
            Log.w(TAG, "Bildirim gosterilemedi: " + t);
        }
    }

    static void show(Context ctx, int id, String title, String body) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null || !nm.areNotificationsEnabled()) {
            return;
        }
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            CharSequence label = ctx.getApplicationInfo().loadLabel(ctx.getPackageManager());
            NotificationChannel ch = new NotificationChannel(CHANNEL, label, NotificationManager.IMPORTANCE_DEFAULT);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(ctx, CHANNEL);
        } else {
            b = new Notification.Builder(ctx);
        }
        int icon = ctx.getResources().getIdentifier("terlik_notif", "drawable", ctx.getPackageName());
        if (icon == 0) {
            icon = ctx.getApplicationInfo().icon;
        }
        Intent launch = ctx.getPackageManager().getLaunchIntentForPackage(ctx.getPackageName());
        if (launch != null) {
            launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            b.setContentIntent(PendingIntent.getActivity(ctx, id, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        }
        b.setSmallIcon(icon)
            .setContentTitle(title == null ? "" : title)
            .setContentText(body == null ? "" : body)
            .setStyle(new Notification.BigTextStyle().bigText(body == null ? "" : body))
            .setColor(0xFFEE7A2A)
            .setAutoCancel(true);
        nm.notify(id, b.build());
    }

    static Intent alarmIntent(Context ctx, int id, String title, String body) {
        Intent i = new Intent(ctx, NotifyReceiver.class);
        i.setAction(ACTION);
        i.putExtra("id", id);
        i.putExtra("title", title);
        i.putExtra("body", body);
        return i;
    }

    /** entries: [{id, at (epoch ms), title, body}] — gecmis olanlar atlanir. Eski alarmlari iptal eder, yenilerini kurar ve kaydeder. */
    public static void scheduleAbs(Context ctx, JSONArray entries) {
        cancelScheduled(ctx);
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) {
            return;
        }
        JSONArray keep = new JSONArray();
        long now = System.currentTimeMillis();
        for (int k = 0; k < entries.length(); k++) {
            try {
                JSONObject e = entries.getJSONObject(k);
                long at = e.getLong("at");
                if (at <= now + 15000L) {
                    continue;
                }
                int id = e.getInt("id");
                PendingIntent pi = PendingIntent.getBroadcast(ctx, id,
                    alarmIntent(ctx, id, e.optString("title"), e.optString("body")),
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi);
                keep.put(e);
            } catch (Throwable t) {
                Log.w(TAG, "Alarm kurulamadi: " + t);
            }
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, keep.toString()).apply();
    }

    /** Kayitli tum alarmlari iptal eder ve kaydi siler. */
    public static void cancelScheduled(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String raw = sp.getString(KEY, "[]");
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        try {
            JSONArray arr = new JSONArray(raw);
            for (int k = 0; k < arr.length(); k++) {
                int id = arr.getJSONObject(k).getInt("id");
                PendingIntent pi = PendingIntent.getBroadcast(ctx, id, alarmIntent(ctx, id, "", ""),
                    PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE);
                if (pi != null) {
                    if (am != null) {
                        am.cancel(pi);
                    }
                    pi.cancel();
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "Alarm iptali: " + t);
        }
        sp.edit().remove(KEY).apply();
    }

    /** Telefon yeniden basladiktan / uygulama guncellendikten sonra kayitli (gelecekteki) alarmlari geri kurar. */
    public static void restore(Context ctx) {
        try {
            String raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]");
            scheduleAbs(ctx, new JSONArray(raw));
        } catch (Throwable t) {
            Log.w(TAG, "Alarm geri yuklenemedi: " + t);
        }
    }
}
