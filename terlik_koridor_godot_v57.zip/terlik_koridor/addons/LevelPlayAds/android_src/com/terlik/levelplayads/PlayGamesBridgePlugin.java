package com.terlik.levelplayads;

import android.app.Activity;
import android.util.Log;

import com.google.android.gms.games.AuthenticationResult;
import com.google.android.gms.games.GamesSignInClient;
import com.google.android.gms.games.PlayGames;
import com.google.android.gms.games.PlayGamesSdk;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.SnapshotsClient;
import com.google.android.gms.games.snapshot.Snapshot;
import com.google.android.gms.games.snapshot.SnapshotContents;
import com.google.android.gms.games.snapshot.SnapshotMetadataChange;
import com.google.android.gms.tasks.Task;

import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.SignalInfo;
import org.godotengine.godot.plugin.UsedByGodot;

import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.Set;

/**
 * Godot 4 <-> Play Games Services v2 koprusu (GDScript tarafi: cloud.gd, autoload "Cloud").
 *  - Oturum: PGS v2 oyun acilirken otomatik oturum acar; reddedilirse signIn() ile elle acilir.
 *  - Bulut kaydi: tek bir "snapshot" (SNAP_NAME). Veri GDScript'te JSON metni olarak uretilir/birlestirilir.
 *    Cakisma (iki cihaz ayni anda yazdi) COZUMU GDScript'tedir: iki surum de metin olarak gonderilir,
 *    GDScript birlestirip cloudResolve() ile geri yollar.
 *
 * Godot'a giden sinyaller:
 *   auth_changed(bool signedIn, String playerId, String displayName)
 *   cloud_loaded(bool ok, String data, String err)     data bos = bulutta kayit yok
 *   cloud_saved(bool ok, String err)
 *   cloud_conflict(String serverData, String localData)
 */
public class PlayGamesBridgePlugin extends GodotPlugin {

    private static final String TAG = "TerlikGames";
    private static final String SNAP_NAME = "terlik_save_v1";

    private boolean sdkInit = false;
    private boolean busy = false;
    private boolean authBusy = false;
    private String lastPlayerId = null;      // null = henuz hic bildirilmedi
    private SnapshotsClient.SnapshotConflict pendingConflict = null;

    public PlayGamesBridgePlugin(Godot godot) {
        super(godot);
    }

    @Override
    public String getPluginName() {
        return "TerlikGames";
    }

    @Override
    public Set<SignalInfo> getPluginSignals() {
        Set<SignalInfo> s = new HashSet<>();
        s.add(new SignalInfo("auth_changed", Boolean.class, String.class, String.class));
        s.add(new SignalInfo("cloud_loaded", Boolean.class, String.class, String.class));
        s.add(new SignalInfo("cloud_saved", Boolean.class, String.class));
        s.add(new SignalInfo("cloud_conflict", String.class, String.class));
        return s;
    }

    private boolean ensureSdk() {
        if (sdkInit) return true;
        Activity act = getActivity();
        if (act == null) return false;
        try {
            PlayGamesSdk.initialize(act.getApplicationContext());
            sdkInit = true;
            return true;
        } catch (Throwable t) {
            Log.w(TAG, "PlayGamesSdk.initialize hatasi: " + t);
            return false;
        }
    }

    // ------------------------------------------------------------ OTURUM
    @UsedByGodot
    public void checkAuth() {
        final Activity act = getActivity();
        if (act == null || !ensureSdk()) {
            reportAuth(false, "", "");
            return;
        }
        if (authBusy) return;
        authBusy = true;
        act.runOnUiThread(() -> {
            try {
                GamesSignInClient c = PlayGames.getGamesSignInClient(act);
                c.isAuthenticated().addOnCompleteListener(task -> handleAuthResult(act, task));
            } catch (Throwable t) {
                authBusy = false;
                Log.w(TAG, "checkAuth hatasi: " + t);
                reportAuth(false, "", "");
            }
        });
    }

    @UsedByGodot
    public void signIn() {
        final Activity act = getActivity();
        if (act == null || !ensureSdk()) {
            reportAuth(false, "", "");
            return;
        }
        if (authBusy) return;
        authBusy = true;
        lastPlayerId = null;               // elle giris: sonuc (basarisiz olsa da) mutlaka bildirilsin
        act.runOnUiThread(() -> {
            try {
                GamesSignInClient c = PlayGames.getGamesSignInClient(act);
                c.signIn().addOnCompleteListener(task -> handleAuthResult(act, task));
            } catch (Throwable t) {
                authBusy = false;
                Log.w(TAG, "signIn hatasi: " + t);
                reportAuth(false, "", "");
            }
        });
    }

    private void handleAuthResult(Activity act, Task<AuthenticationResult> task) {
        boolean ok = false;
        try {
            ok = task.isSuccessful() && task.getResult() != null && task.getResult().isAuthenticated();
        } catch (Throwable t) {
            Log.w(TAG, "auth sonucu okunamadi: " + t);
        }
        if (!ok) {
            authBusy = false;
            reportAuth(false, "", "");
            return;
        }
        try {
            PlayGames.getPlayersClient(act).getCurrentPlayer().addOnCompleteListener(pt -> {
                authBusy = false;
                try {
                    if (pt.isSuccessful() && pt.getResult() != null) {
                        Player p = pt.getResult();
                        reportAuth(true, p.getPlayerId(), p.getDisplayName());
                    } else {
                        Log.w(TAG, "getCurrentPlayer basarisiz: " + pt.getException());
                        reportAuth(false, "", "");
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "player okunamadi: " + t);
                    reportAuth(false, "", "");
                }
            });
        } catch (Throwable t) {
            authBusy = false;
            Log.w(TAG, "getCurrentPlayer hatasi: " + t);
            reportAuth(false, "", "");
        }
    }

    // Yalnizca degisimde bildirir (ayni oyuncu / ayni "oturum yok" tekrar gonderilmez)
    private void reportAuth(boolean signedIn, String playerId, String name) {
        String key = signedIn ? playerId : "";
        if (lastPlayerId != null && lastPlayerId.equals(key)) return;
        lastPlayerId = key;
        emitSignal("auth_changed", signedIn, playerId == null ? "" : playerId, name == null ? "" : name);
    }

    // Uygulama on plana donunce hesap degismis olabilir (Play Games uygulamasindan)
    @Override
    public void onMainResume() {
        super.onMainResume();
        if (sdkInit) {
            checkAuth();
        }
    }

    // ------------------------------------------------------------ BULUT KAYDI
    private interface OpenHandler {
        void onSnapshot(SnapshotsClient sc, Snapshot snapshot);
    }

    private void openSnapshot(final boolean forSave, final OpenHandler handler) {
        final Activity act = getActivity();
        if (act == null || !ensureSdk()) {
            finishFail(forSave, "no_activity");
            return;
        }
        if (busy) {
            finishFail(forSave, "busy");
            return;
        }
        busy = true;
        act.runOnUiThread(() -> {
            try {
                final SnapshotsClient sc = PlayGames.getSnapshotsClient(act);
                sc.open(SNAP_NAME, true, SnapshotsClient.RESOLUTION_POLICY_MANUAL)
                        .addOnSuccessListener(r -> {
                            try {
                                if (r.isConflict()) {
                                    handleConflict(sc, r.getConflict());
                                } else {
                                    handler.onSnapshot(sc, r.getData());
                                }
                            } catch (Throwable t) {
                                Log.w(TAG, "open sonucu islenemedi: " + t);
                                busy = false;
                                finishFail(forSave, "open_result:" + t);
                            }
                        })
                        .addOnFailureListener(e -> {
                            busy = false;
                            Log.w(TAG, "open basarisiz: " + e);
                            finishFail(forSave, String.valueOf(e));
                        });
            } catch (Throwable t) {
                busy = false;
                Log.w(TAG, "open hatasi: " + t);
                finishFail(forSave, String.valueOf(t));
            }
        });
    }

    private void finishFail(boolean forSave, String err) {
        if (forSave) emitSignal("cloud_saved", false, err);
        else emitSignal("cloud_loaded", false, "", err);
    }

    private static String readString(Snapshot s) throws java.io.IOException {
        byte[] b = s.getSnapshotContents().readFully();
        if (b == null || b.length == 0) return "";
        return new String(b, StandardCharsets.UTF_8);
    }

    // Iki surumu (sunucu / bu cihaz) metin olarak GDScript'e yollar; GDScript birlestirip cloudResolve() cagirir.
    private void handleConflict(SnapshotsClient sc, SnapshotsClient.SnapshotConflict conflict) {
        pendingConflict = conflict;
        String server = "";
        String local = "";
        try {
            server = readString(conflict.getSnapshot());
        } catch (Throwable t) {
            Log.w(TAG, "sunucu surumu okunamadi: " + t);
        }
        try {
            local = readString(conflict.getConflictingSnapshot());
        } catch (Throwable t) {
            Log.w(TAG, "yerel surum okunamadi: " + t);
        }
        busy = false;                      // GDScript cloudResolve() ile devam eder
        emitSignal("cloud_conflict", server, local);
    }

    @UsedByGodot
    public void cloudLoad() {
        openSnapshot(false, (sc, snapshot) -> {
            String data = "";
            boolean ok = true;
            String err = "";
            try {
                data = readString(snapshot);
            } catch (Throwable t) {
                ok = false;
                err = "read:" + t;
            }
            final boolean fOk = ok;
            final String fData = data;
            final String fErr = err;
            sc.discardAndClose(snapshot).addOnCompleteListener(x -> {
                busy = false;
                emitSignal("cloud_loaded", fOk, fData, fErr);
            });
        });
    }

    @UsedByGodot
    public void cloudSave(final String data) {
        openSnapshot(true, (sc, snapshot) -> {
            try {
                snapshot.getSnapshotContents().writeBytes(data.getBytes(StandardCharsets.UTF_8));
                SnapshotMetadataChange change = new SnapshotMetadataChange.Builder()
                        .setDescription("Anne Terligi ilerleme")
                        .build();
                sc.commitAndClose(snapshot, change)
                        .addOnSuccessListener(m -> {
                            busy = false;
                            emitSignal("cloud_saved", true, "");
                        })
                        .addOnFailureListener(e -> {
                            busy = false;
                            Log.w(TAG, "commitAndClose basarisiz: " + e);
                            emitSignal("cloud_saved", false, String.valueOf(e));
                        });
            } catch (Throwable t) {
                busy = false;
                Log.w(TAG, "cloudSave hatasi: " + t);
                emitSignal("cloud_saved", false, String.valueOf(t));
            }
        });
    }

    // GDScript'in birlestirdigi son veriyle cakismayi cozer
    @UsedByGodot
    public void cloudResolve(final String merged) {
        final Activity act = getActivity();
        final SnapshotsClient.SnapshotConflict conflict = pendingConflict;
        if (act == null || conflict == null || !ensureSdk()) {
            emitSignal("cloud_saved", false, "no_conflict");
            return;
        }
        if (busy) {
            emitSignal("cloud_saved", false, "busy");
            return;
        }
        busy = true;
        act.runOnUiThread(() -> {
            try {
                final SnapshotsClient sc = PlayGames.getSnapshotsClient(act);
                Snapshot server = conflict.getSnapshot();
                SnapshotContents contents = server.getSnapshotContents();
                contents.writeBytes(merged.getBytes(StandardCharsets.UTF_8));
                SnapshotMetadataChange change = new SnapshotMetadataChange.Builder()
                        .setDescription("Anne Terligi ilerleme")
                        .build();
                pendingConflict = null;
                sc.resolveConflict(conflict.getConflictId(), server.getMetadata().getSnapshotId(), change, contents)
                        .addOnSuccessListener(r -> {
                            try {
                                if (r.isConflict()) {
                                    handleConflict(sc, r.getConflict());     // arka arkaya yeni cakisma: tekrar birlestir
                                } else {
                                    sc.discardAndClose(r.getData()).addOnCompleteListener(x -> {
                                        busy = false;
                                        emitSignal("cloud_saved", true, "");
                                    });
                                }
                            } catch (Throwable t) {
                                busy = false;
                                Log.w(TAG, "resolve sonucu islenemedi: " + t);
                                emitSignal("cloud_saved", false, String.valueOf(t));
                            }
                        })
                        .addOnFailureListener(e -> {
                            busy = false;
                            Log.w(TAG, "resolveConflict basarisiz: " + e);
                            emitSignal("cloud_saved", false, String.valueOf(e));
                        });
            } catch (Throwable t) {
                busy = false;
                Log.w(TAG, "cloudResolve hatasi: " + t);
                emitSignal("cloud_saved", false, String.valueOf(t));
            }
        });
    }
}
