package com.terlik.levelplayads;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import com.google.android.gms.tasks.Task;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.appupdate.AppUpdateOptions;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.UpdateAvailability;
import com.google.android.play.core.review.ReviewInfo;
import com.google.android.play.core.review.ReviewManager;
import com.google.android.play.core.review.ReviewManagerFactory;

import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;

/**
 * Godot 4 <-> Google Play koprusu (GDScript tarafi: play.gd, autoload "Play").
 *  - checkImmediateUpdate(): Play'de yeni surum varsa TAM EKRAN uygulama ici guncelleme baslatir.
 *  - requestReview(): Play'in uygulama ici puan penceresini acar (Google kotasi asilmissa hicbir sey gostermeyebilir).
 * Yalnizca Play'den kurulu uygulamada calisir; elle yuklenen APK'da sessizce basarisiz olur.
 */
public class PlayBridgePlugin extends GodotPlugin {

    private static final String TAG = "TerlikPlay";
    private final Handler ui = new Handler(Looper.getMainLooper());
    private AppUpdateManager updateManager;
    private boolean updateRunning = false;

    public PlayBridgePlugin(Godot godot) {
        super(godot);
    }

    @Override
    public String getPluginName() {
        return "TerlikPlay";
    }

    @UsedByGodot
    public void checkImmediateUpdate() {
        ui.post(this::startUpdateIfNeeded);
    }

    // Guncelleme ekrani yarida kapatildiysa / uygulama arka plandan donduyse devam ettirir.
    @Override
    public void onMainResume() {
        super.onMainResume();
        if (updateManager != null) {
            ui.post(this::startUpdateIfNeeded);
        }
    }

    private void startUpdateIfNeeded() {
        final Activity act = getActivity();
        if (act == null || updateRunning) {
            return;
        }
        try {
            if (updateManager == null) {
                updateManager = AppUpdateManagerFactory.create(act.getApplicationContext());
            }
            final AppUpdateManager mgr = updateManager;
            mgr.getAppUpdateInfo()
                .addOnSuccessListener((AppUpdateInfo info) -> {
                    int av = info.updateAvailability();
                    boolean needed = av == UpdateAvailability.UPDATE_AVAILABLE
                        || av == UpdateAvailability.DEVELOPER_TRIGGERED_UPDATE_IN_PROGRESS;
                    if (needed && info.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)) {
                        updateRunning = true;
                        try {
                            mgr.startUpdateFlow(info, act, AppUpdateOptions.defaultOptions(AppUpdateType.IMMEDIATE))
                                .addOnCompleteListener(t -> updateRunning = false);
                        } catch (Throwable t) {
                            updateRunning = false;
                            Log.w(TAG, "Guncelleme baslatilamadi: " + t);
                        }
                    }
                })
                .addOnFailureListener(e -> Log.i(TAG, "Guncelleme kontrolu yapilamadi (Play disi kurulum olabilir): " + e));
        } catch (Throwable t) {
            Log.w(TAG, "Guncelleme kontrolu hatasi: " + t);
        }
    }

    @UsedByGodot
    public void requestReview() {
        ui.post(() -> {
            final Activity act = getActivity();
            if (act == null) {
                return;
            }
            try {
                final ReviewManager manager = ReviewManagerFactory.create(act.getApplicationContext());
                Task<ReviewInfo> request = manager.requestReviewFlow();
                request.addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        manager.launchReviewFlow(act, task.getResult());
                    } else {
                        Log.i(TAG, "Puan penceresi acilamadi: " + task.getException());
                    }
                });
            } catch (Throwable t) {
                Log.w(TAG, "Puan istegi hatasi: " + t);
            }
        });
    }
}
