package com.terlik.levelplayads;

import android.app.Activity;
import android.util.Log;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.SignalInfo;
import org.godotengine.godot.plugin.UsedByGodot;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Godot 4 <-> Google Play Billing (Billing Library 8.x) koprusu. GDScript tarafi: iap.gd (autoload "Iap").
 * Yalnizca tek seferlik urunler (INAPP): tuketilebilir paketler + kalici urunler (reklamsiz, baslangic paketi).
 *
 * Godot'a giden sinyaller:
 *   billing_ready(bool ok)
 *   products_loaded(String json)          [{id, price, micros, cur}]
 *   purchases_loaded(int code, String json)   [{token, order, products:[id], state(1=alindi,2=beklemede), ack}]
 *   purchase_updated(int code, String json)   odeme penceresi sonucu (code 0 = OK, 1 = kullanici vazgecti, 7 = zaten sahip)
 *   consume_done(String token, int code)
 *   ack_done(String token, int code)
 */
public class BillingBridgePlugin extends GodotPlugin {

    private static final String TAG = "TerlikBilling";

    private BillingClient client;
    private boolean starting = false;
    private boolean everReady = false;
    private final Map<String, ProductDetails> details = new HashMap<>();

    public BillingBridgePlugin(Godot godot) {
        super(godot);
    }

    @Override
    public String getPluginName() {
        return "TerlikBilling";
    }

    @Override
    public Set<SignalInfo> getPluginSignals() {
        Set<SignalInfo> s = new HashSet<>();
        s.add(new SignalInfo("billing_ready", Boolean.class));
        s.add(new SignalInfo("products_loaded", String.class));
        s.add(new SignalInfo("purchases_loaded", Integer.class, String.class));
        s.add(new SignalInfo("purchase_updated", Integer.class, String.class));
        s.add(new SignalInfo("consume_done", String.class, Integer.class));
        s.add(new SignalInfo("ack_done", String.class, Integer.class));
        return s;
    }

    // ------------------------------------------------------------ BAGLANTI
    @UsedByGodot
    public void startConnection() {
        final Activity act = getActivity();
        if (act == null) {
            emitSignal("billing_ready", false);
            return;
        }
        act.runOnUiThread(() -> {
            try {
                if (client == null) {
                    PendingPurchasesParams pending = PendingPurchasesParams.newBuilder()
                            .enableOneTimeProducts()
                            .build();
                    client = BillingClient.newBuilder(act.getApplicationContext())
                            .setListener(purchasesListener)
                            .enablePendingPurchases(pending)
                            .enableAutoServiceReconnection()
                            .build();
                }
                if (client.isReady()) {
                    emitSignal("billing_ready", true);
                    return;
                }
                if (starting) return;
                starting = true;
                client.startConnection(new BillingClientStateListener() {
                    @Override
                    public void onBillingSetupFinished(BillingResult result) {
                        starting = false;
                        boolean ok = result.getResponseCode() == BillingClient.BillingResponseCode.OK;
                        if (ok) everReady = true;
                        else Log.w(TAG, "billing setup failed: " + result.getResponseCode() + " " + result.getDebugMessage());
                        emitSignal("billing_ready", ok);
                    }

                    @Override
                    public void onBillingServiceDisconnected() {
                        starting = false;
                        Log.i(TAG, "billing service disconnected (auto reconnection acik)");
                    }
                });
            } catch (Throwable t) {
                starting = false;
                Log.w(TAG, "startConnection hatasi: " + t);
                emitSignal("billing_ready", false);
            }
        });
    }

    private boolean ready() {
        return client != null && client.isReady();
    }

    // ------------------------------------------------------------ URUNLER
    @UsedByGodot
    public void queryProducts(String idsCsv) {
        if (!ready()) {
            emitSignal("products_loaded", "[]");
            return;
        }
        try {
            List<QueryProductDetailsParams.Product> list = new ArrayList<>();
            for (String id : idsCsv.split(",")) {
                String t = id.trim();
                if (t.isEmpty()) continue;
                list.add(QueryProductDetailsParams.Product.newBuilder()
                        .setProductId(t)
                        .setProductType(BillingClient.ProductType.INAPP)
                        .build());
            }
            QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(list).build();
            client.queryProductDetailsAsync(params, (result, queryResult) -> {
                JSONArray arr = new JSONArray();
                try {
                    if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && queryResult != null) {
                        for (ProductDetails pd : queryResult.getProductDetailsList()) {
                            details.put(pd.getProductId(), pd);
                            ProductDetails.OneTimePurchaseOfferDetails o = pd.getOneTimePurchaseOfferDetails();
                            if (o == null) continue;
                            JSONObject j = new JSONObject();
                            j.put("id", pd.getProductId());
                            j.put("price", o.getFormattedPrice());
                            j.put("micros", o.getPriceAmountMicros());
                            j.put("cur", o.getPriceCurrencyCode());
                            arr.put(j);
                        }
                    } else {
                        Log.w(TAG, "queryProducts code=" + result.getResponseCode() + " " + result.getDebugMessage());
                    }
                } catch (Throwable t) {
                    Log.w(TAG, "queryProducts isleme hatasi: " + t);
                }
                emitSignal("products_loaded", arr.toString());
            });
        } catch (Throwable t) {
            Log.w(TAG, "queryProducts hatasi: " + t);
            emitSignal("products_loaded", "[]");
        }
    }

    // ------------------------------------------------------------ SATIN ALMALAR
    private JSONArray purchasesToJson(List<Purchase> purchases) {
        JSONArray arr = new JSONArray();
        if (purchases == null) return arr;
        for (Purchase p : purchases) {
            try {
                JSONObject j = new JSONObject();
                j.put("token", p.getPurchaseToken());
                j.put("order", p.getOrderId() == null ? "" : p.getOrderId());
                JSONArray prods = new JSONArray();
                for (String id : p.getProducts()) prods.put(id);
                j.put("products", prods);
                j.put("state", p.getPurchaseState());
                j.put("ack", p.isAcknowledged());
                arr.put(j);
            } catch (Throwable t) {
                Log.w(TAG, "purchase json hatasi: " + t);
            }
        }
        return arr;
    }

    // Satin alma akisinin sonucu (odeme penceresi kapaninca ya da beklemedeki odeme onaylaninca)
    private final PurchasesUpdatedListener purchasesListener = (result, purchases) ->
            emitSignal("purchase_updated", result.getResponseCode(), purchasesToJson(purchases).toString());

    @UsedByGodot
    public void queryPurchases() {
        if (!ready()) {
            emitSignal("purchases_loaded", BillingClient.BillingResponseCode.SERVICE_DISCONNECTED, "[]");
            return;
        }
        try {
            QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build();
            client.queryPurchasesAsync(params, (result, purchases) ->
                    emitSignal("purchases_loaded", result.getResponseCode(), purchasesToJson(purchases).toString()));
        } catch (Throwable t) {
            Log.w(TAG, "queryPurchases hatasi: " + t);
            emitSignal("purchases_loaded", BillingClient.BillingResponseCode.ERROR, "[]");
        }
    }

    @UsedByGodot
    public void purchase(String productId) {
        final Activity act = getActivity();
        final ProductDetails pd = details.get(productId);
        if (act == null || !ready() || pd == null) {
            emitSignal("purchase_updated", BillingClient.BillingResponseCode.ITEM_UNAVAILABLE, "[]");
            return;
        }
        act.runOnUiThread(() -> {
            try {
                List<BillingFlowParams.ProductDetailsParams> pl = new ArrayList<>();
                pl.add(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).build());
                BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(pl).build();
                BillingResult r = client.launchBillingFlow(act, flow);
                if (r.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                    Log.w(TAG, "launchBillingFlow code=" + r.getResponseCode() + " " + r.getDebugMessage());
                    emitSignal("purchase_updated", r.getResponseCode(), "[]");
                }
            } catch (Throwable t) {
                Log.w(TAG, "purchase hatasi: " + t);
                emitSignal("purchase_updated", BillingClient.BillingResponseCode.ERROR, "[]");
            }
        });
    }

    @UsedByGodot
    public void consume(String token) {
        if (!ready()) {
            emitSignal("consume_done", token, BillingClient.BillingResponseCode.SERVICE_DISCONNECTED);
            return;
        }
        try {
            ConsumeParams params = ConsumeParams.newBuilder().setPurchaseToken(token).build();
            client.consumeAsync(params, (result, t) -> emitSignal("consume_done", token, result.getResponseCode()));
        } catch (Throwable t) {
            Log.w(TAG, "consume hatasi: " + t);
            emitSignal("consume_done", token, BillingClient.BillingResponseCode.ERROR);
        }
    }

    @UsedByGodot
    public void acknowledge(String token) {
        if (!ready()) {
            emitSignal("ack_done", token, BillingClient.BillingResponseCode.SERVICE_DISCONNECTED);
            return;
        }
        try {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(token).build();
            client.acknowledgePurchase(params, result -> emitSignal("ack_done", token, result.getResponseCode()));
        } catch (Throwable t) {
            Log.w(TAG, "acknowledge hatasi: " + t);
            emitSignal("ack_done", token, BillingClient.BillingResponseCode.ERROR);
        }
    }

    // Uygulama on plana donunce (ornegin Play'den onaylanan beklemedeki odeme) satin almalari yeniden sorgulat
    @Override
    public void onMainResume() {
        super.onMainResume();
        if (everReady && ready()) {
            queryPurchases();
        }
    }

    @Override
    public void onMainDestroy() {
        if (client != null) {
            try {
                client.endConnection();
            } catch (Throwable ignored) {
            }
            client = null;
        }
        super.onMainDestroy();
    }
}
