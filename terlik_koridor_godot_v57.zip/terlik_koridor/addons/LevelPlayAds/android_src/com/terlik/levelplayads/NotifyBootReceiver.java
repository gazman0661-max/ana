package com.terlik.levelplayads;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Telefon acilinca / uygulama guncellenince kayitli bildirim alarmlarini geri kurar. */
public class NotifyBootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent intent) {
        if (intent == null) {
            return;
        }
        String a = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(a) || Intent.ACTION_MY_PACKAGE_REPLACED.equals(a)) {
            NotifyReceiver.restore(ctx);
        }
    }
}
