package com.terlik.levelplayads;

import android.app.Activity;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.util.Log;

import org.godotengine.godot.Godot;
import org.godotengine.godot.plugin.GodotPlugin;
import org.godotengine.godot.plugin.UsedByGodot;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

/**
 * Godot 4 <-> yerel bildirim koprusu (GDScript tarafi: notify.gd, autoload "Notify").
 *  - hasPermission(): bildirim izni var mi (Android 12 ve alti: her zaman true)
 *  - requestPermission(): Android 13+ sistem izin penceresini acar
 *  - scheduleAll(json): [{id, d (kac gun sonra), h, m, title, body}] -> cihazin yerel saatine gore alarmlar kurar
 *  - cancelAll(): kurulu alarmlari iptal eder ve tepsideki bildirimleri temizler
 */
public class NotifyBridgePlugin extends GodotPlugin {

    private static final String TAG = "TerlikNotify";
    private static final String PERM = "android.permission.POST_NOTIFICATIONS";

    public NotifyBridgePlugin(Godot godot) {
        super(godot);
    }

    @Override
    public String getPluginName() {
        return "TerlikNotify";
    }

    @UsedByGodot
    public boolean hasPermission() {
        final Activity act = getActivity();
        if (act == null) {
            return false;
        }
        if (Build.VERSION.SDK_INT < 33) {
            return true;
        }
        return act.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED;
    }

    @UsedByGodot
    public void requestPermission() {
        final Activity act = getActivity();
        if (act == null || Build.VERSION.SDK_INT < 33) {
            return;
        }
        try {
            if (act.checkSelfPermission(PERM) != PackageManager.PERMISSION_GRANTED) {
                act.requestPermissions(new String[]{PERM}, 7731);
            }
        } catch (Throwable t) {
            Log.w(TAG, "Izin istegi hatasi: " + t);
        }
    }

    @UsedByGodot
    public void scheduleAll(String json) {
        final Activity act = getActivity();
        if (act == null) {
            return;
        }
        try {
            JSONArray in = new JSONArray(json);
            JSONArray out = new JSONArray();
            for (int k = 0; k < in.length(); k++) {
                JSONObject e = in.getJSONObject(k);
                Calendar c = Calendar.getInstance();          // cihazin yerel saat dilimi (yaz/kis saati dahil)
                c.add(Calendar.DAY_OF_YEAR, e.getInt("d"));
                c.set(Calendar.HOUR_OF_DAY, e.getInt("h"));
                c.set(Calendar.MINUTE, e.getInt("m"));
                c.set(Calendar.SECOND, 0);
                c.set(Calendar.MILLISECOND, 0);
                JSONObject o = new JSONObject();
                o.put("id", e.getInt("id"));
                o.put("at", c.getTimeInMillis());
                o.put("title", e.optString("title"));
                o.put("body", e.optString("body"));
                out.put(o);
            }
            NotifyReceiver.scheduleAbs(act.getApplicationContext(), out);
        } catch (Throwable t) {
            Log.w(TAG, "Zamanlama hatasi: " + t);
        }
    }

    @UsedByGodot
    public void cancelAll() {
        final Activity act = getActivity();
        if (act == null) {
            return;
        }
        try {
            Context ctx = act.getApplicationContext();
            NotifyReceiver.cancelScheduled(ctx);
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                nm.cancelAll();
            }
        } catch (Throwable t) {
            Log.w(TAG, "Iptal hatasi: " + t);
        }
    }
}
