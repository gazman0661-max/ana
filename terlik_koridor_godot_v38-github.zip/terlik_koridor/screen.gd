extends Node
## EKRAN YARDIMCISI (autoload: "Scr")
## Oyun 720x1280 olarak tasarlandi (kamera ayarlari buna gore). Ekran daha uzunsa (ornegin 20:9)
## oyun alani ekranin ALTINA yaslanir; ustte kalan fazlalik arka plan gorseliyle doldurulur,
## banner da o bosluga biner. Ekran daha genisse (tablet) oyun alani yatayda ortalanir.
## Kullanim: sahnede position = Scr.off | fare icin get_local_mouse_position() | tam ekran ortu icin Scr.full()

const W := 720.0
const H := 1280.0

var size := Vector2(W, H)   # gorunur alanin tamami (oyun koordinati)
var off := Vector2.ZERO     # oyun alaninin sol-ust kosesinin ekrandaki yeri (oyun koordinati)


func _ready() -> void:
	get_tree().root.size_changed.connect(_update)
	_update()
	call_deferred("_update")


func _update() -> void:
	var s := get_viewport().get_visible_rect().size
	size = Vector2(maxf(s.x, W), maxf(s.y, H))
	off = Vector2((size.x - W) * 0.5, size.y - H)


# Tum ekrani (sarsinti payi ile) kaplayan dikdortgen: karartma / flas / fade icin.
func full() -> Rect2:
	return Rect2(-off.x - 40.0, -off.y - 40.0, size.x + 80.0, size.y + 80.0)


# Ekranin ortasi (sahnenin yerel koordinatinda).
func center() -> Vector2:
	return size * 0.5 - off


# Gorseli yamultmadan tum ekrani ortecek boyut (fazlasi kirpilir).
func cover_size(tex: Texture2D) -> Vector2:
	var ts := Vector2(float(tex.get_width()), float(tex.get_height()))
	var k := maxf(size.x / ts.x, size.y / ts.y)
	return ts * k


# Ana oyun arka plani: 720x1280 alana oturur. Fazlalik:
#  - ustte (uzun ekran): gorselin ust seridi aynalanarak devam eder + hafif koyu gecis
#  - yanlarda (genis ekran): gorsel yamulmadan buyutulup karartilir
func draw_game_bg(ci: CanvasItem, tex: Texture2D) -> void:
	if tex == null:
		ci.draw_rect(full(), Color(0.9, 0.8, 0.5))
		return
	if off.x > 0.5:
		var cs := cover_size(tex)
		ci.draw_texture_rect(tex, Rect2(center() - cs * 0.5, cs), false, Color(0.45, 0.42, 0.42))
	if off.y > 0.5:
		var tw := float(tex.get_width())
		var th := float(tex.get_height())
		var e := off.y
		ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2(1.0, -1.0))
		ci.draw_texture_rect_region(tex, Rect2(0.0, 0.0, W, e), Rect2(0.0, 0.0, tw, minf(th, e * th / H)))
		ci.draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	ci.draw_texture_rect(tex, Rect2(0.0, 0.0, W, H), false)
	if off.y > 0.5:
		var top := Color(0.08, 0.02, 0.15, 0.45)
		var clear := Color(0.08, 0.02, 0.15, 0.0)
		ci.draw_polygon(PackedVector2Array([Vector2(0.0, -off.y), Vector2(W, -off.y), Vector2(W, 0.0), Vector2(0.0, 0.0)]), PackedColorArray([top, top, clear, clear]))
