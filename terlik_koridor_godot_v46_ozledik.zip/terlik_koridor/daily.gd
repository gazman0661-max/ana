extends Node
## GÜNLÜK ÖDÜL + GÜNLÜK GÖREVLER + GÜÇ-UP ENVANTERİ (autoload "Daily")
##
## GÜNLÜK ÖDÜL
##  - Hafta Pazartesi'de başlar (Gün 1), Pazar günü biter (Gün 7). Ödül, haftanın gününe bağlıdır: bir gün atlanırsa
##    oyuncu girdiği günün ödülünü alır, atlanan günün ödülü yanar.
##  - Pazar (7. gün) EKSTRA ödülü sadece o hafta 7 günün hepsinde giriş yapıp ödülünü alanlara verilir.
##  - Her hafta 4 tablodan biri kullanılır (hafta numarası % 4), yani ödüller haftadan haftaya değişir.
##  - Ödüller "damla damla": küçük coin miktarları + arada bir güç-up. Tablolar aşağıda (WEEKS / SUNDAY_EXTRA).
##  - Güç-up 6. bölümden önce işe yaramadığı için (POWERUP_MIN_LEVEL), o seviyeye gelmemiş oyuncuda güç-up ödülü
##    PU_AS_COIN coine çevrilir.
##
## GÖREVLER
##  - Her gün 3 görev (gün numarasından üretilir, gece yarısı yenilenir). Hedefe ulaşınca Görevler sayfasından AL ile coin alınır.
##  - Oyun içinden Daily.note("memo"/"stars"/"levels"/"smash"/"powerup"/"threestar"/"shots", n) çağrılır.
##
## ENVANTER: günlük ödülden gelen güç-up'lar (aim / slow / double). Oyunda güç-up popup'ında "Envanterden kullan" olarak çıkar.
##
## Veri: user://terlik_daily.cfg (Ayarlar > Bastan Basla bu dosyaya dokunmaz). Coin: user://terlik_save.cfg  p/coins.

signal quest_completed(idx: int)

const PATH := "user://terlik_daily.cfg"
const SAVE_PATH := "user://terlik_save.cfg"
const POWERUP_MIN_LEVEL := 6          # main.gd POWERUP_MIN_LEVEL ile aynı olmalı
const PU_AS_COIN := 40                # 6. bölümü görmemiş oyuncuda güç-up yerine verilen coin
const PU_IDS := ["aim", "slow", "double"]

# Haftalık ödül tabloları (Pzt..Paz). Her gün: {"coin": n, "aim": n, "slow": n, "double": n}
const WEEKS := [
	[{"coin": 25}, {"slow": 1}, {"coin": 30}, {"aim": 1}, {"coin": 35}, {"double": 1, "coin": 15}, {"coin": 40}],
	[{"aim": 1}, {"coin": 30}, {"double": 1}, {"coin": 35}, {"slow": 1}, {"coin": 40}, {"coin": 45}],
	[{"coin": 30}, {"double": 1}, {"coin": 30}, {"slow": 1}, {"coin": 40}, {"aim": 1, "coin": 10}, {"coin": 45}],
	[{"slow": 1, "coin": 10}, {"coin": 35}, {"aim": 1}, {"coin": 35}, {"double": 1}, {"coin": 45}, {"coin": 40}],
]
# 7 günün hepsine girenlere Pazar günü bu ekstra eklenir (hafta tablosuyla aynı sırada)
const SUNDAY_EXTRA := [
	{"coin": 60, "aim": 1},
	{"coin": 60, "double": 1},
	{"coin": 60, "slow": 1},
	{"coin": 70, "double": 1},
]

# Görev havuzu: hedef seçenekleri + hedef başına coin (ödül = hedef * coin_per, 5'e yuvarlanır, en az 15)
const QPOOL := {
	"memo": {"targets": [30, 40, 50], "coin_per": 0.7},
	"stars": {"targets": [15, 20, 30], "coin_per": 1.2},
	"levels": {"targets": [3, 4, 5], "coin_per": 7.0},
	"smash": {"targets": [4, 6, 8], "coin_per": 3.0},
	"powerup": {"targets": [2, 3], "coin_per": 15.0},
	"threestar": {"targets": [2, 3], "coin_per": 12.0},
	"shots": {"targets": [25, 35, 45], "coin_per": 0.6},
}
const QUEST_COUNT := 3

# SENİ ÖZLEDİK (geri dönüş) hediyesi: 3+ gün girmeyene WB3, 7+ gün girmeyene WB7 (büyük olan geçerli, ikisi birden verilmez).
# Aynı oyuncuya en fazla WB_COOLDOWN günde bir verilir (alındığı günden itibaren).
const WB3 := {"coin": 300, "aim": 0, "slow": 0, "double": 0}
const WB7 := {"coin": 500, "aim": 1, "slow": 1, "double": 1}
const WB_COOLDOWN := 14

var wb_shown := false           # geri dönüş penceresi bu oturumda gösterildi mi
var last_seen := -1             # oyunun son açıldığı gün
var last_wb := -100000          # geri dönüş hediyesinin alındığı son gün
var wb_pending := 0             # bekleyen geri dönüş hediyesi: 0 yok | 3 | 7
var auto_shown := false         # günlük ödül penceresi bu oturumda kendiliğinden açıldı mı

var last_claim := -1            # son ödül alınan gün (gün numarası)
var week_start := -1            # mask'ın ait olduğu haftanın Pazartesi gün numarası
var mask := 0                   # bu hafta ödülü alınan günler (bit 0 = Pazartesi)
var inv := {"aim": 0, "slow": 0, "double": 0}

var q_day := -1
var q_type: Array = []
var q_target: Array = []
var q_prog: Array = []
var q_claimed: Array = []
var q_coin: Array = []


func _ready() -> void:
	_load()
	ensure_quests()
	check_return()


# Uygulama arka plandan uzun süre sonra dönünce de (süreç ölmediyse) geri dönüş kontrolü yapılır.
func _notification(what: int) -> void:
	if what == NOTIFICATION_APPLICATION_RESUMED:
		check_return()


# ---------------- ZAMAN (cihazın yerel saati) ----------------
func _local() -> Dictionary:
	return Time.get_datetime_dict_from_system(false)


# Yerel takvim günü numarası (tarihi UTC gibi sayıp 86400'e bölerek; ardışık günler ardışık sayı).
func today() -> int:
	var d := _local()
	var u := Time.get_unix_time_from_datetime_dict({"year": d["year"], "month": d["month"], "day": d["day"], "hour": 0, "minute": 0, "second": 0})
	return int(floor(float(u) / 86400.0))


# Pazartesi = 0 ... Pazar = 6
func weekday() -> int:
	return (int(_local()["weekday"]) + 6) % 7


func seconds_to_midnight() -> int:
	var d := _local()
	return 86400 - (int(d["hour"]) * 3600 + int(d["minute"]) * 60 + int(d["second"]))


func seconds_of_day() -> int:
	var d := _local()
	return int(d["hour"]) * 3600 + int(d["minute"]) * 60 + int(d["second"])


# ---------------- KAYIT ----------------
func _load() -> void:
	var cf := ConfigFile.new()
	if cf.load(PATH) != OK:
		return
	last_seen = int(cf.get_value("d", "last_seen", -1))
	last_wb = int(cf.get_value("d", "last_wb", -100000))
	wb_pending = int(cf.get_value("d", "wb_pending", 0))
	last_claim = int(cf.get_value("d", "last_claim", -1))
	week_start = int(cf.get_value("d", "week_start", -1))
	mask = int(cf.get_value("d", "mask", 0))
	for id in PU_IDS:
		inv[id] = maxi(0, int(cf.get_value("i", id, 0)))
	q_day = int(cf.get_value("q", "day", -1))
	q_type = cf.get_value("q", "type", [])
	q_target = cf.get_value("q", "target", [])
	q_prog = cf.get_value("q", "prog", [])
	q_claimed = cf.get_value("q", "claimed", [])
	q_coin = cf.get_value("q", "coin", [])


func _save() -> void:
	var cf := ConfigFile.new()
	cf.set_value("d", "last_seen", last_seen)
	cf.set_value("d", "last_wb", last_wb)
	cf.set_value("d", "wb_pending", wb_pending)
	cf.set_value("d", "last_claim", last_claim)
	cf.set_value("d", "week_start", week_start)
	cf.set_value("d", "mask", mask)
	for id in PU_IDS:
		cf.set_value("i", id, int(inv[id]))
	cf.set_value("q", "day", q_day)
	cf.set_value("q", "type", q_type)
	cf.set_value("q", "target", q_target)
	cf.set_value("q", "prog", q_prog)
	cf.set_value("q", "claimed", q_claimed)
	cf.set_value("q", "coin", q_coin)
	cf.save(PATH)


func best_level() -> int:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		return maxi(1, int(cf.get_value("p", "level", 1)))
	return 1


func get_coins() -> int:
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		return maxi(0, int(cf.get_value("p", "coins", 0)))
	return 0


func add_coins(n: int) -> void:
	if n <= 0:
		return
	var cf := ConfigFile.new()
	cf.load(SAVE_PATH)
	cf.set_value("p", "coins", maxi(0, int(cf.get_value("p", "coins", 0))) + n)
	cf.save(SAVE_PATH)


# ---------------- ENVANTER ----------------
func inv_count(id: String) -> int:
	return int(inv.get(id, 0))


func inv_total() -> int:
	var s := 0
	for id in PU_IDS:
		s += int(inv[id])
	return s


# Envanterden 1 adet harcar. true = vardı ve harcandı.
func use_inv(id: String) -> bool:
	if int(inv.get(id, 0)) <= 0:
		return false
	inv[id] = int(inv[id]) - 1
	_save()
	return true


# ---------------- GÜNLÜK ÖDÜL ----------------
func _roll_week() -> void:
	var ws := today() - weekday()
	if week_start != ws:
		week_start = ws
		mask = 0


func week_variant() -> int:
	var ws := today() - weekday()
	return int(floor(float(ws) / 7.0)) % WEEKS.size()


func can_claim() -> bool:
	return today() > last_claim


# Pazartesi'den dünkü güne kadar ödüller eksiksiz alındı mı (Pazar'daki ekstra için)
func week_intact() -> bool:
	_roll_week()
	var wd := weekday()
	for i in wd:
		if (mask & (1 << i)) == 0:
			return false
	return true


# Bugünkü seri: bugün dahil kaç gün üst üste (yalnızca bu hafta içinde). Seri kopmuşsa 1.
func streak_today() -> int:
	_roll_week()
	var wd := weekday()
	var n := 1
	var i := wd - 1
	while i >= 0 and (mask & (1 << i)) != 0:
		n += 1
		i -= 1
	return n


# Bugünün ödülü (güç-up -> coin çevrimi uygulanmış). {"coin","aim","slow","double","extra":bool,"day":1..7}
func reward_today() -> Dictionary:
	_roll_week()
	var wd := weekday()
	var v := week_variant()
	var base: Dictionary = WEEKS[v][wd]
	var r := {"coin": 0, "aim": 0, "slow": 0, "double": 0, "extra": false, "day": wd + 1}
	for k in base.keys():
		r[k] = int(r[k]) + int(base[k])
	if wd == 6 and week_intact():
		var ex: Dictionary = SUNDAY_EXTRA[v]
		for k in ex.keys():
			r[k] = int(r[k]) + int(ex[k])
		r["extra"] = true
	return _gate(r)


# 6. bölümü görmemiş oyuncuda güç-up'ları coine çevirir (düğmeler o bölümden önce görünmüyor).
func _gate(r: Dictionary) -> Dictionary:
	if best_level() < POWERUP_MIN_LEVEL:
		for id in PU_IDS:
			r["coin"] = int(r["coin"]) + int(r[id]) * PU_AS_COIN
			r[id] = 0
	return r


# ---------------- SENİ ÖZLEDİK (GERİ DÖNÜŞ) ----------------
# Oyun açılınca çağrılır: son girişten bu yana geçen güne göre bekleyen hediye belirlenir.
func check_return() -> void:
	var td := today()
	if last_seen < 0:                      # ilk kurulum: hediye yok
		last_seen = td
		_save()
		return
	if td <= last_seen:                    # aynı gün ya da cihaz saati geri alınmış
		return
	var away := td - last_seen
	var tier := 7 if away >= 7 else (3 if away >= 3 else 0)
	if tier > 0 and td - last_wb >= WB_COOLDOWN and tier > wb_pending:
		wb_pending = tier
	last_seen = td
	_save()


func winback_reward() -> Dictionary:
	var src: Dictionary = WB7 if wb_pending >= 7 else WB3
	var r := {"coin": int(src["coin"]), "aim": int(src["aim"]), "slow": int(src["slow"]), "double": int(src["double"]), "extra": false, "day": 0, "tier": wb_pending}
	return _gate(r)


func claim_winback() -> Dictionary:
	if wb_pending <= 0:
		return {}
	var r := winback_reward()
	var tier := wb_pending
	wb_pending = 0
	last_wb = today()
	add_coins(int(r["coin"]))
	for id in PU_IDS:
		inv[id] = int(inv[id]) + int(r[id])
	_save()
	Track.event("winback_claim", {"item_name": "tier_%d" % tier, "value": int(r["coin"])})
	return r


# Bildirim zamanlayıcısı için: dn günündeki (özel) geri dönüş bildirimi kullanılabilir mi (cooldown dolmuş mu)
func winback_allowed(dn: int) -> bool:
	return dn - last_wb >= WB_COOLDOWN


# Ödülü teslim alır (coin dosyaya, güç-up envantere). Alınamazsa boş sözlük döner.
func claim() -> Dictionary:
	if not can_claim():
		return {}
	var r := reward_today()
	var wd := weekday()
	mask |= (1 << wd)
	last_claim = today()
	add_coins(int(r["coin"]))
	for id in PU_IDS:
		inv[id] = int(inv[id]) + int(r[id])
	_save()
	Track.event("daily_claim", {"item_name": "day_%d" % (wd + 1), "value": int(r["coin"]), "extra": 1 if bool(r["extra"]) else 0})
	return r


# ---------------- GÖREVLER ----------------
func ensure_quests() -> void:
	var td := today()
	if q_day == td and q_type.size() == QUEST_COUNT:
		return
	if q_day > td and q_type.size() == QUEST_COUNT:
		return                         # cihaz saati geri alınmış: eski görevler kalsın
	_generate_quests(td)


func _generate_quests(td: int) -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = td * 7919 + 13
	var types: Array = []
	for k in QPOOL.keys():
		if k == "powerup" and best_level() < POWERUP_MIN_LEVEL:
			continue
		types.append(k)
	types.sort()
	for i in range(types.size() - 1, 0, -1):          # sabit tohumlu karıştırma
		var j := rng.randi_range(0, i)
		var tmp = types[i]
		types[i] = types[j]
		types[j] = tmp
	q_day = td
	q_type = []
	q_target = []
	q_prog = []
	q_claimed = []
	q_coin = []
	for i in QUEST_COUNT:
		var ty: String = types[i]
		var ts: Array = QPOOL[ty]["targets"]
		var tg: int = int(ts[rng.randi_range(0, ts.size() - 1)])
		var coin := maxi(15, int(round(float(tg) * float(QPOOL[ty]["coin_per"]) / 5.0)) * 5)
		q_type.append(ty)
		q_target.append(tg)
		q_prog.append(0)
		q_claimed.append(false)
		q_coin.append(coin)
	_save()


func quest_done(i: int) -> bool:
	return int(q_prog[i]) >= int(q_target[i])


# Tamamlanmış ama ödülü henüz alınmamış görev sayısı (ikon üstündeki kırmızı nokta)
func quests_ready_count() -> int:
	ensure_quests()
	var n := 0
	for i in q_type.size():
		if quest_done(i) and not bool(q_claimed[i]):
			n += 1
	return n


# Henüz ödülü alınmamış görev var mı (bildirim metni için)
func quests_open_count() -> int:
	ensure_quests()
	var n := 0
	for i in q_type.size():
		if not bool(q_claimed[i]):
			n += 1
	return n


# Oyundan ilerleme bildirir. Yeni tamamlanan görev indekslerini döndürür.
func note(kind: String, n: int = 1) -> Array:
	ensure_quests()
	var done: Array = []
	var changed := false
	for i in q_type.size():
		if q_type[i] != kind or bool(q_claimed[i]) or quest_done(i):
			continue
		q_prog[i] = mini(int(q_prog[i]) + n, int(q_target[i]))
		changed = true
		if quest_done(i):
			done.append(i)
	if changed:
		_save()
	for i in done:
		quest_completed.emit(i)
	return done


# Görev ödülünü verir (coin). {"coin": n} ya da boş sözlük.
func claim_quest(i: int) -> Dictionary:
	ensure_quests()
	if i < 0 or i >= q_type.size() or bool(q_claimed[i]) or not quest_done(i):
		return {}
	q_claimed[i] = true
	var c := int(q_coin[i])
	add_coins(c)
	_save()
	Track.event("quest_claim", {"item_name": String(q_type[i]), "value": c})
	return {"coin": c, "aim": 0, "slow": 0, "double": 0}
