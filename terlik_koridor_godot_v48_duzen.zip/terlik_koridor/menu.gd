extends Node2D
## ANA MENÜ: dalgalı başlık, düşen terlikler, dönen ışınlar, Memo (dokununca sersemler),
## büyük OYNA butonu (basınca terlik Memo'ya uçar, sonra oyun başlar), NASIL OYNANIR penceresi.

const U = preload("res://fx_util.gd")
const W := 720.0
const H := 1280.0
const GAME_SCENE := "res://main.tscn"
const SAVE_PATH := "user://terlik_save.cfg"

# >>> BURAYI DOLDUR: Play Store paket adların ve politika bağlantıların <<<
const VERSION := "v2.7.0"
const GAMES = [
	{"name": "Worlds Merge: Puzzle & Town", "pkg": "com.sitora.ai", "col": Color(0.93, 0.50, 0.15), "icon": "res://assets/worlds_merge_icon.png"},
]

enum Pose { DIL, GERGIN, SERSEM }

var t := 0.0
var font: Font
var bg: Texture2D
var tex_slip: Texture2D
var game_icons := {}           # oyun kartı ikonları (başlangıçta yüklenir)
var tex_memo := {}
var ad_off := 0.0
var best_level := 1

var parts: Array = []          # düşen terlikler
var sparks: Array = []         # parlayan yıldızlar

var memo_pose: int = Pose.DIL
var memo_pose_t := 0.0         # sersem / gergin pozunun kalan süresi
var memo_taps := 0
var memo_talk := ""
var memo_talk_t := 0.0

var press_id := ""             # basılı tutulan buton
var help_open := false
var help_t := 0.0

var starting := false          # OYNA'ya basıldı, geçiş animasyonu
var start_t := 0.0
var shake := 0.0
var fx: Array = []             # {pos, text, t}

var st_play: StyleBoxFlat
var st_play_hi: StyleBoxFlat
var st_help: StyleBoxFlat
var st_help_hi: StyleBoxFlat
var st_panel: StyleBoxFlat
var st_sheet: StyleBoxFlat
var st_box: StyleBoxFlat
var st_card: StyleBoxFlat
var st_toast: StyleBoxFlat

var page := "main"             # "main" | "settings" | "games"
var cur_items: Array = []
var cur_h := 0.0
var set_items: Array = []
var set_h := 0.0
var game_items: Array = []
var game_h := 0.0
var scroll := 0.0
var scroll_start := 0.0
var scroll_drag := false
var drag_moved := false
var press_pos := Vector2.ZERO
var opts := {"music": true, "sfx": true, "vib": true, "fx": true, "notif": true}
var backup_open := false       # yedekleme bilgi penceresi açık mı
var cons_open := false         # reklam rızası penceresi açık mı (yalnızca AB/AEA/UK)
var lang_open := false         # dil listesi penceresi açık mı
var toast_txt := ""
var toast_t := 0.0

# ---- günlük ödül / görevler / cüzdan ----
var modal := ""                # açık pencere: "" | "notif" | "daily"
var modal_t := 0.0
var modal_pending := ""        # açılış animasyonu bitince kendiliğinden açılacak pencere
var open_after := 1.9          # modal_pending bu saniyeden sonra açılır
var daily_view := 0            # 0 = ödül alınabilir | 1 = alma animasyonu | 2 = bugün zaten alındı (bilgi)
var daily_t := 0.0             # alma animasyonu saati
var daily_wb := false          # pencere "seni özledik" (geri dönüş) hediyesi mi
var daily_rw := {}             # bugünün ödülü
var disp_coins := 0.0          # ekranda görünen coin (uçan coinler varınca artar)
var land_coins := 0            # varmış coinlerle gösterilmesi gereken toplam
var disp_pu := {"aim": 0, "slow": 0, "double": 0}
var chip_pop := {"coin": 0.0, "gem": 0.0, "aim": 0.0, "slow": 0.0, "double": 0.0}   # varış parlaması
var rflyers: Array = []        # uçan ödüller
var rfloats: Array = []        # yükselen "+25" yazıları
var confetti: Array = []       # konfeti / yıldız patlaması
var quest_flash := [0.0, 0.0, 0.0]
var quest_btn_press := -1
var wallet_show := false       # uçuş sırasında güç-up çubuğu zorla görünür
var land_count := 0
var disp_gems := 0.0           # ekranda görünen elmas
var land_gems := 0
var buy_id := ""               # satın alma onayındaki terlik
var buy_gem := false           # elmasla mı alınıyor
var own_id := ""               # yeni alınan terlik (kutlama penceresi)
var gem_n := 0                 # elmas kazanma penceresindeki miktar
var gem_t := 0.0
var gem_spawned := false
var gem_spawn_t := 0.0
var gem_busy := false          # elmas reklamı açık
var st_gem_btn: StyleBoxFlat
var st_coin_btn: StyleBoxFlat
var st_chip: StyleBoxFlat
var st_glow: StyleBoxFlat
var st_white: StyleBoxFlat
var st_flash: StyleBoxFlat
var st_card_gold: StyleBoxFlat
var st_card_dim: StyleBoxFlat
var st_dis: StyleBoxFlat
var st_bar: StyleBoxFlat
var st_bar_fill: StyleBoxFlat


func _ready() -> void:
	randomize()
	font = U.make_font()
	bg = load("res://assets/bg0.jpg")
	tex_slip = load("res://assets/terlik.png")
	for gi in GAMES.size():
		var ip: String = String(GAMES[gi].get("icon", ""))
		if ip != "" and ResourceLoader.exists(ip):
			game_icons[gi] = load(ip)
	for n in ["memo_dil", "memo_gergin", "memo_sersem"]:
		tex_memo[n] = load("res://assets/%s.png" % n)
	var cf := ConfigFile.new()
	if cf.load(SAVE_PATH) == OK:
		best_level = maxi(1, int(cf.get_value("p", "level", 1)))
	ad_off = Ads.banner_h
	if U.get_setting("terms_ok", false):
		Play.check_update()
	Ads.banner_height_changed.connect(_on_banner)
	var rng := RandomNumberGenerator.new()
	rng.seed = 11
	for i in 11:
		parts.append({"x": rng.randf_range(0.0, W), "y": rng.randf_range(0.0, H + 260.0), "v": rng.randf_range(55.0, 120.0),
			"r": rng.randf_range(0.0, TAU), "rv": rng.randf_range(-2.5, 2.5), "h": rng.randf_range(70.0, 130.0), "ph": rng.randf_range(0.0, TAU)})
	for i in 20:
		sparks.append({"x": rng.randf_range(20.0, 700.0), "y": rng.randf_range(60.0, 1220.0), "ph": rng.randf_range(0.0, TAU), "s": rng.randf_range(9.0, 22.0)})
	st_play = _style(Color(0.22, 0.78, 0.30), Color(0.08, 0.30, 0.12), 34)
	st_play_hi = _style(Color(0.55, 0.95, 0.55, 0.65), Color(0, 0, 0, 0), 26)
	st_help = _style(Color(0.93, 0.45, 0.25), Color(0.35, 0.13, 0.05), 28)
	st_help_hi = _style(Color(1.0, 0.75, 0.5, 0.6), Color(0, 0, 0, 0), 20)
	st_panel = _style(Color(0.99, 0.94, 0.80), Color(0.35, 0.13, 0.05), 30)
	st_sheet = StyleBoxFlat.new()
	st_sheet.bg_color = Color(0.99, 0.94, 0.80)
	st_sheet.corner_radius_top_left = 44
	st_sheet.corner_radius_top_right = 44
	st_box = _style(Color.WHITE, Color(0.35, 0.13, 0.05), 12)
	st_box.set_border_width_all(4)
	st_box.shadow_size = 0
	st_card = _style(Color(1.0, 0.98, 0.9), Color(0.35, 0.13, 0.05), 28)
	st_toast = _style(Color(0.15, 0.06, 0.04, 0.92), Color(0, 0, 0, 0), 24)
	for k in opts.keys():
		opts[k] = U.get_setting(k, true)
	_build_settings()
	_build_games()
	st_chip = StyleBoxFlat.new()
	st_chip.bg_color = Color(0.10, 0.04, 0.16, 0.86)
	st_chip.set_corner_radius_all(30)
	st_chip.set_border_width_all(3)
	st_chip.border_color = Color(1.0, 0.76, 0.32, 0.95)
	st_glow = StyleBoxFlat.new()
	st_glow.bg_color = Color(1.0, 0.9, 0.4, 0.5)
	st_glow.set_corner_radius_all(36)
	st_white = StyleBoxFlat.new()
	st_white.bg_color = Color(1, 1, 0.85, 0.0)
	st_white.set_corner_radius_all(28)
	st_flash = StyleBoxFlat.new()
	st_flash.bg_color = Color(1, 1, 1, 0.0)
	st_flash.set_corner_radius_all(48)
	st_card_gold = _style(Color(1.0, 0.97, 0.76), Color(0.95, 0.65, 0.10), 28)
	st_card_dim = _style(Color(0.90, 0.87, 0.78), Color(0.55, 0.45, 0.40), 28)
	st_dis = _style(Color(0.66, 0.62, 0.58), Color(0.42, 0.38, 0.35), 30)
	st_bar = StyleBoxFlat.new()
	st_bar.bg_color = Color(0.25, 0.12, 0.08, 0.55)
	st_bar.set_corner_radius_all(15)
	st_bar_fill = StyleBoxFlat.new()
	st_bar_fill.bg_color = Color(0.25, 0.80, 0.36)
	st_bar_fill.set_corner_radius_all(15)
	st_gem_btn = _style(Color(0.58, 0.38, 0.96), Color(0.22, 0.10, 0.48), 34)
	st_coin_btn = _style(Color(0.98, 0.78, 0.25), Color(0.55, 0.32, 0.05), 30)
	Ads.rewarded_earned.connect(_on_gem_earned)
	Ads.rewarded_closed.connect(func(): gem_busy = false)
	Daily.ensure_quests()
	_sync_wallet()
	# açılışta sırayla: bildirim izni (ilk açılış) -> günlük ödül (alınabilirse, oturumda bir kez)
	if Notify.should_ask():
		modal_pending = "notif"
	elif Daily.wb_pending > 0 and not Daily.wb_shown:
		modal_pending = "back"
	elif Daily.can_claim() and not Daily.auto_shown:
		modal_pending = "daily"


func _on_banner(h: float) -> void:
	ad_off = h


func _style(c: Color, border: Color, radius: int) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = c
	s.set_corner_radius_all(radius)
	if border.a > 0.0:
		s.set_border_width_all(7)
		s.border_color = border
		s.shadow_color = Color(0, 0, 0, 0.35)
		s.shadow_size = 10
		s.shadow_offset = Vector2(0, 8)
	return s


# ---------------- DÜZEN ----------------
func _play_rect() -> Rect2:
	return Rect2(110.0, 690.0, 500.0, 128.0)


func _help_rect() -> Rect2:
	return Rect2(170.0, 836.0, 380.0, 82.0)


func _memo_rect() -> Rect2:
	return Rect2(190.0, 960.0, 340.0, 320.0)


func _close_rect() -> Rect2:
	return Rect2(210.0, 980.0, 300.0, 90.0)


# ---------------- GİRDİ ----------------
func _input(event: InputEvent) -> void:
	if starting:
		return
	var mm := event as InputEventMouseMotion
	if mm != null:
		if scroll_drag and page != "main":
			var d := get_local_mouse_position().y - press_pos.y
			if absf(d) > 14.0:
				drag_moved = true
			if drag_moved:
				scroll = clampf(scroll_start - d, 0.0, _scroll_max())
		return
	var mb := event as InputEventMouseButton
	if mb == null or mb.button_index != MOUSE_BUTTON_LEFT:
		return
	var pos := get_local_mouse_position()
	if modal != "":
		_modal_input(mb.pressed, pos)
		return
	if page == "quests":
		_quests_input(mb.pressed, pos)
		return
	if page == "market":
		_market_input(mb.pressed, pos)
		return
	if page != "main" and not help_open:
		_page_input(mb.pressed, pos)
		return
	if mb.pressed:
		if help_open:
			press_id = "close" if _close_rect().has_point(pos) else ""
		elif _play_rect().has_point(pos):
			press_id = "play"
		elif _help_rect().has_point(pos):
			press_id = "help"
		elif _gear_rect().has_point(pos):
			press_id = "gear"
		elif _gift_rect().has_point(pos):
			press_id = "gift"
		elif _quest_rect().has_point(pos):
			press_id = "quest"
		elif _market_rect().has_point(pos):
			press_id = "market"
		elif _gem_btn_rect().has_point(pos):
			press_id = "gem"
		elif _memo_rect().has_point(pos):
			press_id = "memo"
		else:
			press_id = ""
		return
	# bırakma
	var id := press_id
	press_id = ""
	if id == "":
		return
	var ok := false
	match id:
		"play":
			ok = _play_rect().has_point(pos)
		"help":
			ok = _help_rect().has_point(pos)
		"close":
			ok = _close_rect().has_point(pos)
		"memo":
			ok = _memo_rect().has_point(pos)
		"gear":
			ok = _gear_rect().has_point(pos)
		"gift":
			ok = _gift_rect().has_point(pos)
		"quest":
			ok = _quest_rect().has_point(pos)
		"market":
			ok = _market_rect().has_point(pos)
		"gem":
			ok = _gem_btn_rect().has_point(pos)
	if not ok:
		return
	match id:
		"play":
			starting = true
			start_t = 0.0
			Sfx.play("scared", 1.0, -3.0)
			get_tree().create_timer(0.15).timeout.connect(func(): Sfx.play("throw"))
			memo_pose = Pose.GERGIN
			memo_pose_t = 99.0
			_say(Loc.t("stop"))
		"help":
			Sfx.play("click")
			help_open = true
			help_t = 0.0
		"close":
			Sfx.play("click")
			help_open = false
		"memo":
			_poke_memo()
		"gear":
			Sfx.play("click")
			_open_page("settings")
		"gift":
			Sfx.play("click")
			_open_modal("daily")
		"quest":
			Sfx.play("click")
			_open_page("quests")
		"market":
			Sfx.play("click")
			_open_page("market")
		"gem":
			_gem_watch()


func _say(txt: String) -> void:
	memo_talk = txt
	memo_talk_t = 1.2


func _poke_memo() -> void:
	memo_taps += 1
	Sfx.play("hit", randf_range(0.95, 1.08))
	get_tree().create_timer(0.1).timeout.connect(func(): Sfx.play("ouch", randf_range(0.95, 1.15)))
	memo_pose = Pose.SERSEM
	memo_pose_t = 1.0
	shake = 0.2
	_say(Loc.pick("poke"))
	fx.append({"pos": Vector2(360.0, 1040.0), "text": Loc.t("tak"), "t": 0.0})
	if memo_taps % 5 == 0:
		_say(Loc.t("enough"))


# ---------------- ZAMAN ----------------
func _process(delta: float) -> void:
	delta = minf(delta, 0.05)
	t += delta
	if help_open:
		help_t += delta
	if shake > 0.0:
		shake = maxf(shake - delta, 0.0)
		position = Scr.off + Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * shake * 40.0
	else:
		position = Scr.off
	if memo_talk_t > 0.0:
		memo_talk_t -= delta
	if toast_t > 0.0:
		toast_t -= delta
	if not starting:
		if memo_pose_t > 0.0:
			memo_pose_t -= delta
			if memo_pose_t <= 0.0:
				memo_pose = Pose.DIL
	else:
		start_t += delta
		if start_t >= 0.38 and start_t - delta < 0.38:      # terlik Memo'ya çarptı
			memo_pose = Pose.SERSEM
			shake = 0.3
			Sfx.play("hit")
			get_tree().create_timer(0.12).timeout.connect(func(): Sfx.play("ouch"))
			_say("AY!")
			fx.append({"pos": Vector2(360.0, 1040.0), "text": "TAK!", "t": 0.0})
		if start_t >= 1.2:
			set_process(false)
			get_tree().change_scene_to_file(GAME_SCENE)
	for f in fx:
		f["t"] = float(f["t"]) + delta
	fx = fx.filter(func(f): return float(f["t"]) < 0.9)
	if modal != "":
		modal_t += delta
	elif modal_pending != "" and t > open_after and page == "main" and not help_open and not starting:
		_open_modal(modal_pending)
		modal_pending = ""
	elif modal_pending == "" and Daily.wb_pending > 0 and not Daily.wb_shown and t > open_after and page == "main":
		modal_pending = "back"          # uygulama uzun süre arka plandayken dönüldü
	_update_rewards(delta)
	queue_redraw()


# ---------------- ÇİZİM ----------------
func _draw() -> void:
	var o := ad_off
	if page == "main":
		_draw_bg()
		_draw_falling()
		U.sunburst(self, Vector2(360.0, 330.0 + o), t * 0.15, 16, Color(1.0, 0.85, 0.3, 0.10))
		_draw_title(o)
		_draw_ribbon(o)
		_draw_memo()
		_draw_buttons()
		_draw_gear()
		_draw_top_icons()
		_draw_fx()
		if starting:
			_draw_start_anim()
	elif page == "quests":
		_draw_quests()
	elif page == "market":
		_draw_market()
	else:
		_draw_page()
	if help_open:
		_draw_help()
	if modal != "":
		_draw_modal()
	_draw_rewards_fx()
	if toast_t > 0.0:
		_draw_toast()
	if Ads.is_stub and ad_off > 0.0:
		draw_rect(Rect2(0, 0, W, ad_off), Color(0.15, 0.15, 0.18, 0.95))
		U.out_text(self, font, "TEST BANNER", Vector2(360.0, ad_off * 0.5 + 8.0), 22, Color(0.8, 0.8, 0.85))
	# açılış karartması
	if t < 0.4:
		draw_rect(Scr.full(), Color(0, 0, 0, 1.0 - t / 0.4))
	if starting and start_t > 0.8:
		draw_rect(Scr.full(), Color(0, 0, 0, clampf((start_t - 0.8) / 0.38, 0.0, 1.0)))


func _draw_bg() -> void:
	var z := 1.08 + sin(t * 0.35) * 0.02
	var off := Vector2(sin(t * 0.25) * 14.0, cos(t * 0.2) * 10.0)
	draw_set_transform(Scr.center() + off, 0.0, Vector2(z, z))
	if bg != null:
		var cs := Scr.cover_size(bg)
		draw_texture_rect(bg, Rect2(-cs * 0.5, cs), false)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	# üstte başlık için koyu geçiş, altta Memo için hafif karartma
	var top := Color(0.08, 0.02, 0.15, 0.62)
	var clear := Color(0.08, 0.02, 0.15, 0.0)
	var gx0 := -Scr.off.x
	var gx1 := W + Scr.off.x
	var gy0 := -Scr.off.y
	draw_polygon(PackedVector2Array([Vector2(gx0, gy0), Vector2(gx1, gy0), Vector2(gx1, 700), Vector2(gx0, 700)]), PackedColorArray([top, top, clear, clear]))
	draw_polygon(PackedVector2Array([Vector2(gx0, 900), Vector2(gx1, 900), Vector2(gx1, H), Vector2(gx0, H)]), PackedColorArray([clear, clear, Color(0.08, 0.02, 0.15, 0.4), Color(0.08, 0.02, 0.15, 0.4)]))


func _draw_falling() -> void:
	for s in sparks:
		var tw := maxf(0.5 + 0.5 * sin(t * 3.0 + float(s["ph"])), 0.2)
		var sz := float(s["s"]) * tw
		draw_colored_polygon(U.star_pts(Vector2(float(s["x"]), float(s["y"])), sz, sz * 0.25, 4, 0.0), Color(1.0, 0.95, 0.6, 0.5))
	for p in parts:
		var y := fposmod(float(p["y"]) + t * float(p["v"]), Scr.size.y + 260.0) - 130.0 - Scr.off.y
		var x := float(p["x"]) + sin(t * 0.9 + float(p["ph"])) * 30.0
		U.draw_slipper(self, tex_slip, Vector2(x, y), float(p["h"]), float(p["r"]) + t * float(p["rv"]), 0.8)


func _draw_title(o: float) -> void:
	_wave_text(Loc.t("t1"), 360.0, 270.0 + o, int(134 * Loc.k1()), Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15), 0.0)
	_wave_text(Loc.t("t2"), 360.0, 408.0 + o, 112, Color.WHITE, Color(0.25, 0.6, 0.95), 0.4)


# Harfleri tek tek hareket ettirir: giriş animasyonunda yukarıdan sekerek düşer, sonra dalgalanır.
func _wave_text(txt: String, cx: float, y: float, fsize: int, fill: Color, edge: Color, delay: float) -> void:
	var widths: Array = []
	var total := 0.0
	for i in txt.length():
		var cw := font.get_string_size(txt.substr(i, 1), HORIZONTAL_ALIGNMENT_LEFT, -1, fsize).x
		widths.append(cw)
		total += cw
	for layer in 3:
		var x := cx - total * 0.5
		for i in txt.length():
			var cw: float = widths[i]
			var u := (t - 0.15 - delay - i * 0.07) / 0.55
			if u > 0.0:
				var drop := (1.0 - U.out_bounce(u)) * -520.0
				var wave := 0.0
				var rot := 0.0
				if u >= 1.0:
					wave = sin(t * 3.2 + i * 0.8) * 7.0
					rot = sin(t * 2.4 + i * 1.1) * 0.06
				U.fat_text(self, font, txt.substr(i, 1), Vector2(x + cw * 0.5, y + drop + wave), fsize, fill, edge, rot, 1.0, clampf(u * 4.0, 0.0, 1.0), layer)
			x += cw


func _draw_ribbon(o: float) -> void:
	var u := clampf((t - 0.9) / 0.45, 0.0, 1.0)
	if u <= 0.0:
		return
	var cx := lerpf(-400.0, 360.0, U.out_back(u))
	var cy := 500.0 + o + sin(t * 2.0) * 3.0
	draw_set_transform(Vector2(cx, cy), -0.05 + sin(t * 1.6) * 0.012, Vector2.ONE)
	draw_rect(Rect2(-250, -44, 500, 88), Color(0.13, 0.04, 0.03))
	draw_rect(Rect2(-242, -36, 484, 72), Color(0.78, 0.12, 0.15))
	draw_rect(Rect2(-242, -36, 484, 30), Color(0.95, 0.3, 0.3, 0.55))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	U.out_text(self, font, Loc.t("t3"), Vector2(cx, cy + 20.0), 54, Color(1.0, 0.92, 0.5), -0.05 + sin(t * 1.6) * 0.012)


func _draw_memo() -> void:
	var key := "memo_dil"
	if memo_pose == Pose.GERGIN:
		key = "memo_gergin"
	elif memo_pose == Pose.SERSEM:
		key = "memo_sersem"
	var tex: Texture2D = tex_memo[key]
	if tex == null:
		return
	var sc := 0.64
	var w := float(tex.get_width()) * sc
	var h := float(tex.get_height()) * sc
	# giriş: aşağıdan çıkar. Boştayken ara sıra yukarı aşağı oynar (dil çıkarır)
	var rise := U.out_bounce((t - 1.2) / 0.6)
	var bob := 0.0
	var wob := 0.0
	if memo_pose == Pose.DIL:
		bob = maxf(0.0, sin(t * 2.2)) * 14.0
		wob = sin(t * 9.0) * 0.035 * maxf(0.0, sin(t * 2.2))
	elif memo_pose == Pose.SERSEM:
		wob = sin(t * 28.0) * 0.1
	else:
		wob = sin(t * 40.0) * 0.03
	draw_set_transform(Vector2(360.0, H + 6.0 + (1.0 - rise) * h - bob), wob, Vector2.ONE)
	draw_texture_rect(tex, Rect2(-w * 0.5, -h, w, h), false)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if memo_pose == Pose.SERSEM:
		for i in 3:
			var a := t * 6.0 + i * TAU / 3.0
			draw_colored_polygon(U.star_pts(Vector2(360.0 + cos(a) * 90.0, 1010.0 + sin(a) * 20.0), 17.0, 8.0, 5, t * 3.0), Color(1.0, 0.9, 0.2))
	if memo_talk_t > 0.0:
		var pop := U.out_back((1.2 - memo_talk_t) / 0.2)
		U.out_text(self, font, memo_talk, Vector2(540.0, 985.0), 40, Color(1.0, 0.9, 0.3), 0.15, pop)


func _draw_buttons() -> void:
	if help_open:
		return
	var pulse := 1.0 + sin(t * 4.5) * 0.035
	var pr := _play_rect()
	var ps := pulse
	if press_id == "play" or starting:
		ps = 0.94
	draw_set_transform(pr.get_center(), 0.0, Vector2(ps, ps))
	draw_style_box(st_play, Rect2(-pr.size * 0.5, pr.size))
	draw_style_box(st_play_hi, Rect2(-pr.size.x * 0.5 + 16.0, -pr.size.y * 0.5 + 12.0, pr.size.x - 32.0, pr.size.y * 0.36))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var sub: String = Loc.t("new_game") if best_level <= 1 else Loc.t("continue") % best_level
	U.out_text(self, font, Loc.t("play"), pr.get_center() + Vector2(0, 12.0) * ps, 66, Color.WHITE, 0.0, ps)
	U.out_text(self, font, sub, pr.get_center() + Vector2(0, 46.0) * ps, 22, Color(0.85, 1.0, 0.85), 0.0, ps)
	var hr := _help_rect()
	var hs := 0.95 if press_id == "help" else 1.0
	draw_set_transform(hr.get_center(), 0.0, Vector2(hs, hs))
	draw_style_box(st_help, Rect2(-hr.size * 0.5, hr.size))
	draw_style_box(st_help_hi, Rect2(-hr.size.x * 0.5 + 14.0, -hr.size.y * 0.5 + 10.0, hr.size.x - 28.0, hr.size.y * 0.34))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	U.out_text(self, font, Loc.t("how_to"), hr.get_center() + Vector2(0, 11.0), 30, Color.WHITE, 0.0, hs)


func _draw_fx() -> void:
	for f in fx:
		var u := float(f["t"]) / 0.9
		var p: Vector2 = f["pos"]
		for i in 8:
			var a := i * TAU / 8.0
			var d := U.out_cubic(u * 1.4) * 150.0
			draw_colored_polygon(U.star_pts(p + Vector2(cos(a), sin(a)) * d, maxf(3.0, 22.0 * (1.0 - u)), 7.0, 5, u * 6.0 + i), Color(1.0, 0.85, 0.2, 1.0 - u))
		U.out_text(self, font, String(f["text"]), p + Vector2(0, -110.0 - u * 50.0), 54, Color(1.0, 0.9, 0.3, 1.0 - u * u), 0.0, 0.6 + U.out_back(u * 3.0) * 0.5)


# OYNA'ya basınca: terlik sol alttan Memo'ya uçar.
func _draw_start_anim() -> void:
	if start_t < 0.38:
		var u := start_t / 0.38
		var p := Vector2(-60.0, 1250.0).lerp(Vector2(360.0, 1030.0), u)
		p.y -= sin(u * PI) * 320.0
		for k in range(4, 0, -1):
			var uu := maxf(u - k * 0.05, 0.0)
			var pp := Vector2(-60.0, 1250.0).lerp(Vector2(360.0, 1030.0), uu)
			pp.y -= sin(uu * PI) * 320.0
			U.draw_slipper(self, tex_slip, pp, 190.0 - uu * 40.0, uu * 18.0, 0.5 - k * 0.1)
		U.draw_slipper(self, tex_slip, p, 190.0 - u * 40.0, u * 18.0)
	else:
		var t2 := start_t - 0.38
		if t2 < 0.15:
			draw_rect(Scr.full(), Color(1, 1, 1, 0.6 * (1.0 - t2 / 0.15)))
		if t2 < 0.5:
			var u := t2 / 0.5
			draw_arc(Vector2(360.0, 1030.0), U.out_cubic(u) * 300.0, 0.0, TAU, 56, Color(1.0, 0.9, 0.3, 1.0 - u), maxf(2.0, 18.0 * (1.0 - u)))


func _draw_help() -> void:
	var u := U.out_back(help_t / 0.25)
	draw_rect(Scr.full(), Color(0, 0, 0, 0.6 * clampf(help_t / 0.2, 0.0, 1.0)))
	var pr := Rect2(50.0, 200.0, 620.0, 900.0)
	draw_set_transform(pr.get_center(), 0.0, Vector2(u, u))
	draw_style_box(st_panel, Rect2(-pr.size * 0.5, pr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if help_t < 0.2:
		return
	U.fat_text(self, font, Loc.t("how_to"), Vector2(360.0, 300.0), 46, Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15))
	var lines := [Loc.t("h1"), Loc.t("h2"), Loc.t("h3"), Loc.t("h4"), Loc.t("h5")]
	# Uzun dillerde taşmasın: yazı boyutunu toplam yükseklik sığana kadar küçült.
	var fs := 25
	var gap := 22.0
	while fs > 18:
		var tot := 0.0
		for l in lines:
			tot += font.get_multiline_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, 540.0, fs).y + gap
		if tot <= 640.0:
			break
		fs -= 1
	var y := 370.0
	for l in lines:
		draw_multiline_string(font, Vector2(90.0, y), l, HORIZONTAL_ALIGNMENT_LEFT, 540.0, fs, -1, Color(0.25, 0.12, 0.06))
		y += font.get_multiline_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, 540.0, fs).y + gap
	var cr := _close_rect()
	var cs := 0.95 if press_id == "close" else 1.0
	draw_set_transform(cr.get_center(), 0.0, Vector2(cs, cs))
	draw_style_box(st_play, Rect2(-cr.size * 0.5, cr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	U.out_text(self, font, Loc.t("ok"), cr.get_center() + Vector2(0, 14.0), 42, Color.WHITE, 0.0, cs)


# ---------------- AYARLAR / UYGULAMALARIMIZ SAYFALARI ----------------
func _gear_rect() -> Rect2:
	return Rect2(606.0, 28.0 + ad_off, 82.0, 82.0)


func _panel_top() -> float:
	return 190.0 + ad_off


func _scroll_max() -> float:
	return maxf(0.0, cur_h + 24.0 - (H - _panel_top() - 30.0))


func _back_center() -> Vector2:
	return Vector2(80.0, 100.0 + ad_off)


func _open_page(p: String) -> void:
	_flush_rewards()
	page = p
	scroll = 0.0
	scroll_drag = false
	if p == "settings":
		cur_items = set_items
		cur_h = set_h
	elif p == "games":
		cur_items = game_items
		cur_h = game_h
	elif p == "market":
		cur_h = float(Shop.SKINS.size()) * 306.0 + 104.0


func _toast(txt: String) -> void:
	toast_txt = txt
	toast_t = 2.0


var build_y := 0.0
var reset_arm_ms := -10000


func _add_set(kind: String, id: String, txt: String, h: float, gap: float) -> void:
	set_items.append({"k": kind, "id": id, "t": txt, "y": build_y, "h": h})
	build_y += h + gap


func _build_settings() -> void:
	set_items.clear()
	build_y = 0.0
	_add_set("btn", "games", Loc.t("games_btn"), 124.0, 14.0)
	_add_set("hdr", "", Loc.t("sec_sound"), 56.0, 0.0)
	_add_set("chk", "music", Loc.t("music"), 96.0, 14.0)
	_add_set("chk", "sfx", Loc.t("sfx"), 96.0, 14.0)
	_add_set("hdr", "", Loc.t("sec_device"), 56.0, 0.0)
	_add_set("chk", "vib", Loc.t("vib"), 96.0, 14.0)
	_add_set("chk", "fx", Loc.t("fxs"), 96.0, 14.0)
	_add_set("chk", "notif", Loc.t("notif_set"), 96.0, 14.0)
	_add_set("hdr", "", Loc.t("sec_progress"), 56.0, 0.0)
	_add_set("btn", "backup", Loc.t("backup_btn"), 96.0, 14.0)
	_add_set("btn", "reset", Loc.t("reset"), 96.0, 14.0)
	_add_set("hdr", "", Loc.t("sec_lang"), 56.0, 0.0)
	_add_set("btn", "lang", Loc.lang_name(), 96.0, 14.0)
	_add_set("hdr", "", Loc.t("sec_help"), 56.0, 0.0)
	_add_set("btn", "help", Loc.t("how_to_s"), 96.0, 14.0)
	if U.gdpr_region():                # reklam rızası yalnızca AB/AEA/UK/İsviçre'de görünür
		_add_set("hdr", "", Loc.t("sec_privacy"), 56.0, 0.0)
		_add_set("btn", "consent", Loc.t("consent"), 96.0, 14.0)
	_add_set("hdr", "", Loc.t("sec_about"), 56.0, 0.0)
	_add_set("btn", "terms", Loc.t("terms"), 96.0, 14.0)
	_add_set("btn", "privacy", Loc.t("privacy"), 96.0, 14.0)
	_add_set("foot", "", Loc.t("title_full") + "  •  " + VERSION, 70.0, 0.0)
	set_h = build_y


func _build_games() -> void:
	game_items.clear()
	var cy := 0.0
	game_items.append({"k": "note", "id": "", "t": Loc.t("apps_note"), "y": cy, "h": 70.0})
	cy += 80.0
	for i in GAMES.size():
		game_items.append({"k": "card", "id": "game%d" % i, "t": "", "y": cy, "h": 236.0, "g": i})
		cy += 236.0 + 20.0
	game_h = cy


func _item_rect(it: Dictionary) -> Rect2:
	return Rect2(40.0, _panel_top() + 24.0 + float(it["y"]) - scroll, 640.0, float(it["h"]))


func _page_input(pressed: bool, pos: Vector2) -> void:
	if cons_open:                      # reklam rızası penceresi
		if not pressed:
			_cons_tap(pos)
		return
	if backup_open:                    # yedekleme penceresi: OK ya da dışarı dokununca kapanır
		if not pressed and (_bk_close().has_point(pos) or not _bk_panel().has_point(pos)):
			Sfx.play("click")
			backup_open = false
		return
	if lang_open:                      # dil listesi açıkken sayfa kaymaz, sadece listeye dokunulur
		if not pressed:
			_lang_tap(pos)
		return
	if pressed:
		scroll_drag = true
		drag_moved = false
		press_pos = pos
		scroll_start = scroll
		return
	if not scroll_drag:
		return
	scroll_drag = false
	if drag_moved:
		return
	if pos.distance_to(_back_center()) < 54.0:
		Sfx.play("click")
		_open_page("settings" if page == "games" else "main")
		return
	if pos.y < _panel_top():
		return
	for it in cur_items:
		var k: String = it["k"]
		if k != "btn" and k != "chk" and k != "card":
			continue
		if _item_rect(it).has_point(pos):
			_on_item(String(it["id"]))
			return


func _on_item(id: String) -> void:
	Sfx.play("click")
	match id:
		"games":
			_open_page("games")
		"music", "sfx", "vib", "fx", "notif":
			opts[id] = not bool(opts[id])
			U.set_setting(id, bool(opts[id]))
			Sfx.apply_settings()
			if id == "vib" and bool(opts[id]):
				Input.vibrate_handheld(50)
			if id == "notif" and bool(opts[id]) and not Notify.has_permission():
				Notify.ask_permission()
		"reset":
			if Time.get_ticks_msec() - reset_arm_ms < 3000:
				var cf := ConfigFile.new()
				cf.set_value("p", "level", 1)
				cf.save(SAVE_PATH)
				best_level = 1
				reset_arm_ms = -10000
				_toast(Loc.t("reset_done"))
			else:
				reset_arm_ms = Time.get_ticks_msec()
				_toast(Loc.t("reset_ask"))
		"lang":
			lang_open = true
		"backup":
			backup_open = true
		"help":
			help_open = true
			help_t = 0.0
		"consent":
			cons_open = true
		"terms":
			_open_url(U.TERMS_URL)
		"privacy":
			_open_url(U.PRIVACY_URL)
		_:
			if id.begins_with("game"):
				var g: Dictionary = GAMES[int(id.substr(4))]
				_open_store(String(g["pkg"]))


# ---------------- REKLAM RIZASI PENCERESİ (AB/AEA/UK) ----------------
func _cons_panel() -> Rect2:
	return Rect2(60.0, 420.0, 600.0, 440.0)


func _cons_main() -> Rect2:
	return Rect2(110.0, 650.0, 500.0, 90.0)


func _cons_close() -> Rect2:
	return Rect2(110.0, 750.0, 500.0, 80.0)


func _cons_tap(pos: Vector2) -> void:
	if _cons_main().has_point(pos):
		Sfx.play("click")
		Ads.set_gdpr_consent(not U.get_setting("gdpr_consent", false))
		cons_open = false
	elif _cons_close().has_point(pos) or not _cons_panel().has_point(pos):
		Sfx.play("click")
		cons_open = false


func _draw_cons() -> void:
	draw_rect(Scr.full(), Color(0, 0, 0, 0.6))
	var pr := _cons_panel()
	draw_style_box(st_panel, pr)
	var on := U.get_setting("gdpr_consent", false)
	U.fat_text(self, font, Loc.t("consent"), Vector2(360.0, pr.position.y + 80.0), 38, Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15))
	var body := Loc.t("adc_on") if on else Loc.t("adc_off")
	var fs := 28
	while fs > 16 and font.get_multiline_string_size(body, HORIZONTAL_ALIGNMENT_CENTER, 500.0, fs).y > 150.0:
		fs -= 1
	draw_multiline_string(font, Vector2(110.0, pr.position.y + 135.0), body, HORIZONTAL_ALIGNMENT_CENTER, 500.0, fs, -1, Color(0.25, 0.12, 0.06))
	var mr := _cons_main()
	draw_style_box(st_play, mr)
	U.out_text(self, font, Loc.t("adc_withdraw") if on else Loc.t("adc_allow"), mr.get_center() + Vector2(0, 13.0), 34, Color.WHITE)
	var cr := _cons_close()
	draw_style_box(st_help, cr)
	U.out_text(self, font, Loc.t("adc_close"), cr.get_center() + Vector2(0, 12.0), 30, Color.WHITE)


# ---------------- YEDEKLEME PENCERESİ ----------------
func _bk_panel() -> Rect2:
	return Rect2(50.0, 240.0, 620.0, 800.0)


func _bk_close() -> Rect2:
	return Rect2(210.0, 920.0, 300.0, 90.0)


func _draw_backup() -> void:
	draw_rect(Scr.full(), Color(0, 0, 0, 0.6))
	var pr := _bk_panel()
	draw_style_box(st_panel, pr)
	U.fat_text(self, font, Loc.t("bk_title"), Vector2(360.0, pr.position.y + 90.0), 46, Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15))
	var lines := [Loc.t("bk1"), Loc.t("bk2"), Loc.t("bk3"), Loc.t("bk4")]
	var fs := 25
	var gap := 22.0
	while fs > 17:
		var tot := 0.0
		for l in lines:
			tot += font.get_multiline_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, 540.0, fs).y + gap
		if tot <= 500.0:
			break
		fs -= 1
	var y := pr.position.y + 150.0
	for l in lines:
		draw_multiline_string(font, Vector2(90.0, y), l, HORIZONTAL_ALIGNMENT_LEFT, 540.0, fs, -1, Color(0.25, 0.12, 0.06))
		y += font.get_multiline_string_size(l, HORIZONTAL_ALIGNMENT_LEFT, 540.0, fs).y + gap
	var cr := _bk_close()
	draw_style_box(st_play, cr)
	U.out_text(self, font, Loc.t("ok"), cr.get_center() + Vector2(0, 14.0), 42, Color.WHITE)


# ---------------- DİL LİSTESİ ----------------
func _lang_panel() -> Rect2:
	return Rect2(80.0, 330.0, 560.0, 100.0 + Loc.LANGS.size() * 100.0)


func _lang_row(i: int) -> Rect2:
	return Rect2(110.0, 330.0 + 90.0 + i * 100.0, 500.0, 88.0)


func _lang_tap(pos: Vector2) -> void:
	for i in Loc.LANGS.size():
		if _lang_row(i).has_point(pos):
			Sfx.play("click")
			if i != Loc.idx:
				Loc.set_lang(i)
				_build_settings()
				_build_games()
				if page == "settings":
					cur_h = set_h
				elif page == "games":
					cur_h = game_h
				scroll = clampf(scroll, 0.0, _scroll_max())
			lang_open = false
			return
	if not _lang_panel().has_point(pos):
		Sfx.play("click")
		lang_open = false


func _draw_lang() -> void:
	draw_rect(Scr.full(), Color(0, 0, 0, 0.6))
	var pr := _lang_panel()
	draw_style_box(st_panel, pr)
	draw_string(font, Vector2(pr.position.x, pr.position.y + 62.0), Loc.t("sec_lang"), HORIZONTAL_ALIGNMENT_CENTER, pr.size.x, 32, Color(0.35, 0.13, 0.05))
	for i in Loc.LANGS.size():
		var r := _lang_row(i)
		var sel := i == Loc.idx
		draw_style_box(st_play if sel else st_help, r)
		draw_style_box(st_play_hi if sel else st_help_hi, Rect2(r.position.x + 16.0, r.position.y + 8.0, r.size.x - 32.0, r.size.y * 0.30))
		U.out_text(self, font, Loc.NAMES[i], r.get_center() + Vector2(0.0, 12.0), 34, Color.WHITE)
		if sel:
			var c := Vector2(r.position.x + 52.0, r.get_center().y)
			draw_polyline(PackedVector2Array([c + Vector2(-14, 0), c + Vector2(-3, 12), c + Vector2(16, -12)]), Color.WHITE, 8.0)


func _open_url(url: String) -> void:
	if url.begins_with("BURAYA"):
		_toast(Loc.t("toast_nolink"))
		return
	OS.shell_open(url)


func _open_store(pkg: String) -> void:
	if pkg.begins_with("BURAYA"):
		_toast(Loc.t("toast_nopkg"))
		return
	var base := "market://details?id=" if OS.get_name() == "Android" else "https://play.google.com/store/apps/details?id="
	OS.shell_open(base + pkg)


func _draw_gear() -> void:
	if help_open:
		return
	var c := _gear_rect().get_center()
	draw_circle(c, 44.0 * IK, Color(0.20, 0.08, 0.05, 0.88))
	draw_arc(c, 44.0 * IK, 0.0, TAU, 40, Color(0.93, 0.45, 0.25), 5.0)
	draw_colored_polygon(U.star_pts(c, 31.0 * IK, 23.0 * IK, 8, t * 0.5), Color(1.0, 0.9, 0.6))
	draw_circle(c, 22.0 * IK, Color(1.0, 0.9, 0.6))
	draw_circle(c, 11.0 * IK, Color(0.20, 0.08, 0.05))


func _draw_page() -> void:
	var pt := _panel_top()
	draw_rect(Scr.full(), Color(0.17, 0.07, 0.27))
	for s in sparks:
		var tw := maxf(0.5 + 0.5 * sin(t * 3.0 + float(s["ph"])), 0.2)
		var sz := float(s["s"]) * tw
		draw_colored_polygon(U.star_pts(Vector2(float(s["x"]), float(s["y"])), sz, sz * 0.25, 4, 0.0), Color(1.0, 0.95, 0.6, 0.25))
	draw_style_box(st_sheet, Rect2(0.0, pt, W, H - pt + 60.0))
	for it in cur_items:
		var r := _item_rect(it)
		if r.end.y < pt or r.position.y > H:
			continue
		match String(it["k"]):
			"hdr":
				draw_string(font, Vector2(r.position.x, r.position.y + 38.0), String(it["t"]), HORIZONTAL_ALIGNMENT_CENTER, 640.0, 26, Color(0.55, 0.33, 0.15))
			"note":
				draw_multiline_string(font, Vector2(r.position.x + 6.0, r.position.y + 30.0), String(it["t"]), HORIZONTAL_ALIGNMENT_LEFT, 628.0, 24, 3, Color(0.2, 0.5, 0.2))
			"foot":
				draw_string(font, Vector2(r.position.x, r.position.y + 40.0), String(it["t"]), HORIZONTAL_ALIGNMENT_CENTER, 640.0, 24, Color(0.45, 0.28, 0.14))
			"btn", "chk":
				_draw_item_button(it, r)
			"card":
				_draw_card(int(it["g"]), r)
	# başlık şeridi (içeriği üstten örter)
	draw_rect(Rect2(-Scr.off.x, -Scr.off.y, Scr.size.x, pt + Scr.off.y), Color(0.17, 0.07, 0.27))
	var o := ad_off
	draw_rect(Rect2(160, 100.0 + o - 44.0, 400, 88), Color(0.13, 0.04, 0.03))
	draw_rect(Rect2(167, 100.0 + o - 37.0, 386, 74), Color(0.78, 0.12, 0.15))
	draw_rect(Rect2(167, 100.0 + o - 37.0, 386, 30), Color(0.95, 0.3, 0.3, 0.55))
	U.out_text(self, font, Loc.t("settings") if page == "settings" else Loc.t("our_apps"), Vector2(360.0, 114.0 + o), 40, Color(1.0, 0.92, 0.5))
	var bc := _back_center()
	draw_circle(bc, 42.0, Color(0.12, 0.04, 0.2))
	draw_arc(bc, 42.0, 0.0, TAU, 40, Color(0.93, 0.45, 0.25), 5.0)
	draw_polyline(PackedVector2Array([bc + Vector2(14, 0), bc + Vector2(-14, 0)]), Color.WHITE, 6.0)
	draw_polyline(PackedVector2Array([bc + Vector2(-2, -14), bc + Vector2(-16, 0), bc + Vector2(-2, 14)]), Color.WHITE, 6.0)
	var sm := _scroll_max()
	if sm > 0.0:
		var track := H - pt - 40.0
		var bar := maxf(60.0, track * track / (track + sm))
		draw_rect(Rect2(W - 12.0, pt + 20.0 + (track - bar) * scroll / sm, 6.0, bar), Color(0.55, 0.33, 0.15, 0.6))
	if lang_open:
		_draw_lang()
	if backup_open:
		_draw_backup()
	if cons_open:
		_draw_cons()


func _draw_item_button(it: Dictionary, r: Rect2) -> void:
	var st: StyleBoxFlat = st_help
	var hi: StyleBoxFlat = st_help_hi
	if String(it["id"]) == "games":
		st = st_play
		hi = st_play_hi
	draw_style_box(st, r)
	draw_style_box(hi, Rect2(r.position.x + 16.0, r.position.y + 10.0, r.size.x - 32.0, r.size.y * 0.32))
	var fs := 34
	if String(it["id"]) == "games":
		fs = 30
	U.out_text(self, font, String(it["t"]), r.get_center() + Vector2(0.0, fs * 0.36), fs, Color.WHITE)
	if String(it["id"]) == "lang":       # açılır liste oku
		var ac := Vector2(r.end.x - 50.0, r.get_center().y)
		draw_colored_polygon(PackedVector2Array([ac + Vector2(-14, -8), ac + Vector2(14, -8), ac + Vector2(0, 10)]), Color.WHITE)
	if String(it["k"]) == "chk":
		var bx := Rect2(r.position.x + 24.0, r.position.y + (r.size.y - 54.0) * 0.5, 54.0, 54.0)
		draw_style_box(st_box, bx)
		if bool(opts[String(it["id"])]):
			var c := bx.position
			draw_polyline(PackedVector2Array([c + Vector2(12, 28), c + Vector2(23, 40), c + Vector2(43, 15)]), Color(0.15, 0.7, 0.25), 8.0)


func _draw_card(i: int, r: Rect2) -> void:
	var g: Dictionary = GAMES[i]
	draw_style_box(st_card, r)
	var ic := Rect2(r.position.x + 22.0, r.position.y + (r.size.y - 110.0) * 0.5, 110.0, 110.0)
	var col: Color = g["col"]
	draw_rect(Rect2(ic.position.x - 3.0, ic.position.y - 3.0, 116.0, 116.0), Color(0.35, 0.13, 0.05))
	if game_icons.has(i):
		draw_texture_rect(game_icons[i], ic, false)
	else:
		draw_rect(ic, col)
		draw_rect(Rect2(ic.position.x, ic.position.y, 110.0, 40.0), Color(1, 1, 1, 0.18))
		U.out_text(self, font, String(g["name"]).substr(0, 1), ic.get_center() + Vector2(0.0, 26.0), 74, Color.WHITE)
	draw_multiline_string(font, Vector2(r.position.x + 152.0, r.position.y + 54.0), String(g["name"]), HORIZONTAL_ALIGNMENT_LEFT, 300.0, 28, 2, Color(0.30, 0.14, 0.06))
	draw_multiline_string(font, Vector2(r.position.x + 152.0, r.position.y + 128.0), Loc.t("gdesc%d" % i), HORIZONTAL_ALIGNMENT_LEFT, 290.0, 21, 3, Color(0.45, 0.28, 0.14))
	var br := Rect2(r.end.x - 150.0, r.position.y + (r.size.y - 66.0) * 0.5, 130.0, 66.0)
	draw_style_box(st_play, br)
	U.out_text(self, font, Loc.t("download"), br.get_center() + Vector2(0.0, 10.0), 26, Color.WHITE)


func _draw_toast() -> void:
	var a := clampf(toast_t / 0.4, 0.0, 1.0)
	var r := Rect2(90.0, 1130.0, 540.0, 76.0)
	draw_style_box(st_toast, r)
	draw_string(font, Vector2(r.position.x, r.position.y + 47.0), toast_txt, HORIZONTAL_ALIGNMENT_CENTER, 540.0, 24, Color(1, 1, 1, a))


# =====================================================================================
#  GÜNLÜK ÖDÜL / GÖREVLER / CÜZDAN  (Daily + Notify autoload'larıyla çalışır)
# =====================================================================================

# ---------------- DÜZEN ----------------
const IK := 0.86                 # üst satır ikonlarının ölçeği (3 ikon + coin + elmas + dişli aynı satıra sığsın)


func _gift_rect() -> Rect2:
	return Rect2(12.0, 28.0 + ad_off, 82.0, 82.0)


func _quest_rect() -> Rect2:
	return Rect2(100.0, 28.0 + ad_off, 82.0, 82.0)


# Cüzdan kutuları: ana menüde üstte (coin + altında küçük güç-up çubuğu), Görevler sayfasında sayfanın tepesinde.
func _wallet_rect(key: String) -> Rect2:
	if page == "quests":
		var y := _panel_top() + 18.0
		if key == "coin":
			return Rect2(40.0, y, 268.0, 64.0)
		if key == "gem":
			return Rect2(-600.0, y, 10.0, 10.0)
		if key == "aim":
			return Rect2(322.0, y, 112.0, 64.0)
		if key == "slow":
			return Rect2(442.0, y, 112.0, 64.0)
		return Rect2(562.0, y, 112.0, 64.0)
	if page == "market":
		var my := _panel_top() + 18.0
		if key == "coin":
			return Rect2(40.0, my, 300.0, 64.0)
		if key == "gem":
			return Rect2(356.0, my, 300.0, 64.0)
		return Rect2(-600.0, my, 10.0, 10.0)
	var o := ad_off
	if key == "gem":
		return Rect2(434.0, 41.0 + o, 150.0, 60.0)
	if key == "coin":
		return Rect2(278.0, 41.0 + o, 150.0, 60.0)
	if key == "aim":                      # güç-up tepsisindeki 3 yuva (merkez x = 431)
		return Rect2(431.0 - 58.0 - 22.0, 115.0 + o, 44.0, 44.0)
	if key == "slow":
		return Rect2(431.0 - 22.0, 115.0 + o, 44.0, 44.0)
	return Rect2(431.0 + 58.0 - 22.0, 115.0 + o, 44.0, 44.0)


func _sync_wallet() -> void:
	disp_coins = float(Daily.get_coins())
	land_coins = int(disp_coins)
	disp_gems = float(Shop.gems)
	land_gems = Shop.gems
	for id in Daily.PU_IDS:
		disp_pu[id] = Daily.inv_count(id)


func _wallet_pu_visible() -> bool:
	if wallet_show:
		return true
	for id in Daily.PU_IDS:
		if int(disp_pu[id]) > 0:
			return true
	return false


func _fit(txt: String, fs: int, maxw: float, min_fs: int = 14) -> int:
	while fs > min_fs and font.get_string_size(txt, HORIZONTAL_ALIGNMENT_LEFT, -1, fs).x > maxw:
		fs -= 1
	return fs


# ---------------- PENCERE AÇ / KAPA ----------------
func _open_modal(kind: String) -> void:
	modal = kind
	modal_t = 0.0
	press_id = ""
	daily_wb = false
	if kind == "back":
		kind = "daily"
		modal = "daily"
		daily_wb = true
		Daily.wb_shown = true
		daily_view = 0
		daily_rw = Daily.winback_reward()
	elif kind == "daily":
		Daily.auto_shown = true
		if Daily.can_claim():
			daily_view = 0
			daily_rw = Daily.reward_today()
		else:
			daily_view = 2
			daily_rw = {}


func _close_modal() -> void:
	var was := modal
	modal = ""
	modal_t = 0.0
	press_id = ""
	if was == "notif" and Daily.wb_pending > 0 and not Daily.wb_shown:
		modal_pending = "back"
		open_after = t + 0.35
	elif (was == "notif" or (was == "daily" and daily_wb)) and Daily.can_claim() and not Daily.auto_shown:
		modal_pending = "daily"
		open_after = t + 0.35


func _dm_panel() -> Rect2:
	return Rect2(60.0, 300.0, 600.0, 650.0)


func _dm_btn() -> Rect2:
	return Rect2(130.0, 812.0, 460.0, 104.0)


func _dm_x() -> Rect2:
	var pr := _dm_panel()
	return Rect2(pr.end.x - 84.0, pr.position.y + 12.0, 70.0, 70.0)


func _nm_panel() -> Rect2:
	return Rect2(60.0, 350.0, 600.0, 580.0)


func _nm_allow() -> Rect2:
	return Rect2(110.0, 700.0, 500.0, 92.0)


func _nm_later() -> Rect2:
	return Rect2(160.0, 812.0, 400.0, 76.0)


func _modal_input(pressed: bool, pos: Vector2) -> void:
	if modal == "gem":
		if not pressed and gem_t > 0.7 and not gem_spawned:
			_gem_spawn()                        # dokununca hemen cüzdana uçsun
		return
	if modal_t < 0.3:
		return                                  # açılış animasyonunda yanlışlıkla dokunma sayılmasın
	if modal == "buy" or modal == "own":
		_modal_input2(pressed, pos)
		return
	if pressed:
		press_id = ""
		if modal == "daily" and daily_view != 1 and _dm_btn().has_point(pos):
			press_id = "dm_btn"
		elif modal == "notif" and _nm_allow().has_point(pos):
			press_id = "nm_allow"
		elif modal == "notif" and _nm_later().has_point(pos):
			press_id = "nm_later"
		return
	var pid := press_id
	press_id = ""
	if modal == "notif":
		if pid == "nm_allow" and _nm_allow().has_point(pos):
			Sfx.play("click")
			Notify.ask_permission()
			_close_modal()
		elif (pid == "nm_later" and _nm_later().has_point(pos)) or not _nm_panel().has_point(pos):
			Sfx.play("click")
			U.set_setting("notif_asked", true)
			Track.event("notif_prompt", {"item_name": "later"})
			_close_modal()
		return
	if modal == "daily":
		if daily_view == 1:
			return
		if pid == "dm_btn" and _dm_btn().has_point(pos):
			if daily_view == 0:
				_daily_claim()
			else:
				Sfx.play("click")
				_close_modal()
		elif _dm_x().has_point(pos) or not _dm_panel().has_point(pos):
			Sfx.play("click")
			_close_modal()


# Bugünün ödül kutuları (coin + güç-up'lar) ve panel içindeki yerleri
func _daily_items(r: Dictionary) -> Array:
	var list: Array = []
	if int(r.get("coin", 0)) > 0:
		list.append({"k": "coin", "amt": int(r["coin"])})
	for id in Daily.PU_IDS:
		if int(r.get(id, 0)) > 0:
			list.append({"k": id, "amt": int(r[id])})
	var n := list.size()
	var pr := _dm_panel()
	var cell := minf(190.0, (pr.size.x - 60.0) / float(maxi(n, 1)))
	for i in n:
		list[i]["c"] = Vector2(pr.get_center().x + (float(i) - float(n - 1) * 0.5) * cell, pr.position.y + 272.0)
		list[i]["cell"] = cell
	return list


func _daily_claim() -> void:
	var r := Daily.claim_winback() if daily_wb else Daily.claim()
	if r.is_empty():
		return
	daily_rw = r
	daily_view = 1
	daily_t = 0.0
	press_id = ""
	Sfx.play("win", 1.15, -3.0)
	if U.get_setting("vib", true):
		Input.vibrate_handheld(40)
	shake = 0.12
	var pr := _dm_panel()
	_burst(pr.get_center() + Vector2(0.0, -10.0), 34, true)
	var origins := {}
	for it in _daily_items(r):
		origins[String(it["k"])] = it["c"]
	_spawn_rewards(r, origins, 0.32)


# ---------------- UÇAN ÖDÜLLER ----------------
# r: {"coin","aim","slow","double"}  origins: tür -> çıkış noktası (yoksa "coin" noktası kullanılır)
func _spawn_rewards(r: Dictionary, origins: Dictionary, delay: float) -> void:
	wallet_show = true
	var coin := int(r.get("coin", 0))
	if coin > 0:
		var from: Vector2 = origins.get("coin", Vector2(360.0, 640.0))
		var tgt := _wallet_rect("coin").get_center()
		var cn := clampi(coin / 6, 4, 12)
		var share := coin / cn
		for k in cn:
			var amt := share + (coin - share * cn if k == cn - 1 else 0)
			var ang := randf() * TAU
			var mid := from.lerp(tgt, 0.4) + Vector2(cos(ang), sin(ang)) * randf_range(70.0, 190.0)
			rflyers.append({"k": "coin", "amt": amt, "first": k == 0, "tot": coin,
				"p0": from + Vector2(randf_range(-26.0, 26.0), randf_range(-18.0, 18.0)), "c": mid, "p1": tgt,
				"t0": t + delay + float(k) * 0.07, "dur": randf_range(0.62, 0.86), "sz": 22.0})
	var gm := int(r.get("gem", 0))
	if gm > 0:
		var gfrom: Vector2 = origins.get("gem", Vector2(360.0, 640.0))
		var gtgt := _wallet_rect("gem").get_center()
		for k in gm:
			var gang := randf() * TAU
			rflyers.append({"k": "gem", "amt": 1, "first": k == 0, "tot": gm,
				"p0": gfrom + Vector2(randf_range(-30.0, 30.0), randf_range(-20.0, 20.0)),
				"c": gfrom.lerp(gtgt, 0.4) + Vector2(cos(gang), sin(gang)) * randf_range(70.0, 190.0), "p1": gtgt,
				"t0": t + delay + float(k) * 0.09, "dur": randf_range(0.65, 0.85), "sz": 26.0})
	for id in Daily.PU_IDS:
		var cnt := int(r.get(id, 0))
		for k in cnt:
			var from2: Vector2 = origins.get(id, origins.get("coin", Vector2(360.0, 640.0)))
			var tp := _wallet_rect(id).get_center()
			rflyers.append({"k": id, "amt": 1, "first": true, "tot": 1,
				"p0": from2 + Vector2((float(k) - float(cnt - 1) * 0.5) * 50.0, 0.0),
				"c": from2.lerp(tp, 0.4) + Vector2(randf_range(-130.0, 130.0), -150.0), "p1": tp,
				"t0": t + delay + 0.22 + float(k) * 0.14, "dur": 0.9, "sz": 36.0})


func _land(f: Dictionary) -> void:
	var k := String(f["k"])
	chip_pop[k] = 1.0
	land_count += 1
	Sfx.play("click", minf(1.0 + 0.06 * float(land_count % 8), 1.5), -4.0)
	var rc := _wallet_rect(k).get_center()
	_burst(rc, 4, false)
	if k == "gem":
		land_gems += int(f["amt"])
		if bool(f.get("first", false)):
			rfloats.append({"pos": rc + Vector2(0.0, 54.0), "txt": "+%d" % int(f["tot"]), "t": 0.0, "col": Color(0.65, 0.88, 1.0)})
	elif k == "coin":
		land_coins += int(f["amt"])
		if bool(f.get("first", false)):
			rfloats.append({"pos": rc + Vector2(0.0, 54.0), "txt": "+%d" % int(f["tot"]), "t": 0.0, "col": Color(1.0, 0.9, 0.35)})
	else:
		disp_pu[k] = int(disp_pu[k]) + 1
		rfloats.append({"pos": rc + Vector2(0.0, 40.0), "txt": "+1", "t": 0.0, "col": Color(0.55, 1.0, 0.7)})


# Sayfa değişirken havadaki ödülleri anında cüzdana işler
func _flush_rewards() -> void:
	for f in rflyers:
		if String(f["k"]) == "gem":
			land_gems += int(f["amt"])
		elif String(f["k"]) == "coin":
			land_coins += int(f["amt"])
		else:
			disp_pu[String(f["k"])] = int(disp_pu[String(f["k"])]) + 1
	rflyers.clear()
	rfloats.clear()
	wallet_show = false
	_sync_wallet()


func _burst(c: Vector2, n: int, big: bool) -> void:
	var cols := [Color(1.0, 0.85, 0.3), Color(1.0, 0.45, 0.4), Color(0.45, 0.85, 1.0), Color(0.55, 1.0, 0.5), Color(1, 1, 1)]
	for i in n:
		var a := randf() * TAU
		var sp := randf_range(180.0, 540.0 if big else 280.0)
		confetti.append({"p": c, "v": Vector2(cos(a), sin(a)) * sp + Vector2(0.0, -140.0 if big else -40.0), "r": randf() * TAU,
			"rv": randf_range(-8.0, 8.0), "t": 0.0, "life": randf_range(0.8, 1.5), "col": cols[randi() % cols.size()],
			"sz": randf_range(8.0, 17.0) if big else randf_range(5.0, 10.0), "shape": randi() % 2})


func _update_rewards(delta: float) -> void:
	for k in chip_pop.keys():
		chip_pop[k] = maxf(float(chip_pop[k]) - delta * 3.2, 0.0)
	for i in 3:
		quest_flash[i] = maxf(float(quest_flash[i]) - delta * 2.2, 0.0)
	if disp_coins != float(land_coins):
		disp_coins = move_toward(disp_coins, float(land_coins), maxf(60.0, absf(float(land_coins) - disp_coins) * 6.0) * delta)
	if disp_gems != float(land_gems):
		disp_gems = move_toward(disp_gems, float(land_gems), maxf(20.0, absf(float(land_gems) - disp_gems) * 6.0) * delta)
	if modal == "own" and fmod(modal_t, 0.9) < delta:
		_burst(Vector2(randf_range(140.0, 580.0), 330.0), 10, true)
	if modal == "gem":
		gem_t += delta
		if not gem_spawned and gem_t >= 1.6:
			_gem_spawn()
		if gem_spawned and rflyers.is_empty() and gem_t - gem_spawn_t > 0.5:
			_close_modal()
	if not rflyers.is_empty():
		var alive: Array = []
		for f in rflyers:
			if (t - float(f["t0"])) / float(f["dur"]) >= 1.0:
				_land(f)
			else:
				alive.append(f)
		rflyers = alive
	elif wallet_show:
		wallet_show = false
		_sync_wallet()
	for f in rfloats:
		f["t"] = float(f["t"]) + delta
	rfloats = rfloats.filter(func(f): return float(f["t"]) < 1.1)
	for p in confetti:
		p["t"] = float(p["t"]) + delta
		p["p"] = (p["p"] as Vector2) + (p["v"] as Vector2) * delta
		var v: Vector2 = p["v"]
		v.y += 760.0 * delta
		p["v"] = v * (1.0 - 1.1 * delta)
		p["r"] = float(p["r"]) + float(p["rv"]) * delta
	confetti = confetti.filter(func(p): return float(p["t"]) < float(p["life"]))
	if modal == "daily" and daily_view == 1:
		daily_t += delta
		if daily_t > 1.1 and rflyers.is_empty():
			_close_modal()


# ---------------- ÇİZİM: ÜST İKONLAR + CÜZDAN ----------------
func _draw_top_icons() -> void:
	if help_open:
		return
	_draw_gift_icon()
	_draw_quest_icon()
	_draw_market_icon()
	_draw_gem_btn()
	_draw_wallet()


func _draw_gift_icon() -> void:
	var c := _gift_rect().get_center()
	var claimable := Daily.can_claim()
	var s := (0.92 if press_id == "gift" else 1.0) * IK
	var wob := 0.0
	if claimable:
		wob = sin(t * 9.0) * 0.14 * maxf(0.0, sin(t * 1.7))
	draw_set_transform(c, wob, Vector2(s, s))
	draw_circle(Vector2.ZERO, 44.0, Color(0.20, 0.08, 0.05, 0.88))
	draw_arc(Vector2.ZERO, 44.0, 0.0, TAU, 40, Color(0.35, 0.85, 0.45) if claimable else Color(0.93, 0.45, 0.25), 5.0)
	draw_rect(Rect2(-23.0, -4.0, 46.0, 31.0), Color(0.88, 0.22, 0.26))
	draw_rect(Rect2(-27.0, -15.0, 54.0, 14.0), Color(1.0, 0.40, 0.42))
	draw_rect(Rect2(-5.0, -15.0, 10.0, 42.0), Color(1.0, 0.9, 0.3))
	draw_circle(Vector2(-10.0, -21.0), 9.0, Color(1.0, 0.9, 0.3))
	draw_circle(Vector2(10.0, -21.0), 9.0, Color(1.0, 0.9, 0.3))
	draw_circle(Vector2(0.0, -17.0), 5.0, Color(0.95, 0.7, 0.1))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if claimable:
		U.draw_badge(self, font, c + Vector2(31.0, -31.0) * IK, "!", 16.0, (1.0 + 0.08 * sin(t * 5.0)) * IK)


func _draw_quest_icon() -> void:
	var c := _quest_rect().get_center()
	var n := Daily.quests_ready_count()
	var s := (0.92 if press_id == "quest" else 1.0) * IK
	draw_set_transform(c, 0.0, Vector2(s, s))
	draw_circle(Vector2.ZERO, 44.0, Color(0.20, 0.08, 0.05, 0.88))
	draw_arc(Vector2.ZERO, 44.0, 0.0, TAU, 40, Color(0.35, 0.85, 0.45) if n > 0 else Color(0.93, 0.45, 0.25), 5.0)
	draw_rect(Rect2(-21.0, -26.0, 42.0, 54.0), Color(0.35, 0.16, 0.06))
	draw_rect(Rect2(-18.0, -23.0, 36.0, 48.0), Color(1.0, 0.96, 0.85))
	draw_rect(Rect2(-10.0, -31.0, 20.0, 11.0), Color(0.75, 0.45, 0.22))
	for i in 3:
		draw_line(Vector2(-3.0, -9.0 + i * 13.0), Vector2(12.0, -9.0 + i * 13.0), Color(0.6, 0.4, 0.25), 3.5)
		draw_circle(Vector2(-11.0, -9.0 + i * 13.0), 2.6, Color(0.6, 0.4, 0.25))
	draw_polyline(PackedVector2Array([Vector2(-14.0, -10.0), Vector2(-10.5, -5.0), Vector2(-4.0, -16.0)]), Color(0.18, 0.7, 0.28), 4.0)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if n > 0:
		U.draw_badge(self, font, c + Vector2(31.0, -31.0) * IK, str(n), 16.0, (1.0 + 0.08 * sin(t * 5.0)) * IK)


func _draw_wallet() -> void:
	_draw_chip("coin", false, disp_coins, float(chip_pop["coin"]))
	if page != "quests":
		_draw_chip("gem", true, disp_gems, float(chip_pop["gem"]))
	if page == "market":
		return
	if page == "quests":
		for id in Daily.PU_IDS:
			_draw_pu_pill(id)
	elif _wallet_pu_visible():
		_draw_pu_tray()


# Coin / elmas kutusu: ikon + sayı (kutu dar ise küçük düzen)
func _draw_chip(key: String, is_gem: bool, val: float, pop: float) -> void:
	var rc := _wallet_rect(key)
	var small := rc.size.x < 200.0
	var sc := 1.0 + pop * 0.10
	draw_set_transform(rc.get_center(), 0.0, Vector2(sc, sc))
	var lr := Rect2(-rc.size * 0.5, rc.size)
	if pop > 0.0:
		st_glow.bg_color.a = 0.55 * pop
		draw_style_box(st_glow, lr.grow(6.0 * pop))
	draw_style_box(st_chip, lr)
	var ix := 30.0 if small else 36.0
	var ir := 19.0 if small else 23.0
	if is_gem:
		U.draw_gem(self, Vector2(lr.position.x + ix, 0.0), ir)
	else:
		U.draw_coin(self, Vector2(lr.position.x + ix, 0.0), ir)
	var txt := str(int(round(val)))
	var tx := lr.position.x + ix + ir + 8.0
	var tw := lr.end.x - tx - 12.0
	var fs := _fit(txt, 27 if small else (32 if page == "quests" else 30), tw, 12)
	draw_string(font, Vector2(tx, fs * 0.36), txt, HORIZONTAL_ALIGNMENT_LEFT, tw + 4.0, fs, Color(0.75, 0.9, 1.0) if is_gem else Color(1.0, 0.93, 0.55))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


# Ana menü: 3 güç-up'ı tek bir şık tepsi içinde yuvarlak düğmeler + adet rozeti olarak gösterir
func _draw_pu_tray() -> void:
	var c0 := _wallet_rect("slow").get_center()
	draw_style_box(st_chip, Rect2(c0.x - 96.0, c0.y - 27.0, 192.0, 54.0))
	for id in Daily.PU_IDS:
		var c := _wallet_rect(id).get_center()
		var cnt := int(disp_pu[id])
		var pp := float(chip_pop[id])
		var r := 19.0 * (1.0 + pp * 0.25)
		if pp > 0.0:
			draw_circle(c, r + 10.0 * pp, Color(1.0, 0.9, 0.4, 0.45 * pp))
		var al := 1.0 if (cnt > 0 or pp > 0.0) else 0.4
		U.draw_pu_disc(self, tex_slip, id, c, r, al)
		if cnt > 0:
			var bc := c + Vector2(15.0, 14.0)
			draw_circle(bc, 11.0, Color(0.10, 0.04, 0.16))
			draw_circle(bc, 9.0, Color(1.0, 0.85, 0.30))
			draw_string(font, bc + Vector2(-20.0, 5.0), str(cnt), HORIZONTAL_ALIGNMENT_CENTER, 40.0, 14, Color(0.25, 0.10, 0.02))


# Görevler sayfası: geniş güç-up kutusu (ikon + x adet). Dönüşüm kullanılmaz, her şey ekran koordinatında.
func _draw_pu_pill(id: String) -> void:
	var rp := _wallet_rect(id)
	var cnt := int(disp_pu[id])
	var pp := float(chip_pop[id])
	var ps := 1.0 + pp * 0.14
	var lp := Rect2(rp.get_center() - rp.size * 0.5 * ps, rp.size * ps)
	if pp > 0.0:
		st_glow.bg_color.a = 0.55 * pp
		draw_style_box(st_glow, lp.grow(6.0 * pp))
	draw_style_box(st_chip, lp)
	var al := 1.0 if (cnt > 0 or pp > 0.0) else 0.45
	var cy := lp.get_center().y
	U.draw_pu_icon(self, tex_slip, id, Vector2(lp.position.x + lp.size.y * 0.5 + 4.0, cy), 0.62 * ps, Color(1, 1, 1, al))
	var tfs := int(30.0 * ps)
	draw_string(font, Vector2(lp.position.x + lp.size.y + 6.0, cy + tfs * 0.36), "x%d" % cnt, HORIZONTAL_ALIGNMENT_LEFT, lp.size.x - lp.size.y - 10.0, tfs, Color(1, 1, 1, al))


# ---------------- ÇİZİM: PENCERELER ----------------
func _draw_modal() -> void:
	var close_u := 0.0
	if modal == "daily" and daily_view == 1:
		close_u = clampf((daily_t - 0.75) / 0.35, 0.0, 1.0)
	if modal != "gem":
		draw_rect(Scr.full(), Color(0, 0, 0, 0.62 * clampf(modal_t / 0.2, 0.0, 1.0) * (1.0 - close_u)))
	if modal == "daily":
		_draw_wallet()                  # cüzdan karartmanın üstünde parlak kalsın (ödüller oraya uçar)
		_draw_daily(close_u)
	elif modal == "notif":
		_draw_notif()
	elif modal == "buy":
		_draw_buy()
	elif modal == "own":
		_draw_own()
	elif modal == "gem":
		_draw_gem_win()


func _draw_daily(close_u: float) -> void:
	var pr := _dm_panel()
	var cen := pr.get_center()
	var psc := U.out_back(modal_t / 0.4) * (1.0 - close_u * close_u)
	if psc <= 0.02:
		return
	U.sunburst(self, cen, t * 0.25, 14, Color(1.0, 0.85, 0.3, 0.10 * (1.0 - close_u)))
	draw_set_transform(cen, 0.0, Vector2(psc, psc))
	draw_style_box(st_panel, Rect2(-pr.size * 0.5, pr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if modal_t < 0.32 or close_u > 0.0:
		return
	if daily_view == 1 and daily_t < 0.25:                 # alma anı beyaz parlama
		st_flash.bg_color.a = 0.55 * (1.0 - daily_t / 0.25)
		draw_style_box(st_flash, pr)
	if daily_view == 1 and daily_t < 0.55:                 # genişleyen halka
		var ru := daily_t / 0.55
		draw_arc(cen + Vector2(0.0, -10.0), U.out_cubic(ru) * 360.0, 0.0, TAU, 64, Color(1.0, 0.9, 0.35, 1.0 - ru), maxf(2.0, 22.0 * (1.0 - ru)))
	var base_title := Loc.t("wb_title") if daily_wb else Loc.t("daily_title")
	var title := Loc.t("daily_claimed") if daily_view != 0 and not (daily_view == 1 and daily_t < 0.3) else base_title
	if daily_view == 1 and daily_t < 0.3:
		title = base_title
	var tsc := 1.0
	if daily_view == 1:
		tsc = 1.0 + 0.18 * sin(clampf(daily_t / 0.3, 0.0, 1.0) * PI)
	U.fat_text(self, font, title, Vector2(360.0, pr.position.y + 92.0), _fit(title, 46, 440.0, 26), Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15), 0.0, tsc)
	if daily_view == 2:
		_draw_daily_done(pr)
	else:
		if daily_wb:
			var wbm := Loc.t("wb_body")
			var wfs := 26
			while wfs > 16 and font.get_multiline_string_size(wbm, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 90.0, wfs).y > 70.0:
				wfs -= 1
			draw_multiline_string(font, Vector2(pr.position.x + 45.0, pr.position.y + 138.0), wbm, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 90.0, wfs, -1, Color(0.30, 0.14, 0.06))
		else:
			var day := int(daily_rw.get("day", 1))
			var dr := Rect2(360.0 - 135.0, pr.position.y + 122.0, 270.0, 58.0)
			draw_style_box(st_help, dr)
			U.out_text(self, font, Loc.t("daily_day") % day, dr.get_center() + Vector2(0.0, 11.0), 30, Color.WHITE)
		_draw_daily_items(pr)
		if daily_view == 0 and not daily_wb:
			var info := ""
			var icol := Color(0.40, 0.20, 0.08)
			if bool(daily_rw.get("extra", false)):
				info = Loc.t("daily_extra")
				icol = Color(0.80, 0.42, 0.02)
			else:
				var sk := Daily.streak_today()
				if sk >= 2:
					info = Loc.t("daily_streak") % sk
			if info != "":
				draw_string(font, Vector2(pr.position.x + 20.0, pr.position.y + 480.0), info, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 40.0, _fit(info, 28, pr.size.x - 60.0, 18), icol)
	if daily_view != 1:
		_draw_big_btn(_dm_btn(), Loc.t("daily_claim") if daily_view == 0 else Loc.t("ok"), press_id == "dm_btn", true)
	if daily_view == 0:
		var xc := _dm_x().get_center()
		draw_circle(xc, 26.0, Color(0.35, 0.13, 0.05))
		draw_circle(xc, 22.0, Color(0.95, 0.88, 0.7))
		draw_line(xc + Vector2(-8, -8), xc + Vector2(8, 8), Color(0.35, 0.13, 0.05), 5.0)
		draw_line(xc + Vector2(-8, 8), xc + Vector2(8, -8), Color(0.35, 0.13, 0.05), 5.0)


func _draw_daily_items(pr: Rect2) -> void:
	if daily_view == 1 and daily_t >= 0.3:
		return                                  # ödüller uçtu
	var items := _daily_items(daily_rw)
	for i in items.size():
		var it: Dictionary = items[i]
		var k := String(it["k"])
		var c: Vector2 = it["c"]
		var pop := U.out_back((modal_t - 0.35 - float(i) * 0.12) / 0.35)
		if daily_view == 1:
			pop = 1.0 + 0.28 * sin(clampf(daily_t / 0.3, 0.0, 1.0) * PI * 0.5)
		if pop <= 0.02:
			continue
		c.y += sin(t * 3.0 + float(i) * 1.3) * 5.0
		draw_circle(c, 84.0 * pop, Color(1.0, 0.85, 0.3, 0.14))
		draw_circle(c, 62.0 * pop, Color(1.0, 0.9, 0.5, 0.14))
		if k == "coin":
			U.draw_coin(self, c + Vector2(-26.0, 20.0) * pop, 34.0 * pop)
			U.draw_coin(self, c + Vector2(26.0, 16.0) * pop, 34.0 * pop)
			U.draw_coin(self, c + Vector2(0.0, -6.0) * pop, 44.0 * pop)
		else:
			U.draw_pu_disc(self, tex_slip, k, c, 60.0 * pop)
		var lab := ("+%d" % int(it["amt"])) if k == "coin" else ("x%d" % int(it["amt"]))
		U.out_text(self, font, lab, c + Vector2(0.0, 112.0 * pop), 50, Color(1.0, 0.92, 0.35), 0.0, pop)
		var cap := "Coin" if k == "coin" else Loc.t("pu_" + k)
		draw_string(font, Vector2(c.x - float(it["cell"]) * 0.5, c.y + 148.0), cap, HORIZONTAL_ALIGNMENT_CENTER, float(it["cell"]), _fit(cap, 24, float(it["cell"]) - 10.0, 14), Color(0.40, 0.20, 0.08))


func _draw_daily_done(pr: Rect2) -> void:
	var c := Vector2(360.0, pr.position.y + 250.0)
	var pu := 1.0 + 0.04 * sin(t * 3.0)
	draw_circle(c + Vector2(0, 6), 84.0 * pu, Color(0, 0, 0, 0.25))
	draw_circle(c, 84.0 * pu, Color(0.10, 0.45, 0.25))
	draw_circle(c, 76.0 * pu, Color(0.25, 0.80, 0.42))
	draw_polyline(PackedVector2Array([c + Vector2(-34, 2), c + Vector2(-8, 30), c + Vector2(38, -26)]), Color.WHITE, 16.0)
	var msg := Loc.t("daily_back")
	var fs := 28
	while fs > 18 and font.get_multiline_string_size(msg, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 100.0, fs).y > 130.0:
		fs -= 1
	draw_multiline_string(font, Vector2(pr.position.x + 50.0, pr.position.y + 440.0), msg, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 100.0, fs, -1, Color(0.30, 0.14, 0.06))


# Büyük yeşil buton (OYNA / AL / TAMAM stili)
func _draw_big_btn(r: Rect2, txt: String, pressed: bool, pulse: bool) -> void:
	var ps := 1.0 + (sin(t * 4.5) * 0.035 if pulse else 0.0)
	if pressed:
		ps = 0.94
	draw_set_transform(r.get_center(), 0.0, Vector2(ps, ps))
	draw_style_box(st_play, Rect2(-r.size * 0.5, r.size))
	draw_style_box(st_play_hi, Rect2(-r.size.x * 0.5 + 16.0, -r.size.y * 0.5 + 11.0, r.size.x - 32.0, r.size.y * 0.34))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	U.out_text(self, font, txt, r.get_center() + Vector2(0.0, 22.0) * ps, _fit(txt, 62, r.size.x - 60.0, 28), Color.WHITE, 0.0, ps)


func _draw_notif() -> void:
	var pr := _nm_panel()
	var u := U.out_back(modal_t / 0.35)
	draw_set_transform(pr.get_center(), 0.0, Vector2(u, u))
	draw_style_box(st_panel, Rect2(-pr.size * 0.5, pr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if modal_t < 0.3:
		return
	var ttl := Loc.t("notif_title")
	U.fat_text(self, font, ttl, Vector2(360.0, pr.position.y + 86.0), _fit(ttl, 44, 500.0, 24), Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15))
	# çan (sallanır)
	var sw := sin(t * 8.0) * 0.2 * maxf(0.0, sin(t * 1.8))
	draw_set_transform(Vector2(360.0, pr.position.y + 150.0), sw, Vector2.ONE)
	var pts := PackedVector2Array()
	for k in 21:
		var a := PI + float(k) * PI / 20.0
		pts.append(Vector2(cos(a) * 44.0, 44.0 + sin(a) * 44.0))
	pts.append(Vector2(58.0, 84.0))
	pts.append(Vector2(-58.0, 84.0))
	draw_colored_polygon(pts, Color(1.0, 0.82, 0.2))
	var ol := pts.duplicate()
	ol.append(pts[0])
	draw_polyline(ol, Color(0.55, 0.28, 0.05), 5.0)
	draw_circle(Vector2(0.0, -2.0), 8.0, Color(0.95, 0.6, 0.1))
	draw_circle(Vector2(0.0, 96.0), 12.0, Color(0.95, 0.6, 0.1))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var body := Loc.t("notif_body")
	var fs := 27
	while fs > 17 and font.get_multiline_string_size(body, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 100.0, fs).y > 250.0:
		fs -= 1
	draw_multiline_string(font, Vector2(pr.position.x + 50.0, pr.position.y + 300.0), body, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 100.0, fs, -1, Color(0.30, 0.14, 0.06))
	_draw_big_btn(_nm_allow(), Loc.t("adc_allow"), press_id == "nm_allow", true)
	var lr := _nm_later()
	var ls := 0.95 if press_id == "nm_later" else 1.0
	draw_set_transform(lr.get_center(), 0.0, Vector2(ls, ls))
	draw_style_box(st_help, Rect2(-lr.size * 0.5, lr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	U.out_text(self, font, Loc.t("notif_later"), lr.get_center() + Vector2(0.0, 12.0), _fit(Loc.t("notif_later"), 32, lr.size.x - 50.0, 18), Color.WHITE)


# ---------------- ÇİZİM: UÇAN ÖDÜLLER / KONFETİ ----------------
func _draw_reward_icon(k: String, c: Vector2, sz: float, a: float) -> void:
	if a <= 0.0:
		return
	if k == "coin":
		U.draw_coin(self, c, sz, a)
	elif k == "gem":
		U.draw_gem(self, c, sz * 1.05, a)
	else:
		U.draw_pu_disc(self, tex_slip, k, c, sz, a)


func _draw_rewards_fx() -> void:
	for p in confetti:
		var a := clampf((float(p["life"]) - float(p["t"])) / 0.4, 0.0, 1.0)
		var col: Color = p["col"]
		col.a = a
		var pos: Vector2 = p["p"]
		var sz: float = p["sz"]
		var rot: float = p["r"]
		if int(p["shape"]) == 0:
			draw_colored_polygon(U.star_pts(pos, sz, sz * 0.42, 5, rot), col)
		else:
			var d1 := Vector2(cos(rot), sin(rot)) * sz
			var d2 := Vector2(-sin(rot), cos(rot)) * sz * 0.5
			draw_colored_polygon(PackedVector2Array([pos + d1 + d2, pos + d1 - d2, pos - d1 - d2, pos - d1 + d2]), col)
	for f in rflyers:
		var u := (t - float(f["t0"])) / float(f["dur"])
		if u <= 0.0:
			continue
		var e := u * u * (3.0 - 2.0 * u)
		var k := String(f["k"])
		var sz := float(f["sz"]) * lerpf(1.0, 0.65, e)
		for tk in range(4, 0, -1):
			var uu := maxf(u - float(tk) * 0.05, 0.0)
			var ee := uu * uu * (3.0 - 2.0 * uu)
			_draw_reward_icon(k, U.bez(f["p0"], f["c"], f["p1"], ee), sz * (1.0 - float(tk) * 0.12), 0.34 - float(tk) * 0.07)
		_draw_reward_icon(k, U.bez(f["p0"], f["c"], f["p1"], e), sz, 1.0)
	for f in rfloats:
		var ft := float(f["t"])
		var col: Color = f["col"]
		col.a = clampf((1.1 - ft) / 0.4, 0.0, 1.0)
		U.out_text(self, font, String(f["txt"]), (f["pos"] as Vector2) + Vector2(0.0, -ft * 60.0), 40, col, 0.0, 0.7 + U.out_back(ft * 4.0) * 0.3)


# ---------------- GÖREVLER SAYFASI ----------------
func _qlayout() -> Vector2:                    # (ilk kartın y'si, kart yüksekliği)
	var y0 := _panel_top() + 104.0
	var avail := H - y0 - 70.0
	return Vector2(y0, minf(236.0, (avail - 32.0) / 3.0))


func _qcard(i: int) -> Rect2:
	var L := _qlayout()
	return Rect2(30.0, L.x + float(i) * (L.y + 16.0), 660.0, L.y)


func _qbtn(i: int) -> Rect2:
	var r := _qcard(i)
	return Rect2(r.end.x - 196.0, r.end.y - 88.0, 172.0, 64.0)


func _quest_claimable(i: int) -> bool:
	return Daily.quest_done(i) and not bool(Daily.q_claimed[i])


func _quests_input(pressed: bool, pos: Vector2) -> void:
	if pressed:
		press_pos = pos
		quest_btn_press = -1
		for i in Daily.q_type.size():
			if _quest_claimable(i) and _qbtn(i).has_point(pos):
				quest_btn_press = i
		return
	var bp := quest_btn_press
	quest_btn_press = -1
	if pos.distance_to(_back_center()) < 54.0 and press_pos.distance_to(_back_center()) < 54.0:
		Sfx.play("click")
		_open_page("main")
		return
	if bp >= 0 and _qbtn(bp).has_point(pos):
		_claim_quest(bp)


func _claim_quest(i: int) -> void:
	var r := Daily.claim_quest(i)
	if r.is_empty():
		return
	Sfx.play("win", 1.3, -6.0)
	if U.get_setting("vib", true):
		Input.vibrate_handheld(30)
	quest_flash[i] = 1.0
	var bc := _qbtn(i).get_center()
	_burst(bc, 16, true)
	_spawn_rewards(r, {"coin": bc}, 0.12)


func _draw_header(title: String) -> void:
	var pt := _panel_top()
	draw_rect(Rect2(-Scr.off.x, -Scr.off.y, Scr.size.x, pt + Scr.off.y), Color(0.17, 0.07, 0.27))
	var o := ad_off
	draw_rect(Rect2(160, 100.0 + o - 44.0, 400, 88), Color(0.13, 0.04, 0.03))
	draw_rect(Rect2(167, 100.0 + o - 37.0, 386, 74), Color(0.78, 0.12, 0.15))
	draw_rect(Rect2(167, 100.0 + o - 37.0, 386, 30), Color(0.95, 0.3, 0.3, 0.55))
	U.out_text(self, font, title, Vector2(360.0, 114.0 + o), _fit(title, 40, 340.0, 22), Color(1.0, 0.92, 0.5))
	var bc := _back_center()
	draw_circle(bc, 42.0, Color(0.12, 0.04, 0.2))
	draw_arc(bc, 42.0, 0.0, TAU, 40, Color(0.93, 0.45, 0.25), 5.0)
	draw_polyline(PackedVector2Array([bc + Vector2(14, 0), bc + Vector2(-14, 0)]), Color.WHITE, 6.0)
	draw_polyline(PackedVector2Array([bc + Vector2(-2, -14), bc + Vector2(-16, 0), bc + Vector2(-2, 14)]), Color.WHITE, 6.0)


func _draw_quests() -> void:
	Daily.ensure_quests()
	var pt := _panel_top()
	draw_rect(Scr.full(), Color(0.17, 0.07, 0.27))
	for s in sparks:
		var tw := maxf(0.5 + 0.5 * sin(t * 3.0 + float(s["ph"])), 0.2)
		var sz := float(s["s"]) * tw
		draw_colored_polygon(U.star_pts(Vector2(float(s["x"]), float(s["y"])), sz, sz * 0.25, 4, 0.0), Color(1.0, 0.95, 0.6, 0.25))
	draw_style_box(st_sheet, Rect2(0.0, pt, W, H - pt + 60.0))
	for i in Daily.q_type.size():
		_draw_quest_card(i)
	var rem := Daily.seconds_to_midnight()
	var txt := Loc.t("q_reset") % ("%d:%02d:%02d" % [rem / 3600, (rem % 3600) / 60, rem % 60])
	draw_string(font, Vector2(0.0, H - 26.0), txt, HORIZONTAL_ALIGNMENT_CENTER, W, 26, Color(0.55, 0.33, 0.15))
	_draw_header(Loc.t("quests_title"))
	_draw_wallet()


func _draw_quest_card(i: int) -> void:
	var r := _qcard(i)
	var ty := String(Daily.q_type[i])
	var tg := int(Daily.q_target[i])
	var pg := int(Daily.q_prog[i])
	var done := Daily.quest_done(i)
	var claimed := bool(Daily.q_claimed[i])
	draw_style_box(st_card_dim if claimed else (st_card_gold if done else st_card), r)
	var ic := Vector2(r.position.x + 78.0, r.get_center().y)
	draw_circle(ic, 54.0, Color(0.35, 0.13, 0.05))
	draw_circle(ic, 50.0, Color(1.0, 0.86, 0.55) if not claimed else Color(0.80, 0.76, 0.68))
	_draw_quest_glyph(ty, ic, 1.0 if not claimed else 0.55)
	var desc := Loc.t("q_" + ty) % tg
	var fs := 30
	while fs > 18 and font.get_multiline_string_size(desc, HORIZONTAL_ALIGNMENT_LEFT, 296.0, fs).y > 84.0:
		fs -= 1
	draw_multiline_string(font, Vector2(r.position.x + 146.0, r.position.y + 56.0), desc, HORIZONTAL_ALIGNMENT_LEFT, 296.0, fs, 2, Color(0.30, 0.14, 0.06) if not claimed else Color(0.45, 0.38, 0.32))
	var br := Rect2(r.position.x + 146.0, r.end.y - 84.0, 296.0, 32.0)
	draw_style_box(st_bar, br)
	var ratio := clampf(float(pg) / float(maxi(tg, 1)), 0.0, 1.0)
	if ratio > 0.0:
		st_bar_fill.bg_color = Color(0.25, 0.80, 0.36) if done else Color(0.95, 0.62, 0.15)
		draw_style_box(st_bar_fill, Rect2(br.position, Vector2(maxf(br.size.y, br.size.x * ratio), br.size.y)))
	U.out_text(self, font, "%d / %d" % [pg, tg], br.get_center() + Vector2(0.0, 8.0), 21, Color.WHITE)
	var rc := Vector2(r.end.x - 110.0, r.position.y + 62.0)
	U.draw_coin(self, rc + Vector2(-46.0, 0.0), 22.0, 0.5 if claimed else 1.0)
	draw_string(font, rc + Vector2(-18.0, 12.0), "+%d" % int(Daily.q_coin[i]), HORIZONTAL_ALIGNMENT_LEFT, 110.0, 34, Color(0.55, 0.30, 0.05) if not claimed else Color(0.5, 0.42, 0.36))
	var bt := _qbtn(i)
	if claimed:
		draw_style_box(st_dis, bt)
		draw_polyline(PackedVector2Array([bt.position + Vector2(30, 33), bt.position + Vector2(44, 47), bt.position + Vector2(68, 18)]), Color.WHITE, 8.0)
		draw_string(font, Vector2(bt.position.x + 70.0, bt.position.y + 41.0), Loc.t("q_claimed"), HORIZONTAL_ALIGNMENT_CENTER, bt.size.x - 74.0, _fit(Loc.t("q_claimed"), 22, bt.size.x - 80.0, 12), Color.WHITE)
	elif done:
		var ps := 1.0 + sin(t * 5.0) * 0.04
		if quest_btn_press == i:
			ps = 0.93
		draw_set_transform(bt.get_center(), 0.0, Vector2(ps, ps))
		draw_style_box(st_play, Rect2(-bt.size * 0.5, bt.size))
		draw_style_box(st_play_hi, Rect2(-bt.size.x * 0.5 + 12.0, -bt.size.y * 0.5 + 8.0, bt.size.x - 24.0, bt.size.y * 0.34))
		draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
		U.out_text(self, font, Loc.t("q_claim"), bt.get_center() + Vector2(0.0, 13.0) * ps, _fit(Loc.t("q_claim"), 38, bt.size.x - 30.0, 20), Color.WHITE, 0.0, ps)
	else:
		draw_style_box(st_dis, bt)
		U.out_text(self, font, Loc.t("q_claim"), bt.get_center() + Vector2(0.0, 13.0), _fit(Loc.t("q_claim"), 38, bt.size.x - 30.0, 20), Color(1, 1, 1, 0.6))
	var fl := float(quest_flash[i])
	if fl > 0.0:
		st_white.bg_color.a = 0.55 * fl
		draw_style_box(st_white, r)


func _draw_quest_glyph(ty: String, c: Vector2, a: float) -> void:
	var gold := Color(1.0, 0.78, 0.12, a)
	var dark := Color(0.35, 0.13, 0.05, a)
	match ty:
		"memo":
			var tex: Texture2D = tex_memo["memo_dil"]
			if tex != null:
				var h := 86.0
				var w := float(tex.get_width()) * h / float(tex.get_height())
				draw_texture_rect(tex, Rect2(c.x - w * 0.5, c.y - h * 0.55, w, h), false, Color(1, 1, 1, a))
		"stars":
			draw_colored_polygon(U.star_pts(c, 34.0, 15.0, 5, -PI / 2.0), dark)
			draw_colored_polygon(U.star_pts(c, 29.0, 12.5, 5, -PI / 2.0), gold)
		"threestar":
			for k in 3:
				var sc := c + Vector2((k - 1) * 28.0, 8.0 - (1.0 - absf(float(k - 1))) * 16.0)
				draw_colored_polygon(U.star_pts(sc, 19.0, 8.0, 5, -PI / 2.0), dark)
				draw_colored_polygon(U.star_pts(sc, 15.5, 6.5, 5, -PI / 2.0), gold)
		"levels":
			draw_line(c + Vector2(-16, 30), c + Vector2(-16, -30), dark, 6.0)
			draw_colored_polygon(PackedVector2Array([c + Vector2(-14, -30), c + Vector2(30, -16), c + Vector2(-14, -2)]), Color(0.88, 0.22, 0.26, a))
		"smash":
			draw_colored_polygon(PackedVector2Array([c + Vector2(-30, -6), c + Vector2(-8, -30), c + Vector2(-4, 2)]), Color(0.45, 0.75, 0.95, a))
			draw_colored_polygon(PackedVector2Array([c + Vector2(4, -30), c + Vector2(30, -8), c + Vector2(8, 6)]), Color(0.55, 0.82, 1.0, a))
			draw_colored_polygon(PackedVector2Array([c + Vector2(-20, 8), c + Vector2(6, 12), c + Vector2(-6, 32)]), Color(0.40, 0.68, 0.90, a))
			draw_colored_polygon(PackedVector2Array([c + Vector2(10, 14), c + Vector2(30, 10), c + Vector2(22, 32)]), Color(0.50, 0.78, 0.95, a))
		"powerup":
			draw_colored_polygon(PackedVector2Array([c + Vector2(6, -34), c + Vector2(-18, 4), c + Vector2(-2, 4), c + Vector2(-8, 34), c + Vector2(20, -8), c + Vector2(2, -8)]), dark)
			draw_colored_polygon(PackedVector2Array([c + Vector2(4, -29), c + Vector2(-12, 2), c + Vector2(2, 2), c + Vector2(-3, 27), c + Vector2(14, -5), c + Vector2(-2, -5)]), Color(0.55, 0.40, 1.0, a))
		"shots":
			U.draw_slipper(self, tex_slip, c, 80.0, -0.5, a)


# =====================================================================================
#  MARKET (terlik çeşitleri) + ELMAS KAZAN (Shop autoload'ıyla çalışır)
# =====================================================================================
func _market_rect() -> Rect2:
	return Rect2(188.0, 28.0 + ad_off, 82.0, 82.0)


func _gem_btn_rect() -> Rect2:
	return Rect2(110.0, 572.0, 500.0, 94.0)


func _mk_slipper(c: Vector2, k: float, rot: float, tint: Color) -> void:
	draw_set_transform(c, rot + PI * 0.5, Vector2(k, k))
	draw_texture_rect(tex_slip, Rect2(-0.10, -0.155, 0.20, 0.31), false, tint)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_market_icon() -> void:
	if help_open:
		return
	var c := _market_rect().get_center()
	var s := (0.92 if press_id == "market" else 1.0) * IK
	draw_circle(c, 44.0 * s, Color(0.20, 0.08, 0.05, 0.88))
	draw_arc(c, 44.0 * s, 0.0, TAU, 40, Color(0.93, 0.45, 0.25), 5.0)
	var tint := Shop.tint_now(Shop.equipped, t)
	_mk_slipper(c + Vector2(0.0, 2.0), 150.0 * s, -0.7, tint)
	var tw := 0.6 + 0.4 * sin(t * 4.0)
	draw_colored_polygon(U.star_pts(c + Vector2(24.0, -26.0) * IK, (9.0 * tw + 3.0) * IK, 3.5, 4, t), Color(1.0, 0.95, 0.5))


func _draw_gem_btn() -> void:
	if help_open:
		return
	var r := _gem_btn_rect()
	var left := Shop.cooldown_left()
	var loaded := Ads.is_stub or Ads.rewarded_ready
	var ready := left == 0 and loaded and not gem_busy
	var ps := 1.0 + (sin(t * 4.0) * 0.025 if ready else 0.0)
	if press_id == "gem":
		ps = 0.95
	draw_set_transform(r.get_center(), 0.0, Vector2(ps, ps))
	draw_style_box(st_gem_btn if ready else st_dis, Rect2(-r.size * 0.5, r.size))
	if ready:
		draw_style_box(st_play_hi, Rect2(-r.size.x * 0.5 + 14.0, -r.size.y * 0.5 + 9.0, r.size.x - 28.0, r.size.y * 0.30))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	var cy := r.get_center().y
	var gc := Vector2(r.position.x + 62.0, cy + (sin(t * 3.0) * 3.0 if ready else 0.0))
	U.draw_gem(self, gc, 34.0, 1.0 if ready else 0.5)
	if ready:
		for k in 3:
			var ph := t * 3.0 + float(k) * 2.1
			var tw := maxf(sin(ph), 0.0)
			draw_colored_polygon(U.star_pts(gc + Vector2([-30.0, 28.0, 4.0][k], [-18.0, -26.0, 30.0][k]), 3.0 + 7.0 * tw, 2.0, 4, ph), Color(1, 1, 1, tw))
	var tx := r.position.x + 112.0
	var tw2 := r.size.x - 112.0 - 96.0
	var l1 := ""
	var l2 := ""
	if left > 0:
		l1 = Loc.t("gem_wait") % ("%d:%02d:%02d" % [left / 3600, (left % 3600) / 60, left % 60])
	elif not ready:
		l1 = Loc.t("gem_loading")
	else:
		l1 = Loc.t("gem_btn")
		l2 = Loc.t("gem_watch") % Shop.ad_count
	var col := Color.WHITE if ready else Color(1, 1, 1, 0.72)
	if l2 == "":
		draw_string(font, Vector2(tx, cy + 10.0), l1, HORIZONTAL_ALIGNMENT_CENTER, tw2, _fit(l1, 28, tw2, 14), col)
	else:
		draw_string_outline(font, Vector2(tx, cy - 2.0), l1, HORIZONTAL_ALIGNMENT_CENTER, tw2, _fit(l1, 36, tw2, 18), 8, Color(0.22, 0.10, 0.48))
		draw_string(font, Vector2(tx, cy - 2.0), l1, HORIZONTAL_ALIGNMENT_CENTER, tw2, _fit(l1, 36, tw2, 18), Color.WHITE)
		draw_string(font, Vector2(tx, cy + 28.0), l2, HORIZONTAL_ALIGNMENT_CENTER, tw2, _fit(l2, 22, tw2, 12), Color(0.9, 0.85, 1.0))
	for k in 3:                                  # tur ilerlemesi: dolu nokta = izlenen reklam
		var dc := Vector2(r.end.x - 70.0 + float(k) * 22.0, cy)
		var filled := k < Shop.ad_count or left > 0
		draw_circle(dc, 9.0, Color(0.15, 0.06, 0.3, 0.9))
		draw_circle(dc, 7.0, (Color(0.75, 0.55, 1.0) if ready else Color(0.55, 0.5, 0.55)) if filled else Color(0.30, 0.20, 0.45))


func _gem_watch() -> void:
	if gem_busy or not Shop.can_watch():
		return
	if not Ads.is_stub and not Ads.rewarded_ready:
		return
	if Ads.show_rewarded():
		gem_busy = true
		Shop.ad_wait = true
		Sfx.play("click")


func _on_gem_earned() -> void:
	if not Shop.ad_wait:
		return
	Shop.ad_wait = false
	var n := Shop.gem_ad_done()
	if n > 0:
		_gem_reveal(n)


func _gem_reveal(n: int) -> void:
	modal = "gem"
	modal_t = 0.0
	press_id = ""
	gem_n = n
	gem_t = 0.0
	gem_spawned = false
	Sfx.play("win", 1.0 + 0.03 * float(n), -2.0)
	if U.get_setting("vib", true):
		Input.vibrate_handheld(40)
	_burst(Vector2(360.0, 600.0), 24 + n * 4, true)
	if n >= 5:
		get_tree().create_timer(0.35).timeout.connect(func(): _burst(Vector2(360.0, 560.0), 30, true))
	if n >= 10:
		get_tree().create_timer(0.7).timeout.connect(func(): _burst(Vector2(360.0, 640.0), 40, true))
		shake = 0.25


func _gem_spawn() -> void:
	gem_spawned = true
	gem_spawn_t = gem_t
	_spawn_rewards({"gem": gem_n}, {"gem": Vector2(360.0, 600.0)}, 0.0)


func _draw_gem_win() -> void:
	var out := 1.0
	if gem_spawned:
		out = clampf(1.0 - (gem_t - gem_spawn_t) / 0.35, 0.0, 1.0)
	draw_rect(Scr.full(), Color(0, 0, 0, 0.66 * clampf(modal_t / 0.2, 0.0, 1.0) * out))
	_draw_wallet()
	if out <= 0.0:
		return
	var col := Color(0.45, 0.75, 1.0)
	if gem_n >= 10:
		col = Color(1.0, 0.80, 0.25)
	elif gem_n >= 5:
		col = Color(0.78, 0.52, 1.0)
	var u := U.out_back(gem_t / 0.55)
	var cen := Vector2(360.0, 600.0)
	U.sunburst(self, cen, t * 0.5, 16, Color(col.r, col.g, col.b, 0.24 * out))
	draw_circle(cen, 230.0 * u * out, Color(col.r, col.g, col.b, 0.12))
	draw_circle(cen, 160.0 * u * out, Color(col.r, col.g, col.b, 0.18))
	for k in 8:
		var ang := t * 1.4 + float(k) * TAU / 8.0
		var rad := 210.0 * u + sin(t * 3.0 + float(k)) * 12.0
		var tw := maxf(sin(t * 5.0 + float(k) * 1.7), 0.15)
		draw_colored_polygon(U.star_pts(cen + Vector2(cos(ang), sin(ang)) * rad, 18.0 * tw * out, 5.0, 4, ang), Color(1, 1, 1, 0.9 * out))
	U.draw_gem(self, cen + Vector2(0.0, sin(t * 3.0) * 7.0), 132.0 * u * out, 1.0, col)
	var title := Loc.t("gem_jackpot") if gem_n >= 10 else Loc.t("gem_win")
	U.fat_text(self, font, title, Vector2(360.0, 330.0), _fit(title, 54, 600.0, 28), Color(1.0, 0.92, 0.35), Color(0.55, 0.2, 0.7), 0.0, u * out)
	U.out_text(self, font, "+%d" % gem_n, cen + Vector2(0.0, 270.0), 120, Color(0.85, 0.95, 1.0), 0.0, u * out)


# ---------------- MARKET SAYFASI ----------------
func _mk_card(i: int) -> Rect2:
	return Rect2(30.0, _panel_top() + 104.0 + float(i) * 306.0 - scroll, 660.0, 290.0)


func _mk_btns(i: int) -> Dictionary:
	var r := _mk_card(i)
	var bx := r.position.x + 214.0
	var by := r.end.y - 84.0
	var two := int(Shop.SKINS[i]["gem"]) > 0
	return {
		"use": Rect2(bx, by, 436.0, 64.0),
		"coin": Rect2(bx, by, 212.0 if two else 436.0, 64.0),
		"gem": Rect2(bx + 224.0, by, 212.0, 64.0),
	}


func _market_input(pressed: bool, pos: Vector2) -> void:
	if pressed:
		scroll_drag = true
		drag_moved = false
		press_pos = pos
		scroll_start = scroll
		return
	if not scroll_drag:
		return
	scroll_drag = false
	if drag_moved:
		return
	if pos.distance_to(_back_center()) < 54.0:
		Sfx.play("click")
		_open_page("main")
		return
	if pos.y < _panel_top() + 104.0:
		return
	for i in Shop.SKINS.size():
		var id := String(Shop.SKINS[i]["id"])
		var b := _mk_btns(i)
		if Shop.is_owned(id):
			if id != Shop.equipped and (b["use"] as Rect2).has_point(pos):
				Sfx.play("click")
				Shop.equip(id)
				_burst((b["use"] as Rect2).get_center(), 12, false)
				return
		else:
			if (b["coin"] as Rect2).has_point(pos):
				_mk_try_buy(id, false)
				return
			if int(Shop.SKINS[i]["gem"]) > 0 and (b["gem"] as Rect2).has_point(pos):
				_mk_try_buy(id, true)
				return


func _mk_try_buy(id: String, with_gems: bool) -> void:
	var s := Shop.skin(id)
	var price := int(s["gem"]) if with_gems else int(s["coin"])
	var have := Shop.gems if with_gems else Daily.get_coins()
	if have < price:
		Sfx.play("lose", 1.2, -6.0)
		_toast(Loc.t("mk_nogem") if with_gems else Loc.t("mk_nocoin"))
		return
	Sfx.play("click")
	buy_id = id
	buy_gem = with_gems
	modal = "buy"
	modal_t = 0.0
	press_id = ""


func _draw_market() -> void:
	var pt := _panel_top()
	draw_rect(Scr.full(), Color(0.17, 0.07, 0.27))
	for s in sparks:
		var tw := maxf(0.5 + 0.5 * sin(t * 3.0 + float(s["ph"])), 0.2)
		var sz := float(s["s"]) * tw
		draw_colored_polygon(U.star_pts(Vector2(float(s["x"]), float(s["y"])), sz, sz * 0.25, 4, 0.0), Color(1.0, 0.95, 0.6, 0.25))
	draw_style_box(st_sheet, Rect2(0.0, pt, W, H - pt + 60.0))
	for i in Shop.SKINS.size():
		_draw_mk_card(i)
	draw_rect(Rect2(0.0, pt + 30.0, W, 74.0), st_sheet.bg_color)
	_draw_header(Loc.t("market_title"))
	_draw_wallet()


func _draw_mk_card(i: int) -> void:
	var sk: Dictionary = Shop.SKINS[i]
	var id := String(sk["id"])
	var r := _mk_card(i)
	if r.end.y < _panel_top() + 20.0 or r.position.y > H:
		return
	var owned := Shop.is_owned(id)
	var eq := Shop.equipped == id
	draw_style_box(st_card_gold if eq else st_card, r)
	# önizleme kutusu: terlik + canlı iz efekti
	var pb := Rect2(r.position.x + 16.0, r.position.y + 16.0, 180.0, r.size.y - 32.0)
	draw_style_box(st_bar, pb)
	var c := pb.get_center() + Vector2(0.0, 6.0)
	var gc := Shop.glow_color(id)
	if gc.a > 0.0:
		draw_circle(c, 62.0 + sin(t * 6.0) * 3.0, Color(gc.r, gc.g, gc.b, gc.a * 0.7))
	_mk_preview(id, c, t, 1.0)
	_mk_slipper(c, 300.0 * (1.28 if id == "giant" else 1.0), -0.8, Shop.tint_now(id, t))
	var bx := r.position.x + 214.0
	var nm := Loc.t("sk_" + id)
	draw_string(font, Vector2(bx, r.position.y + 60.0), nm, HORIZONTAL_ALIGNMENT_LEFT, 316.0, _fit(nm, 38, 316.0, 20), Color(0.30, 0.14, 0.06))
	if id != "classic":
		var power := String(sk["kind"]) == "power"
		st_bar_fill.bg_color = Color(0.58, 0.38, 0.96) if power else Color(0.95, 0.45, 0.70)
		var chip := Rect2(r.end.x - 148.0, r.position.y + 28.0, 128.0, 34.0)
		draw_style_box(st_bar_fill, chip)
		var tg := Loc.t("mk_power") if power else Loc.t("mk_look")
		draw_string(font, Vector2(chip.position.x, chip.position.y + 25.0), tg, HORIZONTAL_ALIGNMENT_CENTER, chip.size.x, _fit(tg, 20, chip.size.x - 12.0, 11), Color.WHITE)
	var desc := Loc.t("sk_%s_d" % id)
	var fs := 24
	while fs > 15 and font.get_multiline_string_size(desc, HORIZONTAL_ALIGNMENT_LEFT, 440.0, fs).y > 92.0:
		fs -= 1
	draw_multiline_string(font, Vector2(bx, r.position.y + 100.0), desc, HORIZONTAL_ALIGNMENT_LEFT, 440.0, fs, 4, Color(0.40, 0.22, 0.10))
	var b := _mk_btns(i)
	if owned:
		var ur: Rect2 = b["use"]
		if eq:
			draw_style_box(st_help, ur)
			draw_polyline(PackedVector2Array([ur.position + Vector2(28, 34), ur.position + Vector2(42, 48), ur.position + Vector2(66, 18)]), Color.WHITE, 7.0)
			var u1 := Loc.t("mk_using")
			U.out_text(self, font, u1, ur.get_center() + Vector2(28.0, 10.0), _fit(u1, 28, ur.size.x - 110.0, 14), Color.WHITE)
		else:
			var pr2 := 0.95 if (press_id == "mk_use_" + id) else 1.0
			draw_style_box(st_play, ur)
			var u2 := Loc.t("mk_use")
			U.out_text(self, font, u2, ur.get_center() + Vector2(0.0, 11.0), 34, Color.WHITE, 0.0, pr2)
	else:
		_mk_price_btn(b["coin"], false, int(sk["coin"]), Daily.get_coins() >= int(sk["coin"]))
		if int(sk["gem"]) > 0:
			_mk_price_btn(b["gem"], true, int(sk["gem"]), Shop.gems >= int(sk["gem"]))


func _mk_price_btn(r: Rect2, gem: bool, price: int, can: bool) -> void:
	draw_style_box(st_gem_btn if gem else st_coin_btn, r)
	var cy := r.get_center().y
	if gem:
		U.draw_gem(self, Vector2(r.position.x + 34.0, cy), 21.0)
	else:
		U.draw_coin(self, Vector2(r.position.x + 34.0, cy), 21.0)
	var txt := str(price)
	var area := r.size.x - 66.0
	U.out_text(self, font, txt, Vector2(r.position.x + 56.0 + area * 0.5, cy + 11.0), _fit(txt, 32, area - 8.0, 14), Color.WHITE)
	if not can:
		st_white.bg_color = Color(0.1, 0.05, 0.1, 0.38)
		draw_style_box(st_white, r)


# Terlik efektinin önizlemesi: yaşa göre kayan parçacıklar, ekrandaki gerçek efektin kopyası
func _mk_preview(id: String, c: Vector2, tm: float, sc: float) -> void:
	if id == "classic":
		return
	var dir := Vector2(0.70, -0.72)
	for i in 10:
		var f := fposmod(tm * 1.3 - float(i) * 0.1, 1.0)
		var a := 1.0 - f
		var pos := c - dir * (24.0 + f * 120.0) * sc + Vector2(sin(float(i) * 3.1 + tm * 4.0), cos(float(i) * 2.3 + tm * 3.0)) * 9.0 * sc
		match id:
			"flame":
				var c1 := Color(1.0, 0.85, 0.3).lerp(Color(1.0, 0.25, 0.05), clampf(f * 1.6, 0.0, 1.0))
				var rr := 22.0 * sc * (1.0 - 0.7 * f)
				pos += Vector2(0.0, -f * 30.0 * sc)
				draw_circle(pos, rr * 1.5, Color(c1.r, c1.g * 0.6, c1.b, 0.28 * a))
				draw_circle(pos, rr, Color(c1.r, c1.g, c1.b, 0.85 * a))
				draw_circle(pos, rr * 0.5, Color(1.0, 0.95, 0.6, 0.7 * a))
			"hyper":
				draw_line(pos, pos - dir * 46.0 * sc, Color(0.7, 0.95, 1.0, 0.85 * a), 5.0 * sc)
				draw_line(pos, pos - dir * 30.0 * sc, Color(1, 1, 1, a), 2.0 * sc)
			"bolt":
				if i % 2 == 0:
					var ang := float(i) * 1.7 + floorf(tm * 9.0)
					var dr := Vector2(cos(ang), sin(ang)) * 36.0 * sc
					var pp := Vector2(-dr.y, dr.x) * 0.3
					var pts := PackedVector2Array([pos, pos + dr * 0.5 + pp, pos + dr * 0.9 - pp * 0.6, pos + dr * 1.3])
					draw_polyline(pts, Color(0.5, 0.7, 1.0, 0.5 * a), 6.0 * sc)
					draw_polyline(pts, Color(0.9, 0.95, 1.0, a), 2.2 * sc)
				else:
					draw_colored_polygon(U.star_pts(pos, 8.0 * sc * a + 2.0, 3.0, 4, tm * 3.0 + float(i)), Color(1.0, 0.95, 0.4, a))
			"giant":
				draw_circle(pos, 20.0 * sc * (0.6 + f), Color(0.72, 0.64, 0.52, 0.42 * a))
			"gold":
				if i % 3 == 0:
					U.draw_coin(self, pos, 9.0 * sc, a)
				else:
					draw_colored_polygon(U.star_pts(pos, 11.0 * sc * (1.0 - 0.4 * f), 4.0 * sc, 4, tm * 2.0 + float(i)), Color(1.0, 0.9, 0.4, a))
			"boom":
				draw_colored_polygon(U.star_pts(pos, 10.0 * sc * (1.0 - 0.4 * f), 3.5 * sc, 4, tm * 2.0 + float(i)), Color(0.85, 0.5, 1.0, a))
			"pink":
				draw_colored_polygon(U.star_pts(pos, 10.0 * sc * (1.0 - 0.4 * f), 3.5 * sc, 4, tm * 2.0 + float(i)), Color(1.0, 0.6, 0.85, a))
			"tiger":
				if i % 3 == 0:
					var pc := Color(0.32, 0.16, 0.05, 0.85 * a)
					draw_circle(pos, 8.0 * sc, pc)
					for k in 4:
						draw_circle(pos + Vector2(-1.2 + float(k) * 0.8, -1.05 + (0.35 if (k == 0 or k == 3) else 0.0)) * 8.0 * sc, 2.8 * sc, pc)
				else:
					draw_colored_polygon(U.star_pts(pos, 8.0 * sc, 3.0, 4, tm + float(i)), Color(1.0, 0.7, 0.2, a))
			"heart":
				U.draw_heart(self, pos + Vector2(0.0, -f * 36.0 * sc), 10.0 * sc * (1.0 - 0.3 * f), Color(1.0, 0.35, 0.5, a))
			"rainbow":
				draw_circle(pos, 13.0 * sc * (1.0 - 0.5 * f), Color.from_hsv(fposmod(float(i) * 0.1 + tm * 0.3, 1.0), 0.85, 1.0, 0.85 * a))
			"disco":
				draw_colored_polygon(U.star_pts(pos, 11.0 * sc * (1.0 - 0.4 * f), 4.0 * sc, 4, tm * 2.0 + float(i)), Color.from_hsv(fposmod(float(i) * 0.13 + floorf(tm * 5.0) * 0.21, 1.0), 0.7, 1.0, a))


# ---------------- SATIN ALMA ONAYI / KUTLAMA ----------------
func _by_panel() -> Rect2:
	return Rect2(60.0, 300.0, 600.0, 660.0)


func _by_yes() -> Rect2:
	return Rect2(110.0, 770.0, 500.0, 92.0)


func _by_no() -> Rect2:
	return Rect2(160.0, 876.0, 400.0, 64.0)


func _own_panel() -> Rect2:
	return Rect2(60.0, 280.0, 600.0, 700.0)


func _own_btn() -> Rect2:
	return Rect2(130.0, 850.0, 460.0, 100.0)


func _modal_input2(pressed: bool, pos: Vector2) -> void:
	if pressed:
		press_id = ""
		if modal == "buy":
			if _by_yes().has_point(pos):
				press_id = "by_yes"
			elif _by_no().has_point(pos):
				press_id = "by_no"
		elif _own_btn().has_point(pos):
			press_id = "own_ok"
		return
	var pid := press_id
	press_id = ""
	if modal == "buy":
		if pid == "by_yes" and _by_yes().has_point(pos):
			if Shop.buy(buy_id, buy_gem) == 0:
				own_id = buy_id
				land_coins = Daily.get_coins()          # bakiye sayacı aşağı akar
				land_gems = Shop.gems
				modal = "own"
				modal_t = 0.0
				Sfx.play("win", 1.1, -2.0)
				if U.get_setting("vib", true):
					Input.vibrate_handheld(50)
				_burst(Vector2(360.0, 560.0), 40, true)
			else:
				_close_modal()
		elif (pid == "by_no" and _by_no().has_point(pos)) or not _by_panel().has_point(pos):
			Sfx.play("click")
			_close_modal()
	elif modal == "own":
		if pid == "own_ok" and _own_btn().has_point(pos):
			Sfx.play("click")
			_close_modal()


func _draw_buy() -> void:
	var pr := _by_panel()
	var u := U.out_back(modal_t / 0.35)
	draw_set_transform(pr.get_center(), 0.0, Vector2(u, u))
	draw_style_box(st_panel, Rect2(-pr.size * 0.5, pr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if modal_t < 0.3:
		return
	var nm := Loc.t("sk_" + buy_id)
	var msg := Loc.t("mk_confirm") % nm
	U.fat_text(self, font, nm, Vector2(360.0, pr.position.y + 86.0), _fit(nm, 48, 500.0, 24), Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15))
	var c := Vector2(360.0, pr.position.y + 250.0)
	var gc := Shop.glow_color(buy_id)
	if gc.a > 0.0:
		draw_circle(c, 92.0 + sin(t * 6.0) * 4.0, Color(gc.r, gc.g, gc.b, gc.a * 0.8))
	_mk_preview(buy_id, c, t, 1.5)
	_mk_slipper(c, 430.0 * (1.2 if buy_id == "giant" else 1.0), -0.8, Shop.tint_now(buy_id, t))
	draw_string(font, Vector2(pr.position.x + 30.0, pr.position.y + 440.0), msg, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 60.0, _fit(msg, 30, pr.size.x - 70.0, 16), Color(0.30, 0.14, 0.06))
	var s := Shop.skin(buy_id)
	var price := int(s["gem"]) if buy_gem else int(s["coin"])
	var pc := Vector2(360.0 - 50.0, pr.position.y + 500.0)
	if buy_gem:
		U.draw_gem(self, pc, 28.0)
	else:
		U.draw_coin(self, pc, 28.0)
	draw_string(font, pc + Vector2(40.0, 13.0), str(price), HORIZONTAL_ALIGNMENT_LEFT, 200.0, 42, Color(0.55, 0.30, 0.05))
	_draw_big_btn(_by_yes(), Loc.t("mk_yes"), press_id == "by_yes", true)
	var nr := _by_no()
	var ns := 0.95 if press_id == "by_no" else 1.0
	draw_set_transform(nr.get_center(), 0.0, Vector2(ns, ns))
	draw_style_box(st_help, Rect2(-nr.size * 0.5, nr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	U.out_text(self, font, Loc.t("mk_no"), nr.get_center() + Vector2(0.0, 11.0), _fit(Loc.t("mk_no"), 30, nr.size.x - 40.0, 16), Color.WHITE)


func _draw_own() -> void:
	var pr := _own_panel()
	var u := U.out_back(modal_t / 0.45)
	U.sunburst(self, Vector2(360.0, 560.0), t * 0.4, 16, Color(1.0, 0.85, 0.3, 0.18))
	draw_set_transform(pr.get_center(), 0.0, Vector2(u, u))
	draw_style_box(st_panel, Rect2(-pr.size * 0.5, pr.size))
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
	if modal_t < 0.35:
		return
	var tt := Loc.t("mk_new")
	U.fat_text(self, font, tt, Vector2(360.0, pr.position.y + 92.0), _fit(tt, 54, 520.0, 28), Color(1.0, 0.9, 0.3), Color(0.95, 0.35, 0.15), 0.0, 1.0 + 0.05 * sin(t * 5.0))
	var c := Vector2(360.0, pr.position.y + 290.0)
	var gc := Shop.glow_color(own_id)
	var pu := 1.0 + 0.04 * sin(t * 3.0)
	if gc.a > 0.0:
		draw_circle(c, 130.0 * pu, Color(gc.r, gc.g, gc.b, gc.a * 0.8))
	draw_circle(c, 150.0 * pu, Color(1.0, 0.9, 0.5, 0.12))
	_mk_preview(own_id, c, t, 2.0)
	_mk_slipper(c + Vector2(0.0, sin(t * 2.5) * 8.0), 560.0 * (1.2 if own_id == "giant" else 1.0), -0.8 + sin(t * 1.5) * 0.12, Shop.tint_now(own_id, t))
	var nm := Loc.t("sk_" + own_id)
	U.out_text(self, font, nm, Vector2(360.0, pr.position.y + 520.0), _fit(nm, 52, 520.0, 24), Color(0.95, 0.55, 0.12))
	var sub := Loc.t("mk_new_sub")
	var fs := 26
	while fs > 16 and font.get_multiline_string_size(sub, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 100.0, fs).y > 92.0:
		fs -= 1
	draw_multiline_string(font, Vector2(pr.position.x + 50.0, pr.position.y + 570.0), sub, HORIZONTAL_ALIGNMENT_CENTER, pr.size.x - 100.0, fs, -1, Color(0.30, 0.14, 0.06))
	_draw_big_btn(_own_btn(), Loc.t("ok"), press_id == "own_ok", true)
